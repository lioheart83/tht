# PhimHDCSS Kodi Addon

Addon Kodi Python 3 cho `https://phimhdcss.com/`.

## Tính năng

- Trang chủ / phim đề cử.
- Tìm kiếm phim.
- Duyệt đầy đủ **Phim Thuyết Minh & Lồng Tiếng** (bao gồm cả phim đơn ngữ lẫn song ngữ `Vietsub + Thuyết Minh`, `Vietsub + Lồng Tiếng`, `Thuyết Minh + Lồng Tiếng`).
- Duyệt đầy đủ **Phim Phụ Đề (Vietsub / Engsub)** và Phim Song Ngữ.
- Thể loại và quốc gia lấy động từ website.
- Phim Full, Phim bộ, Phim lẻ, Chiếu Rạp, Sắp Chiếu, Bảng Xếp Hạng, Top Phim Ngày.
- Danh sách phim ngoài trang chủ, thể loại, quốc gia, tìm kiếm và danh mục Phụ đề / Thuyết minh đều hiển thị ngay **giới thiệu nội dung phim, trạng thái, năm, quốc gia, thể loại, thời lượng, diễn viên** (làm giàu song song qua HTTP/2 và lưu cache SQLite cục bộ), kèm tùy chọn đọc giới thiệu toàn màn hình trong Context Menu.
- Trang chi tiết phim, poster, mô tả, thông tin, server và tập phim (phim lẻ/phim ngắn 1 tập mở thẳng nguồn phát kèm menu ngữ cảnh phát ngay).
- Tải thêm tập qua AJAX cho phim dài.
- Resolver server FHDC (`stEg`/`iTXt` PNG + CDN dự phòng `#HDC-SHOP-ALT`), NC (HTTP/2 + mirror dự phòng `embed18`/`embed14`/`embed11`/`embed12`) và HD (cắt sạch đoạn quảng cáo chèn trong `.m3u8` mà vẫn giữ nguyên cảnh phim thật `convertv9/`).
- Loại bỏ quảng cáo toàn diện: chặn banner/popup server (`HY(pop)`), xoá quảng cáo mid-roll trong playlist HLS (`resources/lib/adblock.py`), chuyển đổi phụ đề `.vtt` sang `.srt` và lọc dòng quảng cáo rác trong phụ đề.
- Bấm một tập để mở danh sách nguồn phát với mục **Tự động phát nhanh (Không quảng cáo)** ở đầu danh sách, bên dưới là từng server khả dụng. Danh sách hiện ngay lập tức, phụ đề rời chỉ tải khi bắt đầu phát để tránh treo giao diện.
- Retry mạng ngắn (timeout thấp, tối đa 2 lần) để Android TV không bị đứng lâu khi một server chậm hoặc không phản hồi.
- Hiển thị thanh tiến trình khi đang tìm/kiểm tra nguồn phát nên thao tác không còn giống như bị treo.
- Kiểm tra playlist con và một segment trước khi phát; tự bỏ qua server trả manifest giả hoặc dữ liệu ảnh/HTML.
- Auto-play ưu tiên HLS chuẩn và kiểm tra nhanh segment để tránh nguồn phát đứng giữa chừng; proxy cục bộ tự đọc trước các segment kế tiếp (read-ahead), tự động thử lại khi đứt gói hoặc chuyển nhanh CDN dự phòng khi mirror chậm để xem liên tục không bị dừng giữa phim.
- Nguồn NC dùng proxy nội bộ với cổng tự cấp để truyền Referer cho toàn bộ segment trên Android Kodi; playlist được lưu trong `special://temp/` của Kodi (không dùng `tempfile` Android) và resolver ping proxy trước khi phát để tránh URL localhost chưa sẵn sàng.
- Gửi `Accept-Encoding: gzip` khi tải trang: trang danh sách/phim từ site nặng khoảng 120KB nhưng nén gzip chỉ còn ~13KB, giảm hẳn thời lượng tải trên mạng chậm (Wi-Fi TV Android).
- Dùng kết nối keep-alive (tái sử dụng TCP/TLS) cho toàn bộ HTTP request trong addon thay vì mở kết nối mới mỗi lần gọi; một lượt bấm (mở tập -> resolver embed -> gọi API player -> kiểm tra media) có thể gọi 3-5 request liên tiếp tới cùng host, mỗi lần bắt tay TLS mới tốn thêm 150-300ms trên mạng độ trễ cao.
- Từ 09/2026 nguồn NC (streamc.xyz) đổi sang player mới: POST bootstrap API (HTTP/2 qua httpx bundle trong addon) để nhận grant mã hoá AES-GCM chứa URL playlist ký sẵn, sau đó giải mã và phát qua proxy nội bộ như cũ. WAF Cloudflare của streamc chặn mọi client HTTP/1.1 theo TLS fingerprint nên bắt buộc phải dùng HTTP/2.

## Cài đặt

Copy thư mục addon vào thư mục `addons` của Kodi với tên khuyến nghị:

```text
plugin.video.phimhdcss
```

Sau đó mở Kodi và bật addon trong mục Video add-ons.

## Ghi chú

Addon chỉ đọc dữ liệu và link phát công khai mà website trả về. Nếu website đổi HTML, endpoint hoặc cơ chế player, cần cập nhật parser/resolver trong `resources/lib/scraper.py`.
