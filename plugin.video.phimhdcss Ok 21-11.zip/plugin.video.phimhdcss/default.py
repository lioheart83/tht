# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

import hashlib
import os
import sys
import traceback
from urllib.parse import parse_qsl, urlencode

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from resources.lib import scraper
from resources.lib.adblock import clean_subtitle_text
from resources.lib.meta_cache import get_cached_meta_many


ADDON = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo("name")
HANDLE = int(sys.argv[1])
PLUGIN_URL = sys.argv[0]


def build_url(params):
    return PLUGIN_URL + "?" + urlencode(params)


def notify(message, level=xbmcgui.NOTIFICATION_INFO):
    xbmcgui.Dialog().notification(ADDON_NAME, str(message), level, 5000)


def log_error(exc):
    xbmc.log("[%s] %s\n%s" % (ADDON_NAME, exc, traceback.format_exc()), xbmc.LOGERROR)


def list_item(label, art=None, info=None, playable=False):
    item = xbmcgui.ListItem(label=label)
    if art:
        item.setArt({
            "thumb": art,
            "icon": art,
            "poster": art,
            "fanart": art,
        })
    if info:
        item.setInfo("video", info)
    if playable:
        item.setProperty("IsPlayable", "true")
    return item


def add_folder(label, params, art=None, info=None, context_items=None):
    item = list_item(label, art=art, info=info)
    if context_items:
        item.addContextMenuItems(context_items)
    xbmcplugin.addDirectoryItem(
        HANDLE,
        build_url(params),
        item,
        isFolder=True,
    )


def add_playable(label, params, art=None, info=None, context_items=None):
    item = list_item(label, art=art, info=info, playable=True)
    if context_items:
        item.addContextMenuItems(context_items)
    xbmcplugin.addDirectoryItem(
        HANDLE,
        build_url(params),
        item,
        isFolder=False,
    )


def finish(content="videos", succeeded=True):
    xbmcplugin.setContent(HANDLE, content)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(HANDLE, succeeded=succeeded)


def show_root():
    add_folder("Trang chủ / Phim đề cử", {
        "mode": "listing",
        "url": scraper.BASE_URL + "/",
        "title": "Trang chủ",
    })
    add_folder("Tìm kiếm", {"mode": "search"})
    add_folder("Phim Thuyết Minh & Lồng Tiếng", {
        "mode": "lang_menu",
        "group": "dubbed",
        "title": "Phim Thuyết Minh & Lồng Tiếng",
    })
    add_folder("Phim Phụ Đề (Vietsub / Engsub)", {
        "mode": "lang_menu",
        "group": "subtitled",
        "title": "Phim Phụ Đề (Vietsub / Engsub)",
    })
    add_folder("Thể loại", {"mode": "nav", "group": "genres", "title": "Thể loại"})
    add_folder("Quốc gia", {"mode": "nav", "group": "countries", "title": "Quốc gia"})

    for label, url in scraper.MAIN_LISTS:
        add_folder(label, {"mode": "listing", "url": url, "title": label})
    finish("videos")


def show_lang_menu(group):
    if group == "dubbed":
        items = [
            ("Tất cả Phim Thuyết Minh & Lồng Tiếng", "dubbed_all"),
            ("Phim Thuyết Minh (Đơn ngữ & Song ngữ)", "thuyet_minh"),
            ("Phim Lồng Tiếng (Đơn ngữ & Song ngữ)", "long_tieng"),
            ("Phim Song Ngữ (Phụ Đề + Thuyết Minh/Lồng Tiếng)", "dual_audio"),
        ]
    else:
        items = [
            ("Tất cả Phim Phụ Đề (Vietsub)", "vietsub_all"),
            ("Phim Phụ Đề Tiếng Anh (Engsub)", "engsub"),
            ("Phim Song Ngữ (Phụ Đề + Thuyết Minh/Lồng Tiếng)", "dual_audio"),
        ]
    for label, group_key in items:
        add_folder(label, {
            "mode": "lang_listing",
            "group_key": group_key,
            "page": "1",
            "title": label,
        })
    finish("videos")


def format_movie_plot(meta, badge_override=""):
    header_parts = []
    badge = (badge_override or meta.get("label") or meta.get("status") or "").strip()
    if badge:
        header_parts.append("[COLOR gold][B]%s[/B][/COLOR]" % badge)

    year = scraper.safe_int(meta.get("year"))
    if year > 0:
        header_parts.append(str(year))

    country = (meta.get("country") or "").strip()
    if country:
        header_parts.append(country)

    episode_total = (meta.get("episode_total") or "").strip()
    if episode_total:
        if "tập" in episode_total.lower():
            header_parts.append(episode_total)
        else:
            header_parts.append("%s tập" % episode_total)

    duration_text = (meta.get("duration_text") or meta.get("duration") or "").strip()
    if duration_text:
        header_parts.append(duration_text)

    top_lines = []
    if header_parts:
        top_lines.append(" • ".join(header_parts))

    genres = (meta.get("genres") or "").strip()
    if genres:
        top_lines.append("[COLOR lightskyblue]Thể loại:[/COLOR] %s" % genres)

    title = (meta.get("title") or "").strip()
    original_title = (meta.get("original_title") or "").strip()
    if original_title and original_title.lower() != title.lower():
        top_lines.append("[COLOR lightskyblue]Tên gốc:[/COLOR] %s" % original_title)

    plot_text = (meta.get("plot") or "").strip() or "Chưa có nội dung giới thiệu cho phim này."

    footer_lines = []
    actors_raw = (meta.get("actors") or "").strip()
    if actors_raw:
        actor_list = [actor.strip() for actor in actors_raw.split(",") if actor.strip()]
        if actor_list:
            shown = ", ".join(actor_list[:6])
            if len(actor_list) > 6:
                shown += ", ..."
            footer_lines.append("[COLOR silver]Diễn viên: %s[/COLOR]" % shown)

    director = (meta.get("director") or "").strip()
    if director:
        footer_lines.append("[COLOR silver]Đạo diễn: %s[/COLOR]" % director)

    sections = []
    if top_lines:
        sections.append("\n".join(top_lines))
    sections.append(plot_text)
    if footer_lines:
        sections.append("\n".join(footer_lines))
    return "\n\n".join(sections)


def build_video_info(meta, title=None, mediatype="movie", badge_override=""):
    plot_formatted = format_movie_plot(meta, badge_override=badge_override)
    raw_plot = (meta.get("plot") or "").strip()
    info = {
        "title": title or meta.get("title", ""),
        "plot": plot_formatted,
        "plotoutline": raw_plot or plot_formatted,
        "mediatype": mediatype,
    }
    tagline = (badge_override or meta.get("label") or meta.get("status") or "").strip()
    if tagline:
        info["tagline"] = tagline
    if meta.get("original_title"):
        info["originaltitle"] = meta["original_title"]
    if meta.get("genres"):
        info["genre"] = meta["genres"]
    if meta.get("country"):
        info["country"] = meta["country"]
    if meta.get("director"):
        info["director"] = meta["director"]

    year = scraper.safe_int(meta.get("year"))
    if year > 0:
        info["year"] = year

    duration_sec = scraper.safe_int(meta.get("duration_seconds"))
    if duration_sec > 0:
        info["duration"] = duration_sec

    actors = (meta.get("actors") or "").strip()
    if actors:
        cast_list = [actor.strip() for actor in actors.split(",") if actor.strip()]
        if cast_list:
            info["cast"] = cast_list
    return info


def _movie_info_context_item(url, title):
    info_url = build_url({
        "mode": "movie_info",
        "url": url,
        "title": title,
    })
    return ("Đọc giới thiệu phim (Toàn màn hình)", "RunPlugin(%s)" % info_url)


def _add_movie_items(movies):
    for movie in movies:
        info = build_video_info(movie, title=movie["title"], mediatype="movie")
        add_folder(
            movie["display_title"],
            {
                "mode": "details",
                "url": movie["url"],
            },
            art=movie.get("thumb"),
            info=info,
            context_items=[_movie_info_context_item(movie["url"], movie["title"])],
        )


def show_lang_listing(group_key, page, title):
    page_num = max(1, scraper.safe_int(page) or 1)
    data = scraper.get_language_listing(group_key, page=page_num)
    xbmcplugin.setContent(HANDLE, "movies")
    _add_movie_items(data["movies"])

    if data.get("has_next"):
        add_folder("Trang tiếp theo", {
            "mode": "lang_listing",
            "group_key": group_key,
            "page": str(page_num + 1),
            "title": title or data.get("title", ""),
        })
    finish("movies")


def show_nav(group, title):
    links = scraper.get_nav_links(group)
    for entry in links:
        add_folder(entry["title"], {
            "mode": "listing",
            "url": entry["url"],
            "title": entry["title"],
        })
    finish("videos")


def show_listing(url, title):
    page = scraper.get_listing(url)
    xbmcplugin.setContent(HANDLE, "movies")
    _add_movie_items(page["movies"])

    if page.get("next_url"):
        add_folder("Trang tiếp theo", {
            "mode": "listing",
            "url": page["next_url"],
            "title": title,
        })
    finish("movies")


def show_movie_info(url, title=""):
    cached = get_cached_meta_many([url]).get(url)
    if cached and cached.get("plot"):
        detail = dict(cached)
        if not detail.get("title"):
            detail["title"] = title
    else:
        detail = scraper.get_detail(url, load_all_episodes=False)
    xbmcgui.Dialog().textviewer(
        detail.get("title") or title or ADDON_NAME,
        format_movie_plot(detail),
    )


def show_details(url):
    detail = scraper.get_detail(url, load_all_episodes=False)
    info_ctx = _movie_info_context_item(url, detail["title"])

    if detail.get("watch_url") and not detail["episode_groups"]:
        watch_info = build_video_info(detail, title=detail["title"], mediatype="movie")
        add_folder("Chọn nguồn phát", {
            "mode": "sources",
            "url": detail["watch_url"],
            "title": detail["title"],
            "art": detail.get("poster", ""),
        }, art=detail.get("poster"), info=watch_info, context_items=[info_ctx])

    for group in detail["episode_groups"]:
        label = scraper.display_group_title(group)
        group_info = build_video_info(detail, title=label, mediatype="movie", badge_override=label)
        episodes = group.get("episodes") or []
        if len(episodes) == 1 and (group.get("total") or 1) <= 1:
            ep = episodes[0]
            full_title = "%s - %s" % (detail["title"], label)
            play_url = build_url({
                "mode": "play_episode",
                "url": ep["url"],
                "title": full_title,
                "art": detail.get("poster", ""),
            })
            add_folder(label, {
                "mode": "sources",
                "url": ep["url"],
                "title": full_title,
                "art": detail.get("poster", ""),
            }, art=detail.get("poster"), info=group_info, context_items=[
                ("Phát tự động ngay (Không QC)", "PlayMedia(%s)" % play_url),
                info_ctx,
            ])
        else:
            add_folder(label, {
                "mode": "episodes",
                "url": url,
                "server": group.get("server", group["title"]),
                "title": "%s - %s" % (detail["title"], label),
            }, art=detail.get("poster"), info=group_info, context_items=[info_ctx])

    if not detail.get("watch_url") and not detail["episode_groups"]:
        notify("Không tìm thấy tập phim.", xbmcgui.NOTIFICATION_WARNING)
    finish("episodes")


def show_episode_group(url, server, title):
    detail = scraper.get_detail(url, load_all_episodes=True)
    target_server = scraper.normalize_server_key(server)
    group = None
    for candidate in detail["episode_groups"]:
        if (
            scraper.normalize_server_key(candidate.get("server")) == target_server
            or scraper.normalize_server_key(candidate.get("title")) == target_server
        ):
            group = candidate
            break

    if not group:
        notify("Không tìm thấy nhóm tập phim.", xbmcgui.NOTIFICATION_WARNING)
        finish("episodes", succeeded=False)
        return

    xbmcplugin.setContent(HANDLE, "episodes")
    for episode in scraper.sort_episodes_ascending(group["episodes"]):
        ep_title = "%s - %s" % (title or scraper.display_group_title(group), episode["title"])
        episode_info = build_video_info(
            detail,
            title=ep_title,
            mediatype="episode",
            badge_override=episode["title"],
        )
        number = int(scraper.episode_sort_key(episode) or 0)
        if number:
            episode_info["episode"] = number
        label = "%s - %s" % (scraper.language_label(group.get("server") or group.get("title")), episode["title"])
        add_folder(label, {
            "mode": "sources",
            "url": episode["url"],
            "title": episode_info["title"],
            "art": detail.get("poster", ""),
        }, art=detail.get("poster"), info=episode_info)

    finish("episodes")


def show_search():
    keyboard = xbmc.Keyboard("", "Tìm phim trên PhimHDCSS")
    keyboard.doModal()
    if not keyboard.isConfirmed() or not keyboard.getText().strip():
        finish("videos", succeeded=False)
        return

    keyword = keyboard.getText().strip()
    url = scraper.search_url(keyword)
    show_listing(url, "Tìm kiếm: " + keyword)


def show_sources(episode_url, title, art):
    sources = scraper.get_episode_sources(episode_url)
    # Ẩn các nguồn đã xác định không phát được hoặc chỉ là popup quảng cáo.
    playable_sources = [source for source in sources if not scraper.is_unplayable_source(source)]
    if not playable_sources:
        notify("Tập này chỉ có nguồn chưa phát được (HDC/OP/HY).", xbmcgui.NOTIFICATION_WARNING)
        finish("videos", succeeded=False)
        return
    supported_sources = [source for source in playable_sources if scraper.is_supported_source(source)]
    display_sources = sorted(supported_sources or playable_sources, key=lambda item: scraper.priority_index(item["name"]))

    auto_label = "Tự động phát nhanh (Không quảng cáo)"
    add_playable(auto_label, {
        "mode": "play_episode",
        "url": episode_url,
        "title": title,
        "art": art,
    }, art=art, info={"title": auto_label, "plot": "Tập đã chọn: %s" % title})

    for source in display_sources:
        # Build the menu instantly.  Probing each server for subtitles used to
        # trigger a full stream resolution (several HTTP requests) per source on
        # Kodi's UI thread, which froze Android TV for many seconds.  Subtitles
        # are now discovered only when the user actually starts playback.
        label = source_display_label(source)
        source_info = {
            "title": label,
            "plot": "Tập đã chọn: %s" % title,
        }
        add_playable(label, {
            "mode": "play_stream",
            "url": source["url"],
            "server_type": source.get("type", ""),
            "referer": episode_url,
            "title": title + " - " + source["name"],
            "art": art,
        }, art=art, info=source_info)
    finish("videos")


def source_display_label(source, subtitle_hint=""):
    name = source.get("name", "Server")
    kind = (source.get("kind") or "").upper()
    details = [kind or "LINK"]
    if name.upper().strip() in ("NC", "FHDC"):
        details.append("proxy cục bộ")
    details.append("Không quảng cáo")
    if subtitle_hint:
        details.append(subtitle_hint)
    return "%s [%s]" % (name, " - ".join(details))


def resolve_and_play(media):
    item = xbmcgui.ListItem(path=media["url"])
    item.setProperty("IsPlayable", "true")
    try:
        item.setContentLookup(False)
    except AttributeError:
        pass
    if media.get("mime"):
        item.setMimeType(media["mime"])
    if media.get("inputstream"):
        stream_headers = urlencode(media.get("headers") or {})
        item.setProperty("inputstream", media["inputstream"])
        item.setProperty("inputstream.adaptive.manifest_type", "hls")
        item.setProperty("inputstream.adaptive.manifest_headers", stream_headers)
        item.setProperty("inputstream.adaptive.stream_headers", stream_headers)
    if media.get("title"):
        item.setInfo("video", {"title": media["title"]})
    if media.get("art"):
        item.setArt({"thumb": media["art"], "poster": media["art"], "icon": media["art"]})
    subtitles = prepare_subtitles(media.get("subtitles") or [])
    if subtitles:
        item.setSubtitles(subtitles)
    xbmcplugin.setResolvedUrl(HANDLE, True, item)


def prepare_subtitles(subtitles):
    paths = []
    if not subtitles:
        return paths

    temp_dir = xbmcvfs.translatePath("special://temp/plugin.video.phimhdcss-subtitles")
    if not xbmcvfs.exists(temp_dir):
        xbmcvfs.mkdirs(temp_dir)

    # Tải tối đa 3 phụ đề ưu tiên (Tiếng Việt -> Tiếng Anh), chuyển VTT sang SRT
    # và lọc bỏ các dòng quảng cáo rác trong phụ đề với timeout ngắn.
    for subtitle in subtitles[:3]:
        try:
            url = subtitle.get("url", "")
            if not url:
                continue
            label = subtitle.get("label", "subtitle")
            digest = hashlib.md5(url.encode("utf-8")).hexdigest()
            path = os.path.join(temp_dir, "%s-%s.srt" % (safe_filename(label), digest))
            text = scraper.request_text(url, headers={"Referer": subtitle.get("referer", "")}, timeout=6)
            text = normalize_subtitle_text(text)
            if not text:
                continue
            with open(path, "w", encoding="utf-8-sig", newline="\n") as handle:
                handle.write(text)
            paths.append(path)
        except Exception as exc:
            xbmc.log("[%s] Không tải được phụ đề %s: %s" % (ADDON_NAME, subtitle, exc), xbmc.LOGWARNING)
    return paths


def normalize_subtitle_text(text):
    return clean_subtitle_text(text)


def safe_filename(value):
    value = "".join(ch for ch in str(value or "subtitle") if ch.isalnum() or ch in ("-", "_", "."))
    return value or "subtitle"


def play_episode(episode_url, title, art):
    progress = _busy("Đang tìm nguồn phát...")
    try:
        media = scraper.resolve_episode_media(episode_url)
    finally:
        _busy_close(progress)
    media["title"] = title
    media["art"] = art
    resolve_and_play(media)


def play_stream(url, server_type, referer, title, art):
    progress = _busy("Đang kiểm tra nguồn phát...")
    try:
        media = scraper.validate_media(scraper.resolve_stream(url, server_type=server_type, referer=referer))
    finally:
        _busy_close(progress)
    media["title"] = title
    media["art"] = art
    resolve_and_play(media)


def _busy(message):
    try:
        progress = xbmcgui.DialogProgressBG()
        progress.create(ADDON_NAME, message)
        return progress
    except Exception:
        return None


def _busy_close(progress):
    if progress is None:
        return
    try:
        progress.close()
    except Exception:
        pass


def router():
    params = dict(parse_qsl(sys.argv[2][1:]))
    mode = params.get("mode", "root")

    try:
        if mode == "root":
            show_root()
        elif mode == "lang_menu":
            show_lang_menu(params.get("group", "dubbed"))
        elif mode == "lang_listing":
            show_lang_listing(params.get("group_key", ""), params.get("page", "1"), params.get("title", ""))
        elif mode == "nav":
            show_nav(params.get("group", ""), params.get("title", ""))
        elif mode == "listing":
            show_listing(params["url"], params.get("title", ""))
        elif mode == "details":
            show_details(params["url"])
        elif mode == "movie_info":
            show_movie_info(params["url"], params.get("title", ""))
        elif mode == "episodes":
            show_episode_group(params["url"], params.get("server", ""), params.get("title", ""))
        elif mode == "search":
            show_search()
        elif mode == "sources":
            show_sources(params["url"], params.get("title", ""), params.get("art", ""))
        elif mode == "play_episode":
            play_episode(params["url"], params.get("title", ""), params.get("art", ""))
        elif mode == "play_stream":
            play_stream(
                params["url"],
                params.get("server_type", ""),
                params.get("referer", ""),
                params.get("title", ""),
                params.get("art", ""),
            )
        else:
            show_root()
    except scraper.ScraperError as exc:
        log_error(exc)
        notify(exc, xbmcgui.NOTIFICATION_ERROR)
        if mode.startswith("play"):
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        else:
            finish("videos", succeeded=False)
    except Exception as exc:
        log_error(exc)
        notify("Có lỗi khi xử lý addon.", xbmcgui.NOTIFICATION_ERROR)
        if mode.startswith("play"):
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        else:
            finish("videos", succeeded=False)


if __name__ == "__main__":
    router()
