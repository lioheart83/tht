# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

import json
import os

import xbmcaddon
import xbmcvfs


STATE_FILE = "nc_proxy.json"
WORKSPACE_DIR = "plugin.video.phimhdcss"


def proxy_base(port):
    return "http://127.0.0.1:%s" % int(port)


def state_path():
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile"))
    return os.path.join(profile, STATE_FILE)


def proxy_workspace_dir():
    temporary_root = xbmcvfs.translatePath("special://temp/")
    workspace = os.path.realpath(os.path.join(temporary_root, WORKSPACE_DIR))
    if not os.path.isdir(workspace):
        xbmcvfs.mkdirs(workspace)
    return workspace


def write_proxy_state(port):
    port = int(port)
    if port < 1 or port > 65535:
        raise ValueError("Invalid proxy port")
    path = state_path()
    directory = os.path.dirname(path)
    if directory and not os.path.isdir(directory):
        xbmcvfs.mkdirs(directory)
    temporary_path = path + ".tmp"
    with open(temporary_path, "w", encoding="utf-8") as handle:
        json.dump({"port": port}, handle)
    os.replace(temporary_path, path)
    return proxy_base(port)


def read_proxy_base():
    try:
        with open(state_path(), "r", encoding="utf-8") as handle:
            port = int(json.load(handle).get("port"))
        if 1 <= port <= 65535:
            return proxy_base(port)
    except (IOError, OSError, TypeError, ValueError, json.JSONDecodeError):
        pass
    return None


def clear_proxy_state(port=None):
    path = state_path()
    if port is not None:
        try:
            with open(path, "r", encoding="utf-8") as handle:
                if int(json.load(handle).get("port")) != int(port):
                    return
        except (IOError, OSError, TypeError, ValueError, json.JSONDecodeError):
            return
    try:
        os.remove(path)
    except OSError:
        pass
