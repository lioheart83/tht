# -*- coding: utf-8 -*-
"""Keep-alive urllib opener.

Kodi's addon runs as a fresh Python process for every menu click, but a
single click can still fire several HTTP requests in a row (episode list
AJAX pagination, resolving a player embed, then its API call, then probing
the media itself).  The stock ``urllib`` opener opens a brand new TCP+TLS
connection for every one of those requests.  On a slow/high-latency mobile
network (typical for an Android TV box on Wi-Fi) each extra TLS handshake
costs 150-300ms, and this adds up across the several sequential requests a
single "click" can trigger.

This module keeps one open connection per host for the lifetime of the
opener (i.e. for the lifetime of the addon process) so that follow-up
requests to the same host reuse the existing TCP+TLS session instead of
renegotiating it.  It falls back to a normal one-shot connection if the
pooled connection turns out to be dead.
"""
from __future__ import absolute_import, unicode_literals

import http.client
import io
import socket
import threading
from urllib.error import URLError
from urllib.request import HTTPCookieProcessor, HTTPHandler, HTTPSHandler, build_opener
from urllib.response import addinfourl


class _ConnectionPool(object):
    """Keeps at most one open connection per host."""

    def __init__(self):
        self._lock = threading.Lock()
        self._conns = {}

    def get(self, host, factory, timeout):
        with self._lock:
            conn = self._conns.get(host)
        if conn is not None:
            conn.timeout = timeout
            return conn
        conn = factory(host, timeout=timeout)
        with self._lock:
            self._conns[host] = conn
        return conn

    def drop(self, host):
        with self._lock:
            conn = self._conns.pop(host, None)
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass


class _KeepAliveMixin(object):
    def do_open(self, conn_factory, req):
        host = req.host
        if not host:
            raise URLError("no host given")
        timeout = req.timeout if getattr(req, "timeout", None) else 15
        pool = self._pool

        headers = dict(req.unredirected_hdrs)
        for key, value in req.headers.items():
            headers.setdefault(key, value)
        headers["Connection"] = "keep-alive"
        body = req.data

        conn = pool.get(host, conn_factory, timeout)
        attempts = 0
        while True:
            attempts += 1
            try:
                conn.request(req.get_method(), req.selector, body, headers)
                response = conn.getresponse()
                break
            except (http.client.BadStatusLine, http.client.ResponseNotReady,
                    ConnectionError, BrokenPipeError, socket.error) as exc:
                pool.drop(host)
                if attempts >= 2:
                    raise URLError(exc)
                conn = pool.get(host, conn_factory, timeout)

        payload = response.read()
        if response.getheader("Connection", "").lower() == "close" or response.version == 10:
            pool.drop(host)

        wrapped = addinfourl(io.BytesIO(payload), response.msg, req.get_full_url())
        wrapped.code = response.status
        wrapped.msg = response.reason
        return wrapped


class _KeepAliveHTTPHandler(_KeepAliveMixin, HTTPHandler):
    def __init__(self, pool):
        HTTPHandler.__init__(self)
        self._pool = pool

    def http_open(self, req):
        return self.do_open(http.client.HTTPConnection, req)


class _KeepAliveHTTPSHandler(_KeepAliveMixin, HTTPSHandler):
    def __init__(self, pool):
        HTTPSHandler.__init__(self)
        self._pool = pool

    def https_open(self, req):
        return self.do_open(http.client.HTTPSConnection, req)


def build_keepalive_opener(cookie_jar):
    """Return a urllib opener that reuses one connection per host and shares
    the given cookie jar, matching the signature previously used with
    ``build_opener(HTTPCookieProcessor(cookie_jar))``."""
    pool = _ConnectionPool()
    return build_opener(
        _KeepAliveHTTPHandler(pool),
        _KeepAliveHTTPSHandler(pool),
        HTTPCookieProcessor(cookie_jar),
    )
