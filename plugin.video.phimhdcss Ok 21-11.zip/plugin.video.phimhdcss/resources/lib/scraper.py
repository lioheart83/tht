# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

import base64
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FuturesTimeoutError, as_completed
import gzip
import hashlib
import hmac
import html as html_lib
import json
import os
import re
import sys
import threading
import time
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qs, parse_qsl, quote, urlencode, urljoin, urlparse
from urllib.request import Request
from http.cookiejar import CookieJar

# Thư viện HTTP/2 bundle (httpx + h2...) nằm cùng thư mục này. Cloudflare WAF
# cua streamc.xyz chan moi client HTTP/1.1 (urllib) theo TLS fingerprint nen
# request toi streamc.xyz phai di qua HTTP/2.
_LIB_DIR = os.path.dirname(os.path.abspath(__file__))
if _LIB_DIR not in sys.path:
    sys.path.insert(0, _LIB_DIR)

import httpx

from resources.lib.adblock import strip_hls_ads
from resources.lib.aesgcm import decrypt as aesgcm_decrypt
from resources.lib.httpkeepalive import build_keepalive_opener
from resources.lib.meta_cache import get_cached_meta_many, put_cached_meta_many
from resources.lib.nc_proxy_state import proxy_workspace_dir, read_proxy_base


BASE_URL = "https://phimhdcss.com"
SITE_HOST = (urlparse(BASE_URL).hostname or "phimhdcss.com").lower().lstrip("www.")
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36"
)

MAIN_LISTS = [
    ("Phim Full", BASE_URL + "/danh-sach/phim-hoan-thanh"),
    ("Phim bộ", BASE_URL + "/danh-sach/phim-bo"),
    ("Phim lẻ", BASE_URL + "/danh-sach/phim-le"),
    ("Chiếu Rạp", BASE_URL + "/danh-sach/phim-chieu-rap"),
    ("Sắp Chiếu", BASE_URL + "/danh-sach/phim-sap-chieu"),
    ("Bảng Xếp Hạng", BASE_URL + "/danh-sach/bang-xep-hang"),
    ("Top Phim Ngày", BASE_URL + "/danh-sach/top-phim-ngay"),
]

LANGUAGE_GROUPS = {
    "dubbed_all": {
        "title": "Tất cả Phim Thuyết Minh & Lồng Tiếng",
        "filters": (
            "Vietsub + Thuyết Minh",
            "Thuyết Minh",
            "Lồng Tiếng",
            "Vietsub + Lồng Tiếng",
            "Thuyết Minh + Lồng Tiếng",
            "Thuyết Minh + Vietsub",
            "Thuyết Minh + Vietsub + Lồng Tiếng",
        ),
    },
    "thuyet_minh": {
        "title": "Phim Thuyết Minh (Đơn ngữ & Song ngữ)",
        "filters": (
            "Vietsub + Thuyết Minh",
            "Thuyết Minh",
            "Thuyết Minh + Vietsub",
            "Thuyết Minh + Lồng Tiếng",
            "Thuyết Minh + Vietsub + Lồng Tiếng",
        ),
    },
    "long_tieng": {
        "title": "Phim Lồng Tiếng (Đơn ngữ & Song ngữ)",
        "filters": (
            "Lồng Tiếng",
            "Vietsub + Lồng Tiếng",
            "Thuyết Minh + Lồng Tiếng",
            "Thuyết Minh + Vietsub + Lồng Tiếng",
        ),
    },
    "vietsub_all": {
        "title": "Tất cả Phim Phụ Đề (Vietsub)",
        "filters": (
            "Vietsub",
            "Vietsub + Thuyết Minh",
            "Vietsub + Lồng Tiếng",
            "Thuyết Minh + Vietsub",
            "Thuyết Minh + Vietsub + Lồng Tiếng",
        ),
    },
    "dual_audio": {
        "title": "Phim Song Ngữ (Vừa có Phụ Đề vừa có Thuyết Minh/Lồng Tiếng)",
        "filters": (
            "Vietsub + Thuyết Minh",
            "Vietsub + Lồng Tiếng",
            "Thuyết Minh + Vietsub",
            "Thuyết Minh + Vietsub + Lồng Tiếng",
        ),
    },
    "engsub": {
        "title": "Phim Phụ Đề Tiếng Anh (Engsub)",
        "filters": ("Engsub",),
    },
}

# Ưu tiên nguồn sạch không quảng cáo trước (FHDC, NC), sau đó tới HD (đã cắt QC HLS).
STREAM_PRIORITY = ("FHDC", "NC", "HD", "HDC", "OP")
NC_MIRROR_HOSTS = (
    "embed18.streamc.xyz",
    "embed14.streamc.xyz",
    "embed11.streamc.xyz",
    "embed12.streamc.xyz",
)
RETRYABLE_STATUS_CODES = (408, 429, 500, 502, 503, 504)
COOKIE_JAR = CookieJar()
# A keep-alive opener reuses one TCP+TLS connection per host for the whole
# addon process instead of renegotiating it on every single HTTP request.
# A single click (open episode -> resolve embed -> call player API -> probe
# media) can fire 3-5 sequential requests to the same host(s); on a
# high-latency Android TV Wi-Fi link each fresh TLS handshake costs an extra
# 150-300ms, which is what actually made browsing feel slow (the site itself
# responds in well under half a second and isn't blocking/rate-limiting us).
HTTP_OPENER = build_keepalive_opener(COOKIE_JAR)



class ScraperError(Exception):
    pass


def ready_proxy_base():
    base = read_proxy_base()
    if not base:
        raise ScraperError("Proxy cục bộ chưa sẵn sàng. Hãy thử lại sau vài giây.")
    for attempt in range(5):
        try:
            request = Request(base + "/ping", headers={"User-Agent": USER_AGENT})
            with HTTP_OPENER.open(request, timeout=1) as response:
                if response.read() == b"ok":
                    return base
        except (HTTPError, URLError, OSError):
            pass
        if attempt < 4:
            time.sleep(0.1)
    raise ScraperError("Proxy cục bộ chưa sẵn sàng. Hãy thử lại sau vài giây.")


def request_text(url, data=None, headers=None, method=None, timeout=12):
    body = None
    final_headers = {
        "User-Agent": USER_AGENT,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "vi,en-US;q=0.9,en;q=0.8",
        # The site (Cloudflare) supports gzip and shrinks these HTML listing
        # pages roughly 9x (~120KB -> ~13KB), but urllib never asks for it by
        # default.  Requesting it cuts transfer time noticeably on slow
        # mobile/Wi-Fi links typical for Android TV boxes.
        "Accept-Encoding": "gzip",
    }

    if headers:
        final_headers.update(headers)

    if isinstance(data, dict):
        body = urlencode(data).encode("utf-8")
        final_headers.setdefault("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
    elif data is not None:
        body = data

    # Two attempts with a short timeout keeps the worst-case wait around 25s
    # instead of ~75s.  A long serial wait on the UI thread is what made
    # Android TV appear frozen when a host was slow or unreachable.
    for attempt in range(2):
        try:
            req = Request(url, data=body, headers=final_headers, method=method)
            with HTTP_OPENER.open(req, timeout=timeout) as response:
                raw = response.read()
                if response.headers.get("Content-Encoding", "").lower() == "gzip":
                    raw = gzip.decompress(raw)
                charset = response.headers.get_content_charset() or "utf-8"
                return raw.decode(charset, "ignore")
        except HTTPError as exc:
            if exc.code not in RETRYABLE_STATUS_CODES or attempt == 1:
                raise ScraperError("HTTP %s khi tải %s" % (exc.code, url))
        except URLError as exc:
            if attempt == 1:
                raise ScraperError("Không kết nối được %s: %s" % (url, exc.reason))
        except Exception as exc:
            if attempt == 1:
                raise ScraperError("Không tải được %s: %s" % (url, exc))
        time.sleep(0.3 * (attempt + 1))


def request_json(url, data=None, headers=None, method=None, timeout=25):
    text = request_text(url, data=data, headers=headers, method=method, timeout=timeout)
    try:
        return json.loads(text)
    except ValueError:
        raise ScraperError("Phản hồi JSON không hợp lệ từ %s" % url)


def normalize_url(url, base=BASE_URL):
    url = html_lib.unescape((url or "").strip())
    if not url or url.startswith("javascript:") or url.startswith("#"):
        return ""
    if url.startswith("//"):
        url = "https:" + url
    url = urljoin(base, url)
    url = url.replace("http://phimhdcss.com", "https://phimhdcss.com")
    url = url.replace("https://phimhdcss.net", BASE_URL)
    url = url.replace("http://phimhdcss.net", BASE_URL)
    return url


def is_site_url(url):
    host = (urlparse(url).hostname or "").lower().lstrip("www.")
    return host == SITE_HOST


def clean_text(value):
    if value is None:
        return ""
    value = re.sub(r"(?is)<script.*?</script>|<style.*?</style>", " ", str(value))
    value = re.sub(r"(?s)<[^>]+>", " ", value)
    value = html_lib.unescape(value)
    value = value.replace("\xa0", " ")
    value = re.sub(r"\s+", " ", value)
    return value.strip()


def attr(tag, name, default=""):
    patterns = [
        r'\b%s\s*=\s*"([^"]*)"' % re.escape(name),
        r"\b%s\s*=\s*'([^']*)'" % re.escape(name),
    ]
    for pattern in patterns:
        match = re.search(pattern, tag, re.I)
        if match:
            return html_lib.unescape(match.group(1))
    return default


def meta_content(html, key, value):
    pattern = r'<meta\b(?=[^>]*\b%s=["\']%s["\'])[^>]*\bcontent=["\']([^"\']*)["\']' % (
        re.escape(key),
        re.escape(value),
    )
    match = re.search(pattern, html, re.I)
    return clean_text(match.group(1)) if match else ""


def search_url(keyword):
    return BASE_URL + "/?search=" + quote(keyword.encode("utf-8"))


def get_home_html():
    return request_text(BASE_URL + "/")


def get_nav_links(group):
    html = get_home_html()
    if group == "countries":
        prefix = "/quoc-gia/"
    elif group == "genres":
        prefix = "/the-loai/"
    else:
        return []

    links = []
    seen = set()
    for match in re.finditer(r"<a\b[^>]*href=[\"']([^\"']+)[\"'][^>]*>(.*?)</a>", html, re.S | re.I):
        url = normalize_url(match.group(1))
        parsed_path = urlparse(url).path
        if not parsed_path.startswith(prefix):
            continue
        title = clean_text(match.group(2))
        if not title or url in seen:
            continue
        seen.add(url)
        links.append({"title": title, "url": url})
    return links


def get_listing(url):
    url = normalize_url(url)
    html = request_text(url)
    movies = parse_movies(html, url)
    enrich_movies_metadata(movies)
    return {
        "movies": movies,
        "next_url": find_next_page(html, url),
    }


LANGUAGE_PAGE_SIZE = 20
LANGUAGE_CACHE_TTL = 300


def _fetch_language_site_page(group_key, group, site_page):
    cache_path = ""
    try:
        cache_dir = proxy_workspace_dir()
        cache_path = os.path.join(
            cache_dir,
            "lang-page-%s-%d.json" % (safe_path_token(group_key), site_page),
        )
        if os.path.isfile(cache_path) and (time.time() - os.path.getmtime(cache_path)) <= LANGUAGE_CACHE_TTL:
            with open(cache_path, "r", encoding="utf-8") as handle:
                cached = json.load(handle)
            if isinstance(cached, dict) and isinstance(cached.get("movies"), list):
                return cached
    except Exception:
        cache_path = ""

    urls = []
    for lang in group["filters"]:
        params = [("filter[sort]", "update"), ("filter[language]", lang)]
        if site_page > 1:
            params.append(("page", str(site_page)))
        urls.append(BASE_URL + "/?" + urlencode(params))

    def fetch_one(client, target_url):
        for attempt in range(2):
            resp = client.get(target_url)
            if resp.status_code in RETRYABLE_STATUS_CODES and attempt == 0:
                time.sleep(0.35)
                continue
            if resp.status_code >= 400:
                raise ScraperError("HTTP %s khi tải %s" % (resp.status_code, target_url))
            html = resp.text
            return {
                "movies": parse_movies(html, target_url),
                "has_next": bool(find_next_page(html, target_url)),
            }
        raise ScraperError("Không tải được %s" % target_url)

    results = []
    errors = []
    with httpx.Client(
        http2=True,
        timeout=12,
        follow_redirects=True,
        headers={
            "User-Agent": USER_AGENT,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "vi,en-US;q=0.9,en;q=0.8",
            "Accept-Encoding": "gzip",
        },
    ) as client:
        with ThreadPoolExecutor(max_workers=min(4, len(urls))) as executor:
            futures = [executor.submit(fetch_one, client, target_url) for target_url in urls]
            for future in futures:
                try:
                    results.append(future.result())
                except Exception as exc:
                    errors.append(exc)

    if not results and errors:
        raise ScraperError("Không tải được danh sách phim theo ngôn ngữ: %s" % errors[0])

    merged = []
    seen = set()
    lists = [res["movies"] for res in results if res["movies"]]
    max_len = max((len(items) for items in lists), default=0)
    for idx in range(max_len):
        for items in lists:
            if idx < len(items):
                movie = items[idx]
                if movie["url"] not in seen:
                    seen.add(movie["url"])
                    merged.append(movie)

    data = {
        "movies": merged,
        "has_next": bool(merged) and any(res["has_next"] for res in results),
    }
    if cache_path and merged:
        try:
            with open(cache_path, "w", encoding="utf-8") as handle:
                json.dump(data, handle, ensure_ascii=False)
        except Exception:
            pass
    return data


def get_language_listing(group_key, page=1):
    group = LANGUAGE_GROUPS.get(group_key)
    if not group:
        raise ScraperError("Danh mục ngôn ngữ không hợp lệ.")
    page = max(1, safe_int(page) or 1)
    start = (page - 1) * LANGUAGE_PAGE_SIZE
    end = page * LANGUAGE_PAGE_SIZE

    combined = []
    seen = set()
    site_page = 1
    more_on_site = True
    while len(combined) < end + 1 and more_on_site and site_page <= 20:
        site_data = _fetch_language_site_page(group_key, group, site_page)
        site_movies = site_data.get("movies") or []
        for movie in site_movies:
            url = movie.get("url")
            if url and url not in seen:
                seen.add(url)
                combined.append(movie)
        more_on_site = bool(site_data.get("has_next")) and bool(site_movies)
        site_page += 1

    page_movies = [dict(movie) for movie in combined[start:end]]
    enrich_movies_metadata(page_movies)
    has_next = len(combined) > end or more_on_site
    return {
        "movies": page_movies,
        "has_next": has_next,
        "title": group["title"],
    }


def parse_movies(html, page_url):
    movies = []
    seen = set()
    blocks = re.findall(r'<li\b[^>]*class=["\'][^"\']*\bitem\b[^"\']*["\'][^>]*>(.*?)</li>', html, re.S | re.I)

    for block in blocks:
        image_tag_match = re.search(r"<img\b[^>]*class=[\"'][^\"']*\bimg-film\b[^\"']*[\"'][^>]*>", block, re.I)
        link_match = re.search(r"<a\b[^>]*href=[\"']([^\"']+)[\"'][^>]*>\s*(?:<img|\s*<span|\s*<i)", block, re.S | re.I)
        if not image_tag_match or not link_match:
            continue

        url = normalize_url(link_match.group(1), page_url)
        if not url or not is_site_url(url) or url in seen:
            continue
        seen.add(url)

        image_tag = image_tag_match.group(0)
        thumb = normalize_url(attr(image_tag, "src"), page_url)
        label_match = re.search(r'<span\b[^>]*class=["\']label["\'][^>]*>(.*?)</span>', block, re.S | re.I)
        label = clean_text(label_match.group(1)) if label_match else ""

        name_match = re.search(
            r'<div\b[^>]*class=["\']name["\'][^>]*>.*?<a\b[^>]*>(.*?)</a>',
            block,
            re.S | re.I,
        )
        title = clean_text(name_match.group(1)) if name_match else ""
        if not title:
            title = clean_text(attr(image_tag, "title") or attr(image_tag, "alt"))
        if not title:
            continue

        year = extract_year(title)
        display_title = title
        if label:
            display_title = "%s - %s" % (title, label)

        movies.append({
            "title": title,
            "display_title": display_title,
            "url": url,
            "thumb": thumb,
            "label": label,
            "year": year,
        })

    if not movies:
        movies = parse_avatar_movies(html, page_url)
    return movies


def parse_avatar_movies(html, page_url):
    movies = []
    seen = set()
    blocks = re.findall(r'<li\b[^>]*class=["\'][^"\']*\bfilm-item-ver\b[^"\']*["\'][^>]*>(.*?)</li>', html, re.S | re.I)
    for block in blocks:
        link = re.search(r"<a\b[^>]*href=[\"']([^\"']+)[\"'][^>]*>", block, re.I)
        image = re.search(r"<img\b[^>]*>", block, re.I)
        name = re.search(r'<p\b[^>]*class=["\']name["\'][^>]*>.*?<a\b[^>]*>(.*?)</a>', block, re.S | re.I)
        if not link or not name:
            continue
        url = normalize_url(link.group(1), page_url)
        if not url or not is_site_url(url) or url in seen:
            continue
        seen.add(url)
        thumb = normalize_url(attr(image.group(0), "src"), page_url) if image else ""
        title = clean_text(name.group(1))
        label_match = re.search(r'<span\b[^>]*class=["\']text-muted["\'][^>]*>(.*?)</span>', block, re.S | re.I)
        label = clean_text(label_match.group(1)) if label_match else ""
        movies.append({
            "title": title,
            "display_title": "%s - %s" % (title, label) if label else title,
            "url": url,
            "thumb": thumb,
            "label": label,
            "year": extract_year(title + " " + label),
        })
    return movies


def find_next_page(html, page_url):
    candidates = []
    for match in re.finditer(r"<a\b[^>]*href=[\"']([^\"']+)[\"'][^>]*>(.*?)</a>", html, re.S | re.I):
        tag = match.group(0)
        text = clean_text(match.group(2)).lower()
        href = normalize_url(match.group(1), page_url)
        if not href:
            continue
        if "navigation next" in tag or "rel=\"next\"" in tag or "rel='next'" in tag or text in ("sau »", "sau", "›", "»"):
            candidates.append(href)
    return candidates[0] if candidates else ""


def extract_year(text):
    match = re.search(r"\b(19\d{2}|20\d{2})\b", text or "")
    return int(match.group(1)) if match else 0


def normalize_csv_text(value):
    text = clean_text(value)
    if not text:
        return ""
    return re.sub(r"\s*,\s*", ", ", text).strip(" ,")


def parse_duration_seconds(value):
    text = clean_text(value)
    if not text:
        return 0
    total_seconds = 0
    hour_match = re.search(r"(\d+)\s*(?:giờ|gio|h)(?=\s*\d|\b|$)", text, re.I)
    if hour_match:
        total_seconds += int(hour_match.group(1)) * 3600
        rest = text[hour_match.end():]
        min_match = re.search(r"(\d+)\s*(?:phút|phut|p|m)?", rest, re.I)
        if min_match and min_match.group(1):
            total_seconds += int(min_match.group(1)) * 60
        return total_seconds

    min_match = re.search(r"(\d+)\s*(?:phút|phut|min|m|p)(?:/|\b|$)", text, re.I)
    if min_match:
        return int(min_match.group(1)) * 60
    return 0


def clean_plot_text(plot):
    text = clean_text(plot)
    if not text:
        return ""
    text = re.sub(
        r"(?i)\s*(?:chúc các bạn xem phim[^.!?]*|"
        r"xem phim\b[^.!?]*\btại\s+\S+[^.!?]*|"
        r"truy cập\s+\S+[^.!?]*)[.!]*\s*$",
        "",
        text,
    ).strip()
    if re.match(r"(?i)^xem phim\s+.+?(?:vietsub|thuyết minh|lồng tiếng|full hd)", text):
        stripped = re.sub(
            r"(?i)^xem phim\s+.+?(?:vietsub|thuyết minh|lồng tiếng|full hd)[^.!?]*[.!?\-:]\s*",
            "",
            text,
        ).strip()
        if stripped and len(stripped) > 20:
            return stripped
        return ""
    return text


def extract_movie_meta_from_html(html, page_url=""):
    fields = parse_detail_fields(html)
    title = extract_first(html, r'<span\b[^>]*class=["\']title["\'][^>]*itemprop=["\']name["\'][^>]*>(.*?)</span>')
    if not title:
        title = meta_content(html, "property", "og:title").replace("Phim ", "", 1)
    original_title = extract_first(html, r'<span\b[^>]*class=["\']real-name["\'][^>]*>(.*?)</span>')
    raw_plot = (
        parse_plot(html)
        or meta_content(html, "name", "description")
        or meta_content(html, "property", "og:description")
    )
    poster = normalize_url(meta_content(html, "property", "og:image"), page_url)
    if not poster:
        image_match = re.search(r"<img\b[^>]*itemprop=[\"']image[\"'][^>]*>", html, re.I)
        poster = normalize_url(attr(image_match.group(0), "src"), page_url) if image_match else ""

    duration_text = clean_text(fields.get("Thời lượng", ""))
    return {
        "title": clean_text(title) or "Phim",
        "plot": clean_plot_text(raw_plot),
        "original_title": clean_text(original_title),
        "status": clean_text(fields.get("Trạng thái", "")),
        "episode_total": clean_text(fields.get("Số tập", "")),
        "duration_text": duration_text,
        "duration_seconds": parse_duration_seconds(duration_text),
        "year": extract_year(fields.get("Năm sản xuất", "") or original_title),
        "country": normalize_csv_text(fields.get("Quốc gia", "")),
        "genres": normalize_csv_text(fields.get("Thể loại", "")),
        "director": normalize_csv_text(fields.get("Đạo diễn", "")),
        "actors": normalize_csv_text(fields.get("Diễn viên", "")),
        "poster": poster,
    }


def enqueue_background_prefetch(urls):
    if not urls:
        return
    base = read_proxy_base()
    if not base:
        return
    try:
        payload = json.dumps({"urls": list(urls)}).encode("utf-8")
        req = Request(
            base + "/prefetch",
            data=payload,
            headers={
                "Content-Type": "application/json",
                "User-Agent": USER_AGENT,
            },
            method="POST",
        )
        with HTTP_OPENER.open(req, timeout=0.15) as resp:
            resp.read()
    except Exception:
        pass


def enrich_movies_metadata(movies, max_fetch=16, deadline_sec=5.5):
    if not movies:
        return movies

    urls = [movie.get("url", "") for movie in movies if movie.get("url")]
    cached = get_cached_meta_many(urls)

    all_missing = []
    seen_missing = set()
    for url in urls:
        if url not in cached and url not in seen_missing:
            seen_missing.add(url)
            all_missing.append(url)

    immediate_urls = all_missing[:max_fetch]
    fetched = {}
    if immediate_urls:
        client = httpx.Client(
            http2=True,
            timeout=httpx.Timeout(4.5, connect=3.0),
            follow_redirects=True,
            limits=httpx.Limits(max_keepalive_connections=2, max_connections=2),
            headers={
                "User-Agent": USER_AGENT,
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "Accept-Language": "vi,en-US;q=0.9,en;q=0.8",
                "Accept-Encoding": "gzip",
            },
        )
        executor = ThreadPoolExecutor(max_workers=min(3, len(immediate_urls)))
        rate_lock = threading.Lock()
        next_slot = [time.monotonic()]

        def wait_slot():
            with rate_lock:
                now = time.monotonic()
                wait = max(0.0, next_slot[0] - now)
                next_slot[0] = max(now, next_slot[0]) + 0.06
            if wait > 0:
                time.sleep(wait)

        def fetch_one(target_url):
            for attempt in range(2):
                wait_slot()
                try:
                    resp = client.get(target_url)
                    if resp.status_code == 200:
                        return extract_movie_meta_from_html(resp.text, target_url)
                    if resp.status_code in (429, 503) and attempt == 0:
                        time.sleep(0.9)
                        continue
                    return None
                except Exception:
                    if attempt == 0:
                        time.sleep(0.4)
                        continue
                    return None
            return None

        future_to_url = {executor.submit(fetch_one, url): url for url in immediate_urls}
        try:
            for future in as_completed(future_to_url, timeout=deadline_sec):
                target_url = future_to_url[future]
                try:
                    meta = future.result()
                    if meta:
                        fetched[target_url] = meta
                except Exception:
                    continue
        except FuturesTimeoutError:
            pass
        finally:
            for future in future_to_url:
                future.cancel()
            executor.shutdown(wait=False)
            try:
                client.close()
            except Exception:
                pass

        if fetched:
            put_cached_meta_many(fetched)
            cached.update(fetched)

    remaining_urls = [url for url in all_missing if url not in cached]
    if remaining_urls:
        enqueue_background_prefetch(remaining_urls)

    for movie in movies:
        meta = cached.get(movie.get("url", ""))
        if not meta:
            continue
        movie["plot"] = meta.get("plot", "")
        movie["original_title"] = meta.get("original_title", "")
        movie["genres"] = meta.get("genres", "")
        movie["country"] = meta.get("country", "")
        movie["duration_text"] = meta.get("duration_text", "")
        movie["duration_seconds"] = meta.get("duration_seconds", 0)
        movie["episode_total"] = meta.get("episode_total", "")
        movie["director"] = meta.get("director", "")
        movie["actors"] = meta.get("actors", "")
        if not movie.get("status") and meta.get("status"):
            movie["status"] = meta["status"]
        if not movie.get("year") and meta.get("year"):
            movie["year"] = meta["year"]
        if not movie.get("thumb") and meta.get("poster"):
            movie["thumb"] = meta["poster"]
    return movies


def get_detail(url, load_all_episodes=False):
    url = normalize_url(url)
    html = request_text(url)
    title = extract_first(html, r'<span\b[^>]*class=["\']title["\'][^>]*itemprop=["\']name["\'][^>]*>(.*?)</span>')
    if not title:
        title = meta_content(html, "property", "og:title").replace("Phim ", "", 1)

    meta = extract_movie_meta_from_html(html, url)
    put_cached_meta_many({url: meta})

    watch_url = parse_watch_url(html, url)
    episode_groups = parse_episode_groups(html, url, load_all=load_all_episodes)
    if not episode_groups and watch_url:
        try:
            watch_html = request_text(watch_url, headers={"Referer": url})
            episode_groups = parse_episode_groups(watch_html, watch_url, load_all=load_all_episodes)
        except ScraperError:
            pass

    return {
        "title": clean_text(title) or "Phim",
        "original_title": meta["original_title"],
        "poster": meta["poster"],
        "plot": meta["plot"],
        "watch_url": watch_url,
        "episode_groups": episode_groups,
        "status": meta["status"],
        "duration": meta["duration_text"],
        "duration_text": meta["duration_text"],
        "duration_seconds": meta["duration_seconds"],
        "episode_total": meta["episode_total"],
        "director": meta["director"],
        "country": meta["country"],
        "genres": meta["genres"],
        "actors": meta["actors"],
        "year": meta["year"],
    }


def extract_first(html, pattern):
    match = re.search(pattern, html, re.S | re.I)
    return clean_text(match.group(1)) if match else ""


def parse_detail_fields(html):
    fields = {}
    for match in re.finditer(r"<dt>(.*?)</dt>\s*<dd\b[^>]*>(.*?)</dd>", html, re.S | re.I):
        key = clean_text(match.group(1)).rstrip(":")
        value = clean_text(match.group(2))
        if key and value:
            fields[key] = value
    return fields


def parse_plot(html):
    match = re.search(
        r'<div\b[^>]*class=["\']tabs-content["\'][^>]*id=["\']info-film["\'][^>]*>.*?'
        r'<div\b[^>]*class=["\']tab["\'][^>]*>\s*<div\b[^>]*>(.*?)</div>\s*</div>',
        html,
        re.S | re.I,
    )
    return clean_text(match.group(1)) if match else ""


def parse_watch_url(html, page_url):
    match = re.search(r'<a\b[^>]*class=["\'][^"\']*\bbtn-stream-link\b[^"\']*["\'][^>]*href=["\']([^"\']+)["\']', html, re.I)
    if match:
        return normalize_url(match.group(1), page_url)
    match = re.search(r'<a\b[^>]*class=["\'][^"\']*\badspruce-streamlink\b[^"\']*["\'][^>]*href=["\']([^"\']+)["\']', html, re.I)
    return normalize_url(match.group(1), page_url) if match else ""


def parse_episode_groups(html, page_url, load_all=False):
    ajax_endpoint = parse_ajax_episode_endpoint(html)
    groups = []
    pattern = (
        r'<div\b[^>]*class=["\']server-episode-block["\'][^>]*>(.*?)</div>\s*'
        r'<div\b[^>]*class=["\'][^"\']*\bepisodes\b[^"\']*["\'][^>]*>\s*'
        r'(<div\b[^>]*class=["\'][^"\']*\bjs-episode-list\b[^"\']*["\'][^>]*>)(.*?)</div>'
    )

    for match in re.finditer(pattern, html, re.S | re.I):
        raw_title = clean_server_title(match.group(1))
        list_tag = match.group(2)
        list_html = match.group(3)
        raw_server_key = attr(list_tag, "data-server") or raw_title
        server_key = normalize_server_key(raw_server_key) or raw_title
        loaded = safe_int(attr(list_tag, "data-loaded"))
        total = safe_int(attr(list_tag, "data-total"))
        endpoint = attr(list_tag, "data-endpoint") or ajax_endpoint
        episodes = parse_episode_links(list_html, page_url)

        if load_all and endpoint and raw_server_key and loaded and total and loaded < total:
            episodes.extend(fetch_more_episodes(endpoint, raw_server_key, loaded, total, page_url))

        episodes = sort_episodes_newest_first(dedupe_episodes(episodes))
        if episodes:
            groups.append({
                "title": raw_title or clean_server_name(server_key),
                "server": server_key,
                "episodes": episodes,
                "loaded": len(episodes),
                "total": total or len(episodes),
            })
    return groups


def parse_ajax_episode_endpoint(html):
    match = re.search(r'id=["\']movie-episode-state["\'][^>]*data-endpoint=["\']([^"\']+)["\']', html, re.I)
    if not match:
        match = re.search(r'data-endpoint=["\']([^"\']+/ajax/episodes/[^"\']+)/state["\']', html, re.I)
    if not match:
        return ""
    endpoint = normalize_url(match.group(1))
    return endpoint[:-6] if endpoint.endswith("/state") else endpoint


def parse_episode_links(html, page_url):
    episodes = []
    for match in re.finditer(r"<a\b[^>]*href=[\"']([^\"']+)[\"'][^>]*>(.*?)</a>", html, re.S | re.I):
        url = normalize_url(match.group(1), page_url)
        title = clean_text(match.group(2)) or clean_text(attr(match.group(0), "title"))
        if url and is_site_url(url) and title:
            episodes.append({"title": title, "url": url})
    return episodes


def fetch_more_episodes(endpoint, server_key, loaded, total, referer):
    episodes = []
    offset = loaded
    pages = 0
    while offset < total and pages < 25:
        pages += 1
        params = {
            "server": server_key,
            "offset": str(offset),
            "limit": "200",
        }
        url = endpoint + "?" + urlencode(params)
        payload = request_json(url, headers={
            "Referer": referer,
            "Accept": "application/json",
            "X-Requested-With": "XMLHttpRequest",
        })
        chunk = payload.get("episodes") or []
        for item in chunk:
            name = item.get("name")
            title = "Tập %s" % name if name is not None and not str(name).lower().startswith("tập") else str(name)
            episodes.append({"title": clean_text(title), "url": normalize_url(item.get("url"), endpoint)})
        new_loaded = safe_int(payload.get("loaded"))
        if new_loaded <= offset:
            offset += len(chunk)
        else:
            offset = new_loaded
        total = safe_int(payload.get("total")) or total
        if not payload.get("has_more") or not chunk:
            break
    return episodes


def dedupe_episodes(episodes):
    result = []
    seen = set()
    for episode in episodes:
        url = episode.get("url")
        if not url or url in seen:
            continue
        seen.add(url)
        result.append(episode)
    return result


def sort_episodes_newest_first(episodes):
    return sorted(episodes, key=episode_sort_key, reverse=True)


def sort_episodes_ascending(episodes):
    return sorted(episodes, key=episode_sort_key)


def episode_sort_key(episode):
    text = "%s %s" % (episode.get("title", ""), episode.get("url", ""))
    numbers = re.findall(r"\d+(?:\.\d+)?", text)
    if not numbers:
        return 0.0
    try:
        return float(numbers[0])
    except ValueError:
        return 0.0


def clean_server_title(value):
    text = clean_text(value)
    text = re.sub(r"^Danh sách\s+Server\s+", "", text, flags=re.I)
    text = text.strip(" :")
    return clean_server_name(text)


def normalize_server_key(value):
    return re.sub(r"\s+", " ", str(value or "")).strip()


def clean_server_name(value):
    text = clean_text(value)
    text = re.sub(r"^[a-z](?=[A-ZÀ-Ỵ])", "", text)
    return text.strip(" :") or "Server"


def language_label(value):
    text = clean_server_name(value)
    plain = remove_vietnamese_marks(text).lower()
    if "long tieng" in plain:
        return "Lồng tiếng"
    if "thuyet minh" in plain:
        return "Thuyết minh"
    if "engsub" in plain:
        return "Phụ đề Anh"
    if "vietsub" in plain or "phu de" in plain:
        return "Phụ đề"
    if "nosub" in plain or "raw" in plain:
        return "Bản gốc"
    return "Bản phát"


def display_group_title(group):
    title = clean_server_name(group.get("title") or group.get("server") or "")
    label = language_label("%s %s" % (group.get("title", ""), group.get("server", "")))
    total = group.get("total") or len(group.get("episodes") or [])
    title = "[%s] %s" % (label, title or label)
    return "%s (%s tập)" % (title, total)


def remove_vietnamese_marks(value):
    source = "àáạảãâầấậẩẫăằắặẳẵèéẹẻẽêềếệểễìíịỉĩòóọỏõôồốộổỗơờớợởỡùúụủũưừứựửữỳýỵỷỹđ"
    target = "aaaaaaaaaaaaaaaaaeeeeeeeeeeeiiiiiooooooooooooooooouuuuuuuuuuuyyyyyd"
    text = str(value or "")
    for src, dst in zip(source, target):
        text = text.replace(src, dst).replace(src.upper(), dst.upper())
    return text


def safe_int(value):
    try:
        return int(value)
    except (TypeError, ValueError):
        return 0


def get_episode_sources(episode_url):
    episode_url = normalize_url(episode_url)
    html = request_text(episode_url, headers={"Referer": BASE_URL + "/"})
    decoded_links = decode_site_stream_links(html)
    sources = []

    for match in re.finditer(r'<a\b[^>]*class=["\'][^"\']*\bstreaming-server\b[^"\']*["\'][^>]*>(.*?)</a>', html, re.S | re.I):
        tag = match.group(0)
        server_id = attr(tag, "data-id")
        source_type = attr(tag, "data-type") or "embed"
        name = clean_text(match.group(1)) or server_id or "Server"
        link = attr(tag, "data-link") or decoded_links.get(server_id, "") or attr(tag, "href")
        if not link:
            continue
        resolved_kind = guess_stream_kind(link, source_type)
        sources.append({
            "id": server_id,
            "name": name,
            "type": source_type,
            "url": normalize_url(link, episode_url),
            "kind": resolved_kind,
        })

    if not sources:
        raise ScraperError("Không tìm thấy server phát cho tập này.")
    return sources


def decode_site_stream_links(html):
    salt_match = re.search(r'const\s+_0xS\s*=\s*["\']([^"\']*)["\']', html)
    salt = salt_match.group(1) if salt_match else ""
    if not salt:
        return {}

    combined = {}
    data_match = re.search(r"const\s+_0xData\s*=\s*(\{.*?\});", html, re.S)
    if data_match:
        try:
            combined.update(json.loads(data_match.group(1)))
        except ValueError:
            pass

    for encoded in re.findall(r'atob\(["\']([A-Za-z0-9+/=]+)["\']\)', html):
        try:
            decoded = base64.b64decode(encoded).decode("utf-8")
            payload = json.loads(decoded)
        except Exception:
            continue
        if isinstance(payload, dict) and all(isinstance(v, list) for v in payload.values()):
            combined.update(payload)

    links = {}
    for server_id, chunks in combined.items():
        if not isinstance(chunks, list):
            continue
        joined = "".join(str(part) for part in chunks)[::-1].replace(salt, "")
        try:
            padding = "=" * (-len(joined) % 4)
            link = base64.b64decode((joined + padding).encode("utf-8")).decode("utf-8")
        except Exception:
            continue
        if link.startswith("http"):
            links[str(server_id)] = link
    return links


def guess_stream_kind(link, source_type=""):
    lower = (link or "").lower()
    if ".m3u8" in lower:
        return "hls"
    if ".mp4" in lower or "tiktokcdn.com" in lower:
        return "mp4"
    if "play.streamxemphimhd.site" in lower:
        return "hls"
    if "tiktok.phimhdc.com" in lower:
        return "auto"
    if "opstream" in lower:
        return "hls"
    return source_type or "embed"


def is_supported_source(source):
    lower = (source.get("url") or "").lower()
    kind = (source.get("kind") or "").lower()
    if kind in ("hls", "mp4"):
        return True
    return any(host in lower for host in (
        "play.streamxemphimhd.site",
        "tiktok.phimhdc.com",
        "streamc.xyz",
        "opstream",
        "phimhdc.com/player.php",
    ))


# Nguồn đã xác định KHÔNG phát được từ addon Python thuần hoặc chỉ chứa quảng cáo
# popup: HDC chặn TLS không phải trình duyệt, OP chết upstream, HY(pop) là nguồn
# popup quảng cáo / bị chặn trực tiếp.
UNPLAYABLE_SOURCE_HOSTS = (
    "play.streamxemphimhd.site",  # HDC
    "opstream",                   # OP
    "player.abyssplayer.com",     # HY(pop)
)
AD_SOURCE_KEYWORDS = ("(pop)", "popup", "ads", "quang cao")


def is_unplayable_source(source):
    lower = (source.get("url") or "").lower()
    if any(host in lower for host in UNPLAYABLE_SOURCE_HOSTS):
        return True
    plain_name = remove_vietnamese_marks(source.get("name") or "").lower()
    return any(keyword in plain_name for keyword in AD_SOURCE_KEYWORDS)


def source_subtitle_hint(source, referer):
    name = re.sub(r"[^A-Z0-9]+", "", (source.get("name") or "").upper())
    if not name.startswith("HDC"):
        return "không có phụ đề rời"
    try:
        media_item = resolve_stream(source.get("url", ""), source.get("type", ""), referer)
        subtitles = media_item.get("subtitles") or []
    except ScraperError:
        return "phụ đề rời: chưa kiểm tra được"
    labels = []
    for subtitle in subtitles:
        label = clean_text(subtitle.get("label"))
        if label and label not in labels:
            labels.append(label)
    if labels:
        return "phụ đề rời: %s" % ", ".join(labels)
    return "không thấy phụ đề rời"


def resolve_episode_media(episode_url):
    sources = get_episode_sources(episode_url)
    ordered = [source for source in sources if not is_unplayable_source(source)]
    if not ordered:
        raise ScraperError("Tập này chỉ có nguồn không phát được (HDC/OP/HY).")
    ordered.sort(key=lambda item: priority_index(item["name"]))
    supported = [source for source in ordered if is_supported_source(source)]
    ordered = supported or ordered
    last_error = None
    for source in ordered:
        try:
            return validate_media(resolve_stream(source["url"], source.get("type", ""), episode_url))
        except ScraperError as exc:
            last_error = exc
            continue
    if last_error:
        raise last_error
    raise ScraperError("Không có server phát khả dụng.")


def priority_index(name):
    upper = re.sub(r"[^A-Z0-9]+", "", (name or "").upper())
    for index, key in enumerate(STREAM_PRIORITY):
        if upper == key:
            return index
    for index, key in enumerate(STREAM_PRIORITY):
        if upper.startswith(key):
            return index + 0.5
    return len(STREAM_PRIORITY)


def resolve_stream(url, server_type="", referer="", depth=0):
    url = normalize_url(url, referer or BASE_URL + "/")
    if not url:
        raise ScraperError("Link phát không hợp lệ.")
    if depth > 3:
        raise ScraperError("Link phát chuyển hướng quá nhiều lần.")
    wrapped = unwrap_player_media_url(url)
    if wrapped and wrapped != url:
        return resolve_stream(wrapped, server_type=server_type, referer=url, depth=depth + 1)
    lower = url.lower()
    if ".m3u8" in lower:
        return resolve_hls_stream(url, referer or BASE_URL + "/")
    if ".mp4" in lower or "tiktokcdn.com" in lower:
        return media(url, "video/mp4", {"Referer": referer or BASE_URL + "/"})
    if "play.streamxemphimhd.site/video/" in lower:
        return resolve_streamxemphimhd(url, referer)
    if "tiktok.phimhdc.com/" in lower:
        return resolve_tiktok_phimhdc(url, referer)
    if "streamc.xyz/" in lower:
        return resolve_streamc(url, referer)
    return resolve_generic_embed(url, referer)


def _pick_best_hls_variant(master_text, base_url):
    best_url = ""
    best_bw = -1
    pending_bw = 0
    for raw_line in (master_text or "").splitlines():
        line = raw_line.strip()
        if not line:
            continue
        if line.upper().startswith("#EXT-X-STREAM-INF:"):
            bw_match = re.search(r"\bBANDWIDTH=(\d+)", line, re.I)
            pending_bw = int(bw_match.group(1)) if bw_match else 0
            continue
        if not line.startswith("#"):
            candidate = normalize_url(line, base_url)
            if candidate and (not best_url or pending_bw >= best_bw):
                best_url = candidate
                best_bw = pending_bw
            pending_bw = 0
    return best_url


def resolve_hls_stream(url, referer):
    headers = {"Referer": referer or BASE_URL + "/"}
    text = request_text(url, headers=headers)
    if "#EXTM3U" not in text:
        raise ScraperError("Server không trả về playlist HLS hợp lệ.")

    media_url = url
    media_text = text
    if "#EXT-X-STREAM-INF" in text:
        if "#EXT-X-MEDIA" in text:
            proxy_base = ready_proxy_base()
            return {
                "url": "%s/hls.m3u8?%s" % (proxy_base, urlencode({
                    "u": proxy_token(url),
                    "r": proxy_token(referer or BASE_URL + "/"),
                })),
                "mime": "application/vnd.apple.mpegurl",
            }
        variant_url = _pick_best_hls_variant(text, url)
        if not variant_url:
            raise ScraperError("Playlist HLS không có luồng phát.")
        media_url = variant_url
        media_text = request_text(media_url, headers=headers)
        if "#EXTM3U" not in media_text:
            raise ScraperError("Playlist HLS con không hợp lệ.")

    clean_playlist = strip_hls_ads(media_text, media_url)
    clean_playlist = absolutize_playlist_urls(clean_playlist, media_url)

    first_seg = next(
        (ln.strip() for ln in clean_playlist.splitlines() if ln.strip() and not ln.strip().startswith("#")),
        "",
    )
    if not first_seg:
        raise ScraperError("Playlist HLS không có dữ liệu phát.")

    encrypted = any(
        ln.strip().upper().startswith("#EXT-X-KEY:") and "METHOD=NONE" not in ln.strip().upper()
        for ln in clean_playlist.splitlines()
    )

    output_dir = proxy_workspace_dir()
    digest = hashlib.md5(media_url.encode("utf-8")).hexdigest()[:16]
    output_path = os.path.join(output_dir, "hd-%s.m3u8" % digest)

    try:
        proxy_base = ready_proxy_base()
    except ScraperError:
        proxy_base = ""

    if proxy_base:
        clean_playlist = proxy_streamc_playlist(clean_playlist, referer or BASE_URL + "/", proxy_base)
        _write_text_atomic(output_path, clean_playlist)
        local_url = local_proxy_playlist_url(output_path, proxy_base)
        validate_hls(local_url, {})
        return {
            "url": local_url,
            "mime": "application/vnd.apple.mpegurl",
            "validated": True,
        }

    _, seg_type, seg_data = request_media_chunk(first_seg, {"User-Agent": USER_AGENT}, 1024)
    if not looks_like_media_data(seg_data, seg_type, encrypted=encrypted):
        raise ScraperError("Playlist HLS có segment không phải dữ liệu video Kodi hỗ trợ.")
    _write_text_atomic(output_path, clean_playlist)
    return {
        "url": output_path,
        "mime": "application/vnd.apple.mpegurl",
        "validated": True,
    }


def unwrap_player_media_url(url):
    parsed = urlparse(url)
    query = parse_qs(parsed.query)
    for key in ("link", "url", "file", "source"):
        value = (query.get(key) or [""])[0]
        if value and re.search(r"\.(?:m3u8|mp4)(?:\?|$)", value, re.I):
            return normalize_url(value, url)
    return ""


def media(url, mime="", headers=None):
    headers = headers or {}
    headers.setdefault("User-Agent", USER_AGENT)
    return {
        "url": url_with_headers(url, headers),
        "mime": mime or media_mime_type(url),
    }


def media_mime_type(url):
    return "application/vnd.apple.mpegurl" if ".m3u8" in (url or "").lower() else "video/mp4"


def validate_media(media_item):
    # NC is checked before its playlist is rewritten for the local proxy.
    if media_item.get("validated"):
        return media_item
    value = media_item.get("url") or ""
    raw_url, headers = split_kodi_url(value)
    headers.update(media_item.get("headers") or {})
    mime = (media_item.get("mime") or "").lower()
    if not raw_url:
        raise ScraperError("Server không trả về URL media.")
    if os.path.isfile(raw_url) or "mpegurl" in mime or ".m3u8" in raw_url.lower():
        validate_hls(raw_url, headers)
    else:
        _, content_type, data = request_media_chunk(raw_url, headers, 65536)
        if not looks_like_media_data(data, content_type):
            raise ScraperError("Server trả về dữ liệu không phải video.")
    return media_item


def split_kodi_url(value):
    raw_url, separator, encoded_headers = (value or "").partition("|")
    return raw_url, dict(parse_qsl(encoded_headers)) if separator else {}


def validate_hls(url, headers):
    current_url = url
    current_headers = dict(headers or {})
    for _ in range(3):
        if os.path.isfile(current_url):
            with open(current_url, "rb") as handle:
                data = handle.read(262144)
            content_type = "application/vnd.apple.mpegurl"
        else:
            _, content_type, data = request_media_chunk(current_url, current_headers, 262144)
        if b"#EXTM3U" not in data[:4096]:
            raise ScraperError("Server không trả về playlist HLS hợp lệ.")
        text = data.decode("utf-8", "ignore")
        uris = [line.strip() for line in text.splitlines() if line.strip() and not line.startswith("#")]
        if not uris:
            raise ScraperError("Playlist HLS không có dữ liệu phát.")
        child_url, child_headers = split_kodi_url(uris[0])
        if not urlparse(child_url).scheme:
            child_url = normalize_url(child_url, current_url)
        merged_headers = dict(current_headers)
        merged_headers.update(child_headers)
        _, child_type, child_data = request_media_chunk(child_url, merged_headers, 65536)
        if b"#EXTM3U" in child_data[:4096]:
            current_url = child_url
            current_headers = merged_headers
            continue
        encrypted = any(
            ln.strip().upper().startswith("#EXT-X-KEY:") and "METHOD=NONE" not in ln.strip().upper()
            for ln in text.splitlines()
        )
        for index in sample_playlist_indexes(len(uris)):
            if index == 0:
                segment_type, segment_data = child_type, child_data
            else:
                segment_url, segment_headers = split_kodi_url(uris[index])
                if not urlparse(segment_url).scheme:
                    segment_url = normalize_url(segment_url, current_url)
                final_headers = dict(current_headers)
                final_headers.update(segment_headers)
                _, segment_type, segment_data = request_media_chunk(segment_url, final_headers, 65536)
            if not looks_like_media_data(segment_data, segment_type, encrypted=encrypted):
                raise ScraperError("Playlist HLS có segment không phải dữ liệu video Kodi hỗ trợ.")
        return
    raise ScraperError("Playlist HLS lồng quá nhiều cấp.")


def sample_playlist_indexes(length):
    # Checking a single segment is enough to detect an HTML/error response
    # while keeping playback start-up fast.  Sampling three segments meant
    # three serial round-trips on the UI thread before Kodi began playing.
    return (0,)


def request_media_chunk(url, headers, limit):
    final_headers = dict(headers or {})
    final_headers.setdefault("User-Agent", USER_AGENT)
    final_headers.setdefault("Range", "bytes=0-%s" % max(0, limit - 1))
    try:
        request = Request(url, headers=final_headers)
        with HTTP_OPENER.open(request, timeout=12) as response:
            return getattr(response, "status", 200), response.headers.get("Content-Type", ""), response.read(limit)
    except HTTPError as exc:
        raise ScraperError("HTTP %s khi kiểm tra media" % exc.code)
    except URLError as exc:
        raise ScraperError("Không kết nối được media: %s" % exc.reason)
    except Exception as exc:
        raise ScraperError("Không kiểm tra được media: %s" % exc)


def looks_like_media_data(data, content_type="", encrypted=False):
    data = data or b""
    lower_type = (content_type or "").lower()
    if data.startswith((b"\x89PNG\r\n\x1a\n", b"\xff\xd8\xff", b"GIF87a", b"GIF89a")):
        return False
    stripped = data.lstrip().lower()
    if stripped.startswith((b"<!doctype html", b"<html", b"{", b"[")):
        return False
    if data.startswith(b"\x47") or data.startswith(b"\x1a\x45\xdf\xa3") or data.startswith(b"ID3"):
        return True
    if len(data) >= 12 and (data[4:8] == b"ftyp" or b"moof" in data[:64]):
        return True
    if len(data) >= 2 and data[0] == 0xFF and data[1] & 0xF0 == 0xF0:
        return True
    if encrypted and data and not lower_type.startswith(("text/", "image/")):
        return True
    return lower_type.startswith(("video/", "audio/", "application/octet-stream"))


def add_subtitles(media_item, subtitles):
    if subtitles:
        media_item["subtitles"] = subtitles
    return media_item


def url_with_headers(url, headers):
    clean_headers = {key: value for key, value in headers.items() if value}
    if not clean_headers:
        return url
    separator = "&" if "|" in url else "|"
    return url + separator + urlencode(clean_headers)


def resolve_streamxemphimhd(url, referer):
    parsed = urlparse(url)
    video_id = parsed.path.rstrip("/").split("/")[-1]
    if not video_id:
        raise ScraperError("Không đọc được mã video HDC.")

    base = "%s://%s" % (parsed.scheme, parsed.netloc)
    player_html = request_text(url, headers={"Referer": referer or BASE_URL + "/"})
    subtitles = extract_player_subtitles(player_html, url)

    # FirePlayer giờ yêu cầu guard token: POST guard_issue.php rồi gửi
    # fp_guard (body) + X-FP-Guard (header) kèm lệnh getVideo.
    guard_headers = {
        "Referer": url,
        "Origin": base,
        "Accept": "application/json,text/javascript,*/*;q=0.01",
        "X-Requested-With": "XMLHttpRequest",
        "Sec-Fetch-Site": "same-origin",
    }
    guard_token = ""
    try:
        guard_payload = request_json(base + "/player/guard_issue.php", data={
            "t": str(int(time.time() * 1000)),
        }, headers=guard_headers, method="POST", timeout=12)
        guard_token = guard_payload.get("token") or ""
    except ScraperError:
        guard_token = ""

    api_data = {"hash": video_id, "r": referer or BASE_URL + "/"}
    if guard_token:
        api_data["fp_guard"] = guard_token
    payload = request_json("%s/player/index.php?data=%s&do=getVideo" % (base, quote(video_id)), data=api_data, headers=dict(
        guard_headers, **({"X-FP-Guard": guard_token} if guard_token else {})
    ), method="POST")

    secured = payload.get("securedLink") or payload.get("videoSource")
    if secured:
        return add_subtitles(media(secured, media_mime_type(secured), {
            "Referer": url,
            "Origin": base,
        }), subtitles)

    sources = payload.get("videoSources") or []
    if isinstance(sources, dict):
        sources = [sources]
    for source in sources:
        file_url = source.get("file") or source.get("src") or source.get("url")
        if file_url and file_url.startswith("http"):
            return add_subtitles(media(file_url, media_mime_type(file_url), {"Referer": url}), subtitles)
    raise ScraperError("Server HDC chưa trả về link phát.")


def extract_player_subtitles(html, player_url):
    subtitles = []
    seen = set()

    match = re.search(r'playerjsSubtitle\s*=\s*"([^"]*)"', html, re.S)
    if match:
        value = html_lib.unescape(match.group(1)).replace("\\/", "/")
        for label, url in re.findall(r"\[([^\]]+)\](https?://[^,\s]+)", value):
            add_subtitle(subtitles, seen, label, url, player_url)

    normalized = html.replace("\\/", "/")
    for match in re.finditer(
        r'\{[^{}]*"kind"\s*:\s*"captions"[^{}]*"file"\s*:\s*"([^"]+)"[^{}]*"label"\s*:\s*"([^"]*)"',
        normalized,
        re.I,
    ):
        add_subtitle(subtitles, seen, match.group(2), match.group(1), player_url)
    for match in re.finditer(
        r'\{[^{}]*"file"\s*:\s*"([^"]+)"[^{}]*"kind"\s*:\s*"captions"[^{}]*"label"\s*:\s*"([^"]*)"',
        normalized,
        re.I,
    ):
        add_subtitle(subtitles, seen, match.group(2), match.group(1), player_url)

    subtitles.sort(key=lambda item: subtitle_priority(item.get("label", "")))
    return subtitles


def add_subtitle(subtitles, seen, label, url, referer):
    url = normalize_url(url, referer)
    if not url or url in seen:
        return
    seen.add(url)
    subtitles.append({
        "label": clean_text(label) or "Subtitle",
        "url": url,
        "referer": referer,
    })


def subtitle_priority(label):
    plain = remove_vietnamese_marks(label).lower()
    if "vietnamese" in plain or "viet" in plain or plain == "vi":
        return 0
    if "english" in plain or plain == "en":
        return 1
    return 2


def fhdc_request_headers(referer, accept="text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"):
    return {
        "User-Agent": USER_AGENT,
        "Accept": accept,
        "Accept-Language": "vi,en-US;q=0.9,en;q=0.8",
        "Sec-Fetch-Dest": "iframe",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Site": "same-origin",
        "Referer": referer,
    }


def resolve_tiktok_phimhdc(url, referer):
    # 09/2026 - 11/2026: request trần tới embed bị chặn 403; cần đủ header
    # navigation của iframe. Player thật (edgeplayer, delivery=direct) lấy
    # play_guard token rồi gọi /api/master-inline để nhận manifest HLS inline;
    # segment là PNG (chunk stEg mới hoặc iTXt cũ) phải giải mã qua proxy cục bộ.
    embed_html = request_text(url, headers=fhdc_request_headers(url))
    iframe = re.search(r"<iframe\b[^>]*src=[\"']([^\"']+)[\"']", embed_html, re.I)
    edge_url = normalize_url(iframe.group(1), url) if iframe else url
    query = parse_qs(urlparse(edge_url).query)
    key = (query.get("key") or [""])[0]
    if not key:
        raise ScraperError("Không đọc được key của server FHDC.")

    base = "%s://%s" % (urlparse(edge_url).scheme, urlparse(edge_url).netloc)
    json_headers = fhdc_request_headers(edge_url, "application/json")
    guard = request_json(base + "/api/js-token?" + urlencode({
        "name": "play_guard",
        "jobId": key,
    }), headers=json_headers)
    token = guard.get("token") or ""
    if not token:
        raise ScraperError("Server FHDC từ chối cấp token phát.")

    api_headers = dict(json_headers)
    api_headers.update({
        "Content-Type": "application/json",
        "Origin": base,
        "X-Requested-With": "XMLHttpRequest",
        "X-Play-Guard": token,
    })
    payload = request_json(base + "/api/master-inline", data=json.dumps({
        "jobId": key,
        "delivery": "direct",
        "playGuard": token,
    }).encode("utf-8"), headers=api_headers, method="POST")
    manifest = payload.get("manifest") or ""
    if "#EXTM3U" not in manifest:
        raise ScraperError("Server FHDC không trả về playlist.")

    manifest = strip_hls_ads(manifest, edge_url)
    proxy_base = ready_proxy_base()
    playlist = proxy_fhdc_manifest(manifest, edge_url, proxy_base)
    output_dir = proxy_workspace_dir()
    output_path = os.path.join(output_dir, "fhdc-%s.m3u8" % safe_path_token(key))
    _write_text_atomic(output_path, playlist)
    playlist_url = local_proxy_playlist_url(output_path, proxy_base)
    validate_hls(playlist_url, {})
    return {
        "url": playlist_url,
        "mime": "application/vnd.apple.mpegurl",
        "validated": True,
    }


def _write_text_atomic(path, content):
    tmp_path = path + ".tmp"
    with open(tmp_path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(content)
    os.replace(tmp_path, path)


def _ensure_vod_endlist(lines, original_playlist):
    upper = (original_playlist or "").upper()
    if "#EXT-X-PLAYLIST-TYPE:EVENT" in upper:
        return lines
    if not any(ln.strip().upper().startswith("#EXT-X-ENDLIST") for ln in lines):
        lines.append("#EXT-X-ENDLIST")
    return lines


def proxy_fhdc_manifest(manifest, referer, proxy_base):
    lines = []
    pending_alts = None
    for line in (manifest or "").splitlines():
        stripped = line.strip()
        if stripped.startswith("#HDC-SHOP-ALT:"):
            raw_json = stripped[len("#HDC-SHOP-ALT:"):].strip()
            try:
                parsed = json.loads(raw_json)
                if isinstance(parsed, list):
                    pending_alts = [
                        normalize_url(item, referer)
                        for item in parsed
                        if isinstance(item, str) and item.strip()
                    ]
            except ValueError:
                pending_alts = None
            continue
        if stripped and not stripped.startswith("#"):
            abs_seg = normalize_url(stripped, referer)
            params = {
                "u": proxy_token(abs_seg),
                "r": proxy_token(referer),
            }
            if pending_alts:
                alts = [item for item in pending_alts if item and item != abs_seg]
                if alts:
                    params["a"] = proxy_token("\n".join(alts))
            pending_alts = None
            line = "%s/fhdc.ts?%s" % (proxy_base, urlencode(params))
        lines.append(line)
    _ensure_vod_endlist(lines, manifest)
    return "\n".join(lines).strip() + "\n"


def open_streamc_client():
    return httpx.Client(http2=True, timeout=20, headers={
        "User-Agent": USER_AGENT,
        "Accept": "application/json, text/plain, */*",
        "Accept-Language": "vi,en-US;q=0.9,en;q=0.8",
    })


def streamc_bootstrap_grant(client, url, origin):
    """POST bootstrap API mới của player streamc.xyz (09/2026) để nhận grant
    mã hoá AES-GCM chứa URL playlist đã ký sẵn (preissued)."""
    headers = {
        "Content-Type": "application/json",
        "Referer": BASE_URL + "/",
        "Origin": origin,
    }
    common_body = {
        "referrer": BASE_URL + "/",
        "frame_origins": [BASE_URL],
        "playlist_format": "aesgcm-v2",
        "pretty_url": True,
        "path_chunks": True,
    }
    bootstrap_body = dict(common_body)
    bootstrap_body.update({"action": "bootstrap", "request_grant": True, "bootstrap_format": "aesgcm-v1"})
    resp = client.post(url, headers=headers, json=bootstrap_body)
    if resp.status_code == 429:
        raise ScraperError("Server NC giới hạn tần suất, thử lại sau ít phút.")
    resp.raise_for_status()

    envelope = resp.json()
    if envelope.get("format") == "aesgcm-v1":
        associated_data = ("stream-bootstrap-v1\n" + url).encode("utf-8")
        key = hashlib.sha256(associated_data).digest()
        plaintext = aesgcm_decrypt(key, bytes.fromhex(envelope["iv"]), base64.b64decode(envelope["data"]), associated_data)
        grant = json.loads(plaintext.decode("utf-8"))
    else:
        grant = envelope

    video_hash = grant.get("video") or ""
    playlist_url = (grant.get("preissued") or {}).get("playlist") or ""
    if not playlist_url:
        if grant.get("turnstileEnabled"):
            raise ScraperError("Server NC bật xác minh Turnstile, chưa hỗ trợ tự động.")
        issue_body = dict(common_body)
        issue_body.update({"action": "issue", "bootstrap": grant.get("bootstrap", ""), "turnstile_response": ""})
        resp = client.post(url, headers=headers, json=issue_body)
        resp.raise_for_status()
        playlist_url = resp.json().get("playlist") or ""
    return playlist_url, video_hash


def resolve_streamc(url, referer):
    try:
        return _resolve_streamc_impl(url, referer)
    except ScraperError:
        raise
    except httpx.HTTPError as exc:
        raise ScraperError("Không kết nối được server NC: %s" % exc)
    except Exception as exc:
        raise ScraperError("Lỗi không xác định khi đọc player NC: %s" % exc)


def _resolve_streamc_impl(url, referer):
    parsed = urlparse(url)
    video_hash = (parse_qs(parsed.query).get("hash") or [""])[0]

    mirror_urls = [url]
    if video_hash:
        for host in NC_MIRROR_HOSTS:
            candidate = "https://%s/embed.php?hash=%s" % (host, quote(video_hash))
            if candidate not in mirror_urls:
                mirror_urls.append(candidate)

    active_url = url
    playlist_url = ""
    last_error = None
    client = open_streamc_client()
    try:
        for candidate_url in mirror_urls:
            cand_parsed = urlparse(candidate_url)
            cand_origin = "%s://%s" % (cand_parsed.scheme, cand_parsed.netloc)
            try:
                grant_playlist, grant_hash = streamc_bootstrap_grant(client, candidate_url, cand_origin)
                if grant_playlist:
                    active_url = candidate_url
                    playlist_url = grant_playlist
                    if grant_hash and not video_hash:
                        video_hash = grant_hash
                    break
            except Exception as exc:
                last_error = exc
                continue

        if not playlist_url:
            # Fallback: flow cũ (data-obf trên trang embed) qua HTTP/2.
            log_text = "Bootstrap NC thất bại, thử flow cũ: %s" % last_error
            try:
                import xbmc
                xbmc.log("[PhimHDCSS] %s" % log_text, xbmc.LOGWARNING)
            except ImportError:
                print(log_text)
            try:
                embed_html = client.get(url, headers={"Referer": referer or BASE_URL + "/"}).text
            except Exception:
                embed_html = ""
            match = re.search(r'data-obf=["\']([^"\']+)', embed_html, re.I)
            if not match:
                if isinstance(last_error, ScraperError):
                    raise last_error
                raise ScraperError("Không đọc được dữ liệu player NC.")
            try:
                encoded = match.group(1)
                outer = json.loads(base64.b64decode(encoded + "=" * (-len(encoded) % 4)).decode("utf-8"))
                stream_token = outer.get("sUb") or ""
                video_hash = outer.get("hD") or video_hash
            except ScraperError:
                raise
            except Exception:
                raise ScraperError("Dữ liệu player NC không hợp lệ.")
            playlist_url = urljoin(url, stream_token)

        if not playlist_url:
            raise ScraperError("Player NC không trả về playlist.")
        if not video_hash:
            raise ScraperError("Player NC thiếu token phát.")

        playlist_resp = client.get(playlist_url, headers={
            "Referer": active_url,
            "Accept": "application/vnd.apple.mpegurl,*/*;q=0.8",
        })
        if playlist_resp.status_code >= 400:
            raise ScraperError("HTTP %s khi tải playlist NC." % playlist_resp.status_code)
        encrypted = playlist_resp.text
    finally:
        client.close()

    playlist = decrypt_streamc_playlist(encrypted, video_hash)
    playlist = strip_hls_ads(playlist, playlist_url)
    playlist = absolutize_playlist_urls(playlist, playlist_url)

    proxy_base = ready_proxy_base()
    playlist = proxy_streamc_playlist(playlist, active_url, proxy_base)
    output_dir = proxy_workspace_dir()
    output_path = os.path.join(output_dir, "nc-%s.m3u8" % safe_path_token(video_hash))
    _write_text_atomic(output_path, playlist)

    local_url = local_proxy_playlist_url(output_path, proxy_base)
    # Kiểm tra trực tiếp qua proxy HTTP/2 cục bộ thay vì urllib trực tiếp (bị 403).
    validate_hls(local_url, {})
    return {
        "url": local_url,
        "mime": "application/vnd.apple.mpegurl",
        "validated": True,
    }


def decrypt_streamc_playlist(encrypted, video_hash):
    iv_match = re.search(r"#ENC-AESGCM;iv=([0-9a-fA-F]+)", encrypted or "")
    payload = next((line.strip() for line in (encrypted or "").splitlines() if line.strip() and not line.startswith("#")), "")
    if not iv_match or not payload:
        if "#EXTM3U" in (encrypted or ""):
            return encrypted
        raise ScraperError("Player NC không trả về playlist hợp lệ.")
    try:
        key = hmac.new(b"stream-derive-v1", video_hash.encode("utf-8"), hashlib.sha256).digest()
        plaintext = aesgcm_decrypt(key, bytes.fromhex(iv_match.group(1)), base64.b64decode(payload))
        playlist = plaintext.decode("utf-8")
    except Exception as exc:
        raise ScraperError("Không giải mã được playlist NC: %s" % exc)
    if "#EXTM3U" not in playlist:
        raise ScraperError("Playlist NC sau giải mã không hợp lệ.")
    return playlist


def _rewrite_tag_uri(line, transform):
    return re.sub(r'URI="([^"]+)"', lambda m: 'URI="%s"' % transform(m.group(1)), line)


def absolutize_playlist_urls(playlist, base_url, headers=None):
    lines = []
    for line in (playlist or "").splitlines():
        stripped = line.strip()
        if stripped.startswith("#"):
            if 'URI="' in stripped and (
                stripped.upper().startswith("#EXT-X-KEY:")
                or stripped.upper().startswith("#EXT-X-MAP:")
            ):
                line = _rewrite_tag_uri(
                    line,
                    lambda u: url_with_headers(normalize_url(u, base_url), headers or {}),
                )
        elif stripped:
            line = url_with_headers(normalize_url(stripped, base_url), headers or {})
        lines.append(line)
    return "\n".join(lines).strip() + "\n"


def proxy_streamc_playlist(playlist, referer, proxy_base):
    lines = []
    for line in (playlist or "").splitlines():
        stripped = line.strip()
        if stripped.startswith("#"):
            if 'URI="' in stripped and (
                stripped.upper().startswith("#EXT-X-KEY:")
                or stripped.upper().startswith("#EXT-X-MAP:")
            ):
                line = _rewrite_tag_uri(
                    line,
                    lambda u: local_proxy_segment_url(u, referer, proxy_base),
                )
        elif stripped:
            line = local_proxy_segment_url(stripped, referer, proxy_base)
        lines.append(line)
    _ensure_vod_endlist(lines, playlist)
    return "\n".join(lines).strip() + "\n"


def local_proxy_playlist_url(path, proxy_base):
    return "%s/playlist.m3u8?%s" % (
        proxy_base,
        urlencode({"p": proxy_token(path)}),
    )


def local_proxy_segment_url(url, referer, proxy_base):
    return "%s/segment.ts?%s" % (
        proxy_base,
        urlencode({"u": proxy_token(url), "r": proxy_token(referer)}),
    )


def proxy_token(value):
    return base64.urlsafe_b64encode(str(value).encode("utf-8")).decode("ascii").rstrip("=")


def safe_path_token(value):
    return re.sub(r"[^A-Za-z0-9_-]+", "", value or "") or "stream"


def resolve_generic_embed(url, referer):
    current_url = url
    current_referer = referer or BASE_URL + "/"
    for _ in range(3):
        html = request_text(current_url, headers={"Referer": current_referer})
        direct = find_direct_media_url(html)
        if direct:
            return resolve_stream(normalize_url(direct, current_url), referer=current_url, depth=1)
        iframe = re.search(r"<iframe\b[^>]*src=[\"']([^\"']+)[\"']", html, re.I)
        if not iframe:
            break
        current_referer = current_url
        current_url = normalize_url(iframe.group(1), current_url)
    raise ScraperError("Server embed này chưa hỗ trợ phát trực tiếp trong Kodi.")


def find_direct_media_url(html):
    patterns = [
        r'https?://[^"\'<>\s\\]+(?:\.m3u8|\.mp4)(?:\?[^"\'<>\s\\]*)?',
        r'\b(?:const|var|let)\s+(?:url|file|source)\s*=\s*["\']([^"\']+\.(?:m3u8|mp4)[^"\']*)["\']',
        r'["\']file["\']\s*:\s*["\']([^"\']+)["\']',
        r'\bfile\s*:\s*["\']([^"\']+)["\']',
        r'\bsrc\s*:\s*["\']([^"\']+\.(?:m3u8|mp4)[^"\']*)["\']',
    ]
    for pattern in patterns:
        match = re.search(pattern, html, re.I)
        if match:
            candidate = html_lib.unescape(match.group(1) if match.lastindex else match.group(0)).replace("\\/", "/")
            if re.search(r"\.(?:m3u8|mp4)(?:\?|$)", candidate, re.I):
                return candidate
    return ""
