# -*- coding: utf-8 -*-
"""Bo loc quang cao cho playlist HLS (.m3u8) va phu de (.srt / .vtt)."""
from __future__ import absolute_import, unicode_literals

import posixpath
import re
from urllib.parse import urljoin, urlparse


AD_PATH_RE = re.compile(
    r"(?:^|/)(?:v\d+/[0-9a-f]{16,}/segment_\d+|adjump|adsegment|ads|adv|"
    r"preroll|midroll|postroll|quangcao|commercial|sponsor|promo)(?:/|_|\.|$)",
    re.I,
)
AD_HOST_RE = re.compile(
    r"(?:^|\.)(?:ads|adserver|adservice|doubleclick|googlesyndication)\.",
    re.I,
)
CONVERT_SUBDIR_RE = re.compile(r"(?:^|/)convertv\d+/", re.I)

SUBTITLE_AD_RE = re.compile(
    r"(?:nhà cái|cá cược|nạp rút|hoàn trả|truy cập ngay|link vào|tặng thưởng|"
    r"telegram\s*@|(?:https?://)?[a-z0-9-]+\.(?:bet|vip|win|club|fun|casino)\b)",
    re.I,
)

VTT_TIMESTAMP_LINE_RE = re.compile(
    r"((?:\d{1,2}:)?\d{2}:\d{2}[.,]\d{3})\s*-->\s*((?:\d{1,2}:)?\d{2}:\d{2}[.,]\d{3})"
)


def is_ad_segment_url(seg_url, main_host="", main_dir=""):
    """Kiem tra nhanh URL segment co trung mau quang cao hay khong."""
    if not seg_url:
        return False
    parsed = urlparse(seg_url)
    host = (parsed.hostname or "").lower()
    path = parsed.path or ""
    if host and AD_HOST_RE.search(host):
        return True
    if path and AD_PATH_RE.search(path):
        return True
    return False


def _parse_extinf_duration(line):
    raw = line.split(":", 1)[1].split(",", 1)[0].strip()
    try:
        return max(0.0, float(raw))
    except (TypeError, ValueError):
        return 0.0


def _is_header_tag(line):
    upper = line.upper()
    return upper.startswith((
        "#EXTM3U",
        "#EXT-X-VERSION",
        "#EXT-X-TARGETDURATION",
        "#EXT-X-MEDIA-SEQUENCE",
        "#EXT-X-DISCONTINUITY-SEQUENCE",
        "#EXT-X-PLAYLIST-TYPE",
        "#EXT-X-INDEPENDENT-SEGMENTS",
        "#EXT-X-ALLOW-CACHE",
        "#EXT-X-START",
    ))


def _key_method(line):
    match = re.search(r"\bMETHOD=([^,\s]+)", line, re.I)
    return match.group(1).upper() if match else ""


def _seg_dir(abs_url):
    path = urlparse(abs_url).path or ""
    return posixpath.dirname(path) if path else ""


def _seg_host(abs_url):
    return (urlparse(abs_url).hostname or "").lower()


def _is_inside_dir(seg_path, main_dir):
    if not main_dir or main_dir == "/":
        return True
    if seg_path == main_dir:
        return True
    return seg_path.startswith(main_dir.rstrip("/") + "/")


def strip_hls_ads(playlist_text, playlist_url=""):
    """Loai bo cac doan quang cao chen qua #EXT-X-DISCONTINUITY hoac URL quang cao
    nhung giu nguyen cac canh phim that (vi du convertv9/ cung thu muc goc)."""
    text = playlist_text or ""
    if "#EXTM3U" not in text or "#EXT-X-STREAM-INF" in text:
        return text

    lines = text.splitlines()
    header_lines = []
    sections = []
    current_segments = []
    pending_lines = []
    pending_duration = 0.0
    pending_key_none = False
    pending_real_key = False
    active_key = ""
    seen_content = False
    has_endlist = False

    def flush_section():
        nonlocal current_segments
        if current_segments:
            sections.append(current_segments)
            current_segments = []

    for raw_line in lines:
        line = raw_line.strip()
        if not line:
            continue
        upper = line.upper()

        if upper.startswith("#EXT-X-ENDLIST"):
            has_endlist = True
            continue

        if upper.startswith("#EXT-X-DISCONTINUITY") and not upper.startswith("#EXT-X-DISCONTINUITY-SEQUENCE"):
            seen_content = True
            flush_section()
            pending_lines = []
            pending_duration = 0.0
            pending_key_none = False
            pending_real_key = False
            continue

        if line.startswith("#"):
            if not seen_content and _is_header_tag(line):
                header_lines.append(line)
                continue
            seen_content = True
            pending_lines.append(line)
            if upper.startswith("#EXTINF:"):
                pending_duration = _parse_extinf_duration(line)
            elif upper.startswith("#EXT-X-KEY:"):
                method = _key_method(line)
                if method == "NONE":
                    pending_key_none = True
                    active_key = ""
                elif method:
                    pending_real_key = True
                    active_key = line
            continue

        seen_content = True
        abs_url = urljoin(playlist_url, line) if playlist_url else line
        current_segments.append({
            "uri": line,
            "abs_url": abs_url,
            "duration": pending_duration,
            "lines": pending_lines,
            "has_key_none": pending_key_none,
            "has_real_key": pending_real_key,
            "key_state": active_key,
        })
        pending_lines = []
        pending_duration = 0.0
        pending_key_none = False
        pending_real_key = False

    flush_section()

    if not sections:
        return text

    # Buoc 1: Loc segment khop URL quang cao va tinh thong ke thoi luong baseline.
    total_duration = 0.0
    dir_durations = {}
    main_encrypted = False

    cleaned_sections = []
    for sec in sections:
        kept_segs = []
        removed_any = False
        for seg in sec:
            total_duration += seg["duration"]
            if is_ad_segment_url(seg["abs_url"]):
                removed_any = True
                continue
            kept_segs.append(seg)
            host = _seg_host(seg["abs_url"])
            sdir = _seg_dir(seg["abs_url"])
            dir_durations[(host, sdir)] = dir_durations.get((host, sdir), 0.0) + seg["duration"]
            if seg["has_real_key"] or seg["key_state"]:
                main_encrypted = True
        cleaned_sections.append((kept_segs, removed_any))

    if dir_durations:
        main_host, main_dir = max(dir_durations.items(), key=lambda item: item[1])[0]
    else:
        main_host, main_dir = "", ""

    # Buoc 2: Xac dinh section quang cao chen qua heuristic duong dan / domain / key.
    kept_sections = []
    removed_between_prev = False

    for kept_segs, removed_by_regex in cleaned_sections:
        if not kept_segs:
            if removed_by_regex:
                removed_between_prev = True
            continue

        sec_duration = sum(seg["duration"] for seg in kept_segs)
        is_short_insert = (
            total_duration > 120.0
            and sec_duration <= 120.0
            and sec_duration < total_duration * 0.25
        )

        is_ad_sec = False
        if is_short_insert:
            first_seg = kept_segs[0]
            all_diff_host = bool(main_host) and all(
                _seg_host(seg["abs_url"]) and _seg_host(seg["abs_url"]) != main_host
                for seg in kept_segs
            )
            all_outside_dir = bool(main_dir and main_dir != "/") and all(
                not _is_inside_dir(urlparse(seg["abs_url"]).path or "", main_dir)
                for seg in kept_segs
            )
            starts_key_none = (
                first_seg["has_key_none"]
                and not main_encrypted
                and not CONVERT_SUBDIR_RE.search(urlparse(first_seg["abs_url"]).path or "")
            )
            if all_diff_host or all_outside_dir or starts_key_none:
                is_ad_sec = True

        if is_ad_sec:
            removed_between_prev = True
            continue

        kept_sections.append((kept_segs, removed_between_prev))
        removed_between_prev = False

    if not kept_sections:
        return text

    # Buoc 3: Ghep lai playlist sach, loai bo DISCONTINUITY thua.
    output = list(header_lines) if header_lines else ["#EXTM3U"]
    prev_sec = None
    for sec_segs, had_removed_before in kept_sections:
        if prev_sec is not None:
            need_discontinuity = True
            if had_removed_before:
                prev_last = prev_sec[-1]
                curr_first = sec_segs[0]
                prev_in_main_dir = (not main_dir or _seg_dir(prev_last["abs_url"]) == main_dir)
                curr_in_main_dir = (not main_dir or _seg_dir(curr_first["abs_url"]) == main_dir)
                same_key = prev_last["key_state"] == curr_first["key_state"]
                if prev_in_main_dir and curr_in_main_dir and same_key:
                    need_discontinuity = False
            if need_discontinuity:
                output.append("#EXT-X-DISCONTINUITY")

        for seg in sec_segs:
            output.extend(seg["lines"])
            output.append(seg["uri"])
        prev_sec = sec_segs

    if has_endlist:
        output.append("#EXT-X-ENDLIST")
    return "\n".join(output) + "\n"


def _normalize_srt_timestamp(value):
    ts = value.strip().replace(".", ",")
    parts = ts.split(":")
    if len(parts) == 2:
        ts = "00:" + ts
    elif len(parts) == 3 and len(parts[0]) == 1:
        ts = "0" + ts
    return ts


def _clean_cue_text(lines):
    cleaned = []
    for line in lines:
        text = re.sub(r"</?(?:c|v)(?:\.[^>]*)?>", "", line)
        text = re.sub(r"<\d{2}:\d{2}(?::\d{2})?[.,]\d{3}>", "", text)
        text = text.strip()
        if text:
            cleaned.append(text)
    return "\n".join(cleaned)


def clean_subtitle_text(text):
    """Chuyen doi WebVTT sang SRT chuan va loai bo cac dong quang cao trong phu de."""
    raw = (text or "").replace("\r\n", "\n").replace("\r", "\n").lstrip("\ufeff").strip()
    if not raw or "-->" not in raw:
        return ""

    is_vtt = raw.upper().startswith("WEBVTT")
    blocks = re.split(r"\n{2,}", raw)
    cues = []

    for block in blocks:
        lines = [ln.rstrip() for ln in block.splitlines() if ln.strip()]
        if not lines:
            continue
        first_upper = lines[0].strip().upper()
        if is_vtt and (
            first_upper.startswith("WEBVTT")
            or first_upper.startswith("STYLE")
            or first_upper.startswith("NOTE")
            or first_upper.startswith("REGION")
        ):
            continue

        timing_idx = -1
        timing_match = None
        for idx, ln in enumerate(lines[:3]):
            match = VTT_TIMESTAMP_LINE_RE.search(ln)
            if match:
                timing_idx = idx
                timing_match = match
                break

        if timing_idx < 0 or not timing_match:
            continue

        start_ts = _normalize_srt_timestamp(timing_match.group(1))
        end_ts = _normalize_srt_timestamp(timing_match.group(2))
        cue_body = _clean_cue_text(lines[timing_idx + 1:])
        if not cue_body:
            continue
        if SUBTITLE_AD_RE.search(cue_body):
            continue

        cues.append("%d\n%s --> %s\n%s" % (len(cues) + 1, start_ts, end_ts, cue_body))

    if not cues:
        return ""
    return "\n\n".join(cues) + "\n"
