# -*- coding: utf-8 -*-
"""Bộ giải mã segment cho server FHDC (tiktok.phimhdc.com).

Hỗ trợ cả hai định dạng giấu MPEG-TS trong PNG:
1. Định dạng mới (11/2026): chunk `stEg` chứa 12-byte header big-endian
   `(index, expected_count, expected_size)` theo sau là lát cắt MPEG-TS thô.
2. Định dạng cũ (09/2026): các chunk `iTXt` tên `payload-NNNN` chứa base64
   nén zlib của dữ liệu MPEG-TS.
"""
from __future__ import absolute_import, unicode_literals

import base64
import struct
import zlib


PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"


def _parse_itxt_index(keyword):
    suffix = keyword[len(b"payload"):].lstrip(b"-_")
    if suffix.isdigit():
        return int(suffix)
    return 0


def decode_fhdc_segment(data):
    """Chuyển segment PNG của FHDC thành MPEG-TS. Input không phải PNG thì
    trả nguyên trạng để caller tự xử lý; PNG rỗng hoặc lỗi cấu trúc sẽ ném ValueError."""
    data = data or b""
    if data[:8] != PNG_SIGNATURE:
        return data

    pos = 8
    raw_parts = []
    raw_expected_count = None
    raw_expected_size = None
    itxt_parts = []

    while pos + 12 <= len(data):
        length = struct.unpack(">I", data[pos:pos + 4])[0]
        chunk_type = data[pos + 4:pos + 8]
        data_start = pos + 8
        data_end = data_start + length
        if data_end + 4 > len(data):
            break
        chunk = data[data_start:data_end]

        if chunk_type == b"stEg":
            if length < 12:
                raise ValueError("Invalid raw TS PNG chunk")
            index, expected_count, expected_size = struct.unpack(">III", chunk[:12])
            if expected_count <= 0 or index >= expected_count or expected_size <= 0:
                raise ValueError("Invalid raw TS PNG metadata")
            if raw_expected_count is not None and (
                raw_expected_count != expected_count or raw_expected_size != expected_size
            ):
                raise ValueError("Inconsistent raw TS PNG metadata")
            raw_expected_count = expected_count
            raw_expected_size = expected_size
            raw_parts.append((index, chunk[12:]))
        elif chunk_type == b"iTXt":
            keyword_end = chunk.find(b"\x00")
            if keyword_end >= 0 and keyword_end + 3 <= len(chunk):
                keyword = chunk[:keyword_end]
                if keyword.startswith(b"payload"):
                    compressed = chunk[keyword_end + 1] == 1
                    cursor = keyword_end + 3
                    while cursor < len(chunk) and chunk[cursor] != 0:
                        cursor += 1
                    cursor += 1
                    while cursor < len(chunk) and chunk[cursor] != 0:
                        cursor += 1
                    cursor += 1
                    if cursor <= len(chunk):
                        text = chunk[cursor:]
                        if compressed:
                            text = zlib.decompress(text)
                        itxt_parts.append((_parse_itxt_index(keyword), keyword, text))

        if chunk_type == b"IEND":
            break
        pos = data_end + 4

    if raw_parts:
        raw_parts.sort(key=lambda item: item[0])
        if len(raw_parts) != raw_expected_count or any(
            item[0] != idx for idx, item in enumerate(raw_parts)
        ):
            raise ValueError("Incomplete raw TS PNG chunks")
        payload = b"".join(part for _, part in raw_parts)
        if len(payload) != raw_expected_size or not payload:
            raise ValueError("Raw TS PNG size mismatch")
        return payload

    if itxt_parts:
        itxt_parts.sort(key=lambda item: (item[0], item[1]))
        payload = base64.b64decode(b"".join(item[2] for item in itxt_parts))
        if not payload:
            raise ValueError("Empty iTXt TS PNG payload")
        return payload

    raise ValueError("Invalid or empty FHDC PNG segment")
