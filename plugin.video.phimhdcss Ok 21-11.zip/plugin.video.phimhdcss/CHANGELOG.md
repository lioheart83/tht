# Changelog

## 1.2.2 - 2026-11-20

- Khắc phục lỗi đang xem giữa chừng bị đứng phim:
  - Bổ sung cơ chế đọc trước (read-ahead prefetch) 2 segment kế tiếp cho `FHDC` (~40 giây trước) và 4 segment kế tiếp cho `NC`/`HD` kèm bộ đệm LRU + singleflight chống tải trùng giữa Kodi và worker nền.
  - Bổ sung retry tự động đa tầng + kiểm tra đủ `Content-Length` cho `/segment.ts` (tối đa 3 lần) và giới hạn thời gian từng mirror (`6s` read / `12s` tổng ở vòng 1) cho `/fhdc.ts` để chuyển nhanh sang CDN dự phòng `#HDC-SHOP-ALT` trước khi FFmpeg của Kodi hết timeout.
  - Định tuyến segment của nguồn `HD` qua `/segment.ts` trên proxy cục bộ khi proxy sẵn sàng để hưởng retry và đọc trước; bảo toàn thẻ `#EXT-X-ENDLIST` và ghi playlist nguyên tử (`.tmp` -> `os.replace`).
  - Tách riêng `media_http_client` (`keepalive_expiry=10.0s`) và `meta_http_client`, tự tạm dừng tải ngầm giới thiệu phim trong 45 giây khi đang phát video, và đóng kết nối sạch khi xảy ra lỗi để tránh hỏng luồng keep-alive.

## 1.2.1 - 2026-11-19

- Đưa toàn bộ **giới thiệu nội dung phim, trạng thái, năm, quốc gia, thể loại, thời lượng và diễn viên** ra ngay màn hình danh sách phim bên ngoài (kèm bộ nhớ đệm SQLite `resources/lib/meta_cache.py` tải song song qua HTTP/2 chỉ ~1s lần đầu và tức thì các lần sau).
- Thêm tùy chọn **Đọc giới thiệu phim (Toàn màn hình)** trong Context Menu cho phim có mô tả dài.
- Chuẩn hoá thời lượng sang số giây (`duration_seconds`) để hiển thị đúng `45:00` thay vì `00:45`, làm sạch dấu phẩy và câu quảng cáo tên miền thừa trong mô tả.

## 1.2.0 - 2026-11-19

- Khôi phục nguồn `FHDC` (`tiktok.phimhdc.com`) theo định dạng PNG mới dùng chunk nhị phân `stEg` (giữ tương thích ngược `iTXt`), hỗ trợ HTTP `Range`, cache 2 segment trong RAM và tự động chuyển CDN dự phòng từ `#HDC-SHOP-ALT`.
- Khôi phục nguồn `NC` (`embed*.streamc.xyz`): định tuyến `/segment.ts` trong proxy cục bộ qua HTTP/2 (`httpx`) kèm đủ header `Origin` và `Referer`, bổ sung fallback tự động qua các mirror dự phòng (`embed18`, `embed14`, `embed11`, `embed12`).
- Thêm bộ lọc quảng cáo `resources/lib/adblock.py`: cắt bỏ toàn bộ đoạn quảng cáo chèn qua `#EXT-X-DISCONTINUITY` (như `/v9/<hash>/segment_*.ts`) trên nguồn `HD` và playlist HLS trong khi vẫn giữ nguyên toàn bộ cảnh phim thật (`convertv9/`), bổ sung route `/hls.m3u8`, chuyển đổi phụ đề `.vtt` sang `.srt` và lọc dòng quảng cáo cá cược.
- Thêm danh mục duyệt trọn vẹn **Phim Thuyết Minh & Lồng Tiếng** và **Phim Phụ Đề (Vietsub / Engsub)** (tải song song các nhãn đơn ngữ & song ngữ qua HTTP/2), sửa lỗi `data-server` có xuống dòng trên Phim ngắn, mở thẳng nguồn phát cho phim lẻ/phim ngắn 1 tập và đưa mục tự động phát sạch quảng cáo lên đầu danh sách.
- Ưu tiên thứ tự nguồn sạch quảng cáo (`FHDC`, `NC`, `HD`) và ẩn triệt để các server popup quảng cáo.

## 1.1.15 - 2026-09-12

- An cac nguon da xac dinh KHONG phat duoc (HDC, OP, HY) khoi menu chon nguon; auto-play cung bo qua de khong mat thoi gian thu. Neu tap chi con nguoi nay, addon bao ro "chi co nguoi chua phat duoc". Muon bat lai chi can go host khoi UNPLAYABLE_SOURCE_HOSTS trong scraper.py.

## 1.1.14 - 2026-09-12

- Khoi phuc nguon FHDC (tiktok.phimhdc.com): embed chi nhan request co du header navigation; player moi dung play_guard token + /api/master-inline tra manifest HLS inline; segment la PNG chua TS nen trong chunk iTXt (zlib + base64) — them bo giai ma `fhdc.py` va route `/fhdc.ts` trong proxy cuc bo de Kodi phat truc tiep.
- Do lai thu tu uu tien nguon: HD, FHDC, NC, HDC, OP (FHDC da phat duoc; HDC van bi WAF chan TLS cua Python, OP van chet upstream - link share 404 va cert host sai).
- Nhan nguon FHDC hien "proxy cuc bo" nhu NC.
- Kiem tra 50 phim tren site: chi ton tai 6 loai nguon (HD, NC, HDC, FHDC, OP, HY). Nguon HY (player.abyssplayer.com) chua them vi media van bi Cloudflare chan TLS Python; HD + NC + FHDC da phu hop voi da so phim.
