# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

import base64
from collections import OrderedDict, deque
import json
import os
import re
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlencode, urljoin, urlparse

import xbmc

_ADDON_DIR = os.path.dirname(os.path.abspath(__file__))
_LIB_DIR = os.path.join(_ADDON_DIR, "resources", "lib")
for _path in (_ADDON_DIR, _LIB_DIR):
    if _path not in sys.path:
        sys.path.insert(0, _path)

import httpx

from resources.lib import scraper
from resources.lib.adblock import strip_hls_ads
from resources.lib.fhdc import decode_fhdc_segment
from resources.lib.meta_cache import get_cached_meta_many, put_cached_meta_many
from resources.lib.nc_proxy_state import clear_proxy_state, proxy_workspace_dir, write_proxy_state


HOST = "127.0.0.1"
PORT = 0
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36"
)
FHDC_CACHE_MAX_ITEMS = 3
TS_CACHE_MAX_ITEMS = 8
MAX_BUFFERED_TS_BYTES = 12 * 1024 * 1024
RETRYABLE_STATUS_CODES = (408, 429, 500, 502, 503, 504)
URI_ATTR_RE = re.compile(r'URI="([^"]+)"')
MEDIA_LIMITS = httpx.Limits(max_keepalive_connections=8, max_connections=16, keepalive_expiry=10.0)
MEDIA_TIMEOUT = httpx.Timeout(connect=4.0, read=7.0, write=7.0, pool=4.0)


def log(message, level=xbmc.LOGINFO):
    xbmc.log("[PhimHDCSS proxy] %s" % message, level)


def encode_token(value):
    return base64.urlsafe_b64encode(str(value).encode("utf-8")).decode("ascii").rstrip("=")


def decode_token(value):
    value = (value or "").encode("ascii")
    value += b"=" * (-len(value) % 4)
    return base64.urlsafe_b64decode(value).decode("utf-8")


def query_value(query, key):
    values = query.get(key) or []
    return decode_token(values[0]) if values else ""


def is_valid_http_url(url):
    try:
        target = urlparse(url)
        return target.scheme in ("http", "https") and bool(target.hostname)
    except Exception:
        return False


def valid_playlist_path(path):
    try:
        path = os.path.realpath(path)
        workspace = proxy_workspace_dir()
        return path.startswith(workspace + os.sep) and path.endswith(".m3u8")
    except Exception:
        return False


def build_origin_headers(referer):
    headers = {"User-Agent": USER_AGENT}
    if referer:
        headers["Referer"] = referer
        parsed = urlparse(referer)
        if parsed.scheme in ("http", "https") and parsed.netloc:
            headers["Origin"] = "%s://%s" % (parsed.scheme, parsed.netloc)
    return headers


def parse_content_length(value):
    if value is None:
        return None
    try:
        parsed = int(str(value).strip())
        return parsed if parsed >= 0 else None
    except (TypeError, ValueError):
        return None


def parse_byte_range(range_header, total_size):
    if not range_header or total_size <= 0:
        return None
    match = re.match(r"^\s*bytes=(\d*)-(\d*)\s*$", range_header, re.I)
    if not match:
        return None
    start_str, end_str = match.group(1), match.group(2)
    if not start_str and not end_str:
        return None
    if not start_str:
        suffix = int(end_str)
        if suffix <= 0:
            return (-1, -1)
        start = max(0, total_size - suffix)
        end = total_size - 1
        return (start, end)
    start = int(start_str)
    end = int(end_str) if end_str else total_size - 1
    end = min(end, total_size - 1)
    if start >= total_size or start > end:
        return (-1, -1)
    return (start, end)


class _UpstreamStatusError(Exception):
    def __init__(self, status_code):
        super(_UpstreamStatusError, self).__init__("HTTP %s" % status_code)
        self.status_code = int(status_code)


class _TooLargeToBuffer(Exception):
    pass


class _SegmentStore(object):
    """LRU cache ket hop singleflight de chong tai trung segment giua Kodi va read-ahead."""

    def __init__(self, max_items):
        self._max_items = max(1, int(max_items))
        self._lock = threading.Lock()
        self._cache = OrderedDict()
        self._inflight = {}

    def get_if_cached(self, key):
        with self._lock:
            value = self._cache.get(key)
            if value is not None:
                self._cache.move_to_end(key)
            return value

    def clear(self):
        with self._lock:
            self._cache.clear()

    def get_or_fetch(self, key, fetcher):
        while True:
            leader = False
            with self._lock:
                value = self._cache.get(key)
                if value is not None:
                    self._cache.move_to_end(key)
                    return value
                slot = self._inflight.get(key)
                if slot is None:
                    slot = {"event": threading.Event(), "value": None, "error": None}
                    self._inflight[key] = slot
                    leader = True

            if not leader:
                slot["event"].wait()
                if slot["error"] is not None:
                    raise slot["error"]
                if slot["value"] is not None:
                    return slot["value"]
                continue

            try:
                value = fetcher()
                with self._lock:
                    self._cache[key] = value
                    self._cache.move_to_end(key)
                    while len(self._cache) > self._max_items:
                        self._cache.popitem(last=False)
                    slot["value"] = value
                    self._inflight.pop(key, None)
                    slot["event"].set()
                return value
            except Exception as exc:
                with self._lock:
                    slot["error"] = exc
                    self._inflight.pop(key, None)
                    slot["event"].set()
                raise


class ProxyServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, server_address, RequestHandlerClass, bind_and_activate=True):
        self.media_http_client = httpx.Client(
            http2=True,
            follow_redirects=True,
            timeout=MEDIA_TIMEOUT,
            limits=MEDIA_LIMITS,
            transport=httpx.HTTPTransport(http2=True, retries=2, limits=MEDIA_LIMITS),
            headers={"User-Agent": USER_AGENT},
        )
        self.meta_http_client = httpx.Client(
            http2=True,
            follow_redirects=True,
            timeout=httpx.Timeout(10.0, connect=5.0),
            limits=httpx.Limits(max_keepalive_connections=4, max_connections=8, keepalive_expiry=10.0),
            headers={"User-Agent": USER_AGENT},
        )
        self._fhdc_store = _SegmentStore(FHDC_CACHE_MAX_ITEMS)
        self._ts_store = _SegmentStore(TS_CACHE_MAX_ITEMS)

        self._active_playlist_path = ""
        self._playlist_entries = []
        self._playlist_index = {}
        self._readahead_queue = deque()
        self._readahead_cond = threading.Condition()

        self._prefetch_queue = deque()
        self._prefetch_queued = set()
        self._prefetch_cond = threading.Condition()
        self._last_media_ts = 0.0
        self._stopping = False

        super(ProxyServer, self).__init__(
            server_address,
            RequestHandlerClass,
            bind_and_activate=bind_and_activate,
        )
        self._prefetch_thread = threading.Thread(target=self._prefetch_worker)
        self._prefetch_thread.daemon = True
        self._prefetch_thread.start()

        self._media_prefetch_thread = threading.Thread(target=self._media_prefetch_worker)
        self._media_prefetch_thread.daemon = True
        self._media_prefetch_thread.start()

    def mark_media_active(self):
        self._last_media_ts = time.monotonic()

    def register_playlist(self, path, playlist_text):
        entries = []
        index_map = {}
        for raw_line in (playlist_text or "").splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#"):
                continue
            parsed = urlparse(line)
            query = parse_qs(parsed.query)
            if parsed.path == "/fhdc.ts":
                u = query_value(query, "u")
                r = query_value(query, "r")
                alt_raw = query_value(query, "a")
                candidates = []
                for item in [u] + [x.strip() for x in alt_raw.splitlines() if x.strip()]:
                    if is_valid_http_url(item) and item not in candidates:
                        candidates.append(item)
                if candidates:
                    index_map[("fhdc", u)] = len(entries)
                    entries.append({
                        "kind": "fhdc",
                        "url": u,
                        "candidates": candidates,
                        "referer": r,
                    })
            elif parsed.path == "/segment.ts":
                u = query_value(query, "u")
                r = query_value(query, "r")
                if is_valid_http_url(u):
                    index_map[("segment", u)] = len(entries)
                    entries.append({
                        "kind": "segment",
                        "url": u,
                        "referer": r,
                    })

        playlist_changed = (path != self._active_playlist_path)
        with self._readahead_cond:
            self._active_playlist_path = path
            self._playlist_entries = entries
            self._playlist_index = index_map
            if playlist_changed:
                self._readahead_queue.clear()
                self._fhdc_store.clear()
                self._ts_store.clear()

    def trigger_readahead(self, kind, upstream_url):
        with self._readahead_cond:
            if self._stopping:
                return
            idx = self._playlist_index.get((kind, upstream_url))
            if idx is None:
                return
            lookahead = 2 if kind == "fhdc" else 4
            targets = self._playlist_entries[idx + 1:idx + 1 + lookahead]
            self._readahead_queue.clear()
            self._readahead_queue.extend(targets)
            if targets:
                self._readahead_cond.notify_all()

    def _media_prefetch_worker(self):
        while True:
            with self._readahead_cond:
                while not self._readahead_queue and not self._stopping:
                    self._readahead_cond.wait(timeout=1.0)
                if self._stopping:
                    return
                entry = self._readahead_queue.popleft()

            try:
                if entry["kind"] == "fhdc":
                    if self._fhdc_store.get_if_cached(entry["url"]) is None:
                        self.get_or_fetch_fhdc(entry["url"], entry["candidates"], entry["referer"])
                else:
                    if self._ts_store.get_if_cached(entry["url"]) is None:
                        self.get_or_fetch_ts(entry["url"], entry["referer"])
            except Exception as exc:
                log("Read-ahead skipped %s: %s" % (entry.get("url", ""), exc), xbmc.LOGINFO)

    def fetch_fhdc_bytes(self, candidates, referer):
        headers = {"User-Agent": USER_AGENT}
        if referer:
            headers["Referer"] = referer

        round_specs = (
            (6.0, 12.0),
            (10.0, 18.0),
        )
        last_status = None
        last_error = None

        for round_idx, (read_timeout, total_limit) in enumerate(round_specs):
            if round_idx > 0:
                with self._readahead_cond:
                    if self._stopping:
                        raise IOError("Proxy stopping")
                    self._readahead_cond.wait(timeout=0.25)
                    if self._stopping:
                        raise IOError("Proxy stopping")

            req_timeout = httpx.Timeout(connect=3.5, read=read_timeout, write=read_timeout, pool=3.5)
            for candidate in candidates:
                deadline = time.monotonic() + total_limit
                try:
                    with self.media_http_client.stream("GET", candidate, headers=headers, timeout=req_timeout) as resp:
                        if resp.status_code >= 400:
                            last_status = resp.status_code
                            continue
                        expected_len = parse_content_length(resp.headers.get("Content-Length"))
                        chunks = []
                        received = 0
                        for chunk in resp.iter_bytes(chunk_size=65536):
                            if chunk:
                                chunks.append(chunk)
                                received += len(chunk)
                            if time.monotonic() > deadline:
                                raise TimeoutError("FHDC mirror exceeded %.1fs" % total_limit)
                        raw = b"".join(chunks)
                        if expected_len is not None and received < expected_len:
                            raise IOError("Truncated FHDC body: %s/%s" % (received, expected_len))
                        return decode_fhdc_segment(raw)
                except (httpx.HTTPError, ValueError, OSError, TimeoutError) as exc:
                    last_error = exc
                    continue

        if last_status is not None:
            raise _UpstreamStatusError(last_status)
        raise IOError(str(last_error or "FHDC segment fetch failed"))

    def get_or_fetch_fhdc(self, url, candidates, referer):
        return self._fhdc_store.get_or_fetch(
            url,
            lambda: self.fetch_fhdc_bytes(candidates, referer),
        )

    def fetch_ts_bytes(self, url, referer):
        headers = build_origin_headers(referer)
        last_status = None
        last_error = None

        for attempt in range(3):
            if attempt > 0:
                delay = 0.2 if attempt == 1 else 0.5
                with self._readahead_cond:
                    if self._stopping:
                        raise IOError("Proxy stopping")
                    self._readahead_cond.wait(timeout=delay)
                    if self._stopping:
                        raise IOError("Proxy stopping")
            try:
                with self.media_http_client.stream("GET", url, headers=headers, timeout=MEDIA_TIMEOUT) as resp:
                    if resp.status_code in RETRYABLE_STATUS_CODES:
                        last_status = resp.status_code
                        continue
                    if resp.status_code >= 400:
                        raise _UpstreamStatusError(resp.status_code)
                    expected_len = parse_content_length(resp.headers.get("Content-Length"))
                    if expected_len is not None and expected_len > MAX_BUFFERED_TS_BYTES:
                        raise _TooLargeToBuffer(expected_len)
                    chunks = []
                    received = 0
                    for chunk in resp.iter_bytes(chunk_size=65536):
                        if chunk:
                            chunks.append(chunk)
                            received += len(chunk)
                            if received > MAX_BUFFERED_TS_BYTES:
                                raise _TooLargeToBuffer(received)
                    data = b"".join(chunks)
                    if expected_len is not None and received < expected_len:
                        raise IOError("Truncated TS body: %s/%s" % (received, expected_len))
                    return data
            except (_TooLargeToBuffer, _UpstreamStatusError):
                raise
            except (httpx.HTTPError, OSError) as exc:
                last_error = exc
                continue

        if last_status is not None:
            raise _UpstreamStatusError(last_status)
        raise IOError(str(last_error or "TS segment fetch failed"))

    def get_or_fetch_ts(self, url, referer):
        return self._ts_store.get_or_fetch(
            url,
            lambda: self.fetch_ts_bytes(url, referer),
        )

    def enqueue_prefetch(self, urls):
        clean_urls = [
            url for url in dict.fromkeys(urls or [])
            if url and is_valid_http_url(url) and scraper.is_site_url(url)
        ]
        if not clean_urls:
            return
        already_cached = set(get_cached_meta_many(clean_urls).keys())
        with self._prefetch_cond:
            if self._stopping:
                return
            added = False
            for url in clean_urls:
                if url not in already_cached and url not in self._prefetch_queued:
                    self._prefetch_queue.append(url)
                    self._prefetch_queued.add(url)
                    added = True
            if added:
                self._prefetch_cond.notify_all()

    def _prefetch_worker(self):
        while True:
            with self._prefetch_cond:
                while not self._stopping:
                    media_busy = (
                        self._last_media_ts > 0.0
                        and (time.monotonic() - self._last_media_ts) < 45.0
                    )
                    if self._prefetch_queue and not media_busy:
                        break
                    self._prefetch_cond.wait(timeout=2.0 if media_busy else 1.0)
                if self._stopping:
                    return
                url = self._prefetch_queue.popleft()
                self._prefetch_queued.discard(url)

            try:
                if get_cached_meta_many([url]):
                    continue
                for attempt in range(2):
                    resp = self.meta_http_client.get(
                        url,
                        headers={
                            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                            "Accept-Language": "vi,en-US;q=0.9,en;q=0.8",
                            "Accept-Encoding": "gzip",
                        },
                        timeout=10.0,
                    )
                    if resp.status_code == 200:
                        meta = scraper.extract_movie_meta_from_html(resp.text, url)
                        put_cached_meta_many({url: meta})
                        break
                    if resp.status_code in (429, 503) and attempt == 0:
                        with self._prefetch_cond:
                            if self._stopping:
                                return
                            self._prefetch_cond.wait(timeout=1.5)
                            if self._stopping:
                                return
                        continue
                    break
            except Exception as exc:
                log("Prefetch skipped %s: %s" % (url, exc), xbmc.LOGINFO)

            with self._prefetch_cond:
                if self._stopping:
                    return
                self._prefetch_cond.wait(timeout=0.35)
                if self._stopping:
                    return

    def server_close(self):
        with self._prefetch_cond:
            self._stopping = True
            self._prefetch_cond.notify_all()
        with self._readahead_cond:
            self._stopping = True
            self._readahead_cond.notify_all()
        for thread_attr in ("_prefetch_thread", "_media_prefetch_thread"):
            try:
                thread = getattr(self, thread_attr, None)
                if thread and thread.is_alive():
                    thread.join(timeout=1.5)
            except Exception:
                pass
        for client_attr in ("media_http_client", "meta_http_client"):
            try:
                client = getattr(self, client_attr, None)
                if client is not None:
                    client.close()
            except Exception:
                pass
        super(ProxyServer, self).server_close()


class ProxyHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    timeout = 30

    def log_message(self, format_, *args):
        return

    def send_error(self, code, message=None, explain=None):
        self.close_connection = True
        try:
            super(ProxyHandler, self).send_error(code, message=message, explain=explain)
        except (BrokenPipeError, ConnectionResetError, OSError):
            pass

    def do_GET(self):
        self.handle_request(send_body=True)

    def do_HEAD(self):
        self.handle_request(send_body=False)

    def do_POST(self):
        parsed = urlparse(self.path)
        if parsed.path != "/prefetch":
            self.send_error(404)
            return
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            length = 0
        if length <= 0 or length > 65536:
            self.send_error(400)
            return
        try:
            body = self.rfile.read(length)
            payload = json.loads(body.decode("utf-8"))
            urls = payload.get("urls") if isinstance(payload, dict) else None
            if not isinstance(urls, list):
                self.send_error(400)
                return
            valid_urls = [
                item.strip()
                for item in urls
                if isinstance(item, str) and is_valid_http_url(item.strip()) and scraper.is_site_url(item.strip())
            ]
            self.server.enqueue_prefetch(valid_urls)
            self.send_bytes(200, b"queued", "text/plain", True)
        except Exception:
            self.send_error(400)

    def local_base_url(self):
        return "http://127.0.0.1:%s" % self.server.server_address[1]

    def handle_request(self, send_body):
        parsed = urlparse(self.path)
        query = parse_qs(parsed.query)
        if parsed.path == "/ping":
            self.send_bytes(200, b"ok", "text/plain", send_body)
            return
        if parsed.path == "/playlist.m3u8":
            self.server.mark_media_active()
            self.serve_playlist(query, send_body)
            return
        if parsed.path == "/hls.m3u8":
            self.server.mark_media_active()
            self.serve_hls_playlist(query, send_body)
            return
        if parsed.path == "/segment.ts":
            self.server.mark_media_active()
            self.serve_segment(query, send_body)
            return
        if parsed.path == "/fhdc.ts":
            self.server.mark_media_active()
            self.serve_fhdc_segment(query, send_body)
            return
        self.send_error(404)

    def serve_playlist(self, query, send_body):
        try:
            path = query_value(query, "p")
            if not valid_playlist_path(path):
                self.send_error(403)
                return
            with open(path, "rb") as handle:
                data = handle.read()
            self.server.register_playlist(os.path.realpath(path), data.decode("utf-8", "ignore"))
            self.send_bytes(200, data, "application/vnd.apple.mpegurl", send_body)
        except Exception as exc:
            log("Cannot serve playlist: %s" % exc, xbmc.LOGWARNING)
            self.send_error(500)

    def serve_hls_playlist(self, query, send_body):
        try:
            url = query_value(query, "u")
            referer = query_value(query, "r")
            proxy_segments = (query.get("sp") or [""])[0] == "1"
            if not is_valid_http_url(url):
                self.send_error(403)
                return

            headers = build_origin_headers(referer)
            headers["Accept"] = "application/vnd.apple.mpegurl,application/x-mpegURL,*/*;q=0.8"
            resp = self.server.media_http_client.get(url, headers=headers)
            if resp.status_code >= 400:
                self.send_error(resp.status_code)
                return

            text = resp.text
            if "#EXTM3U" not in text:
                self.send_error(502)
                return

            local_base = self.local_base_url()
            effective_referer = referer or url

            def make_hls_url(target_url):
                params = {
                    "u": encode_token(target_url),
                    "r": encode_token(effective_referer),
                }
                if proxy_segments:
                    params["sp"] = "1"
                return "%s/hls.m3u8?%s" % (local_base, urlencode(params))

            def make_seg_url(target_url):
                return "%s/segment.ts?%s" % (local_base, urlencode({
                    "u": encode_token(target_url),
                    "r": encode_token(effective_referer),
                }))

            if "#EXT-X-STREAM-INF" in text:
                rewritten = []
                for line in text.splitlines():
                    stripped = line.strip()
                    if stripped.startswith("#"):
                        if 'URI="' in stripped:
                            line = URI_ATTR_RE.sub(
                                lambda m: 'URI="%s"' % make_hls_url(urljoin(url, m.group(1))),
                                line,
                            )
                        rewritten.append(line)
                    elif stripped:
                        rewritten.append(make_hls_url(urljoin(url, stripped)))
                    else:
                        rewritten.append(line)
                out_text = "\n".join(rewritten).strip() + "\n"
            else:
                cleaned = strip_hls_ads(text, url)
                rewritten = []
                for line in cleaned.splitlines():
                    stripped = line.strip()
                    if stripped.startswith("#"):
                        if 'URI="' in stripped and (
                            stripped.upper().startswith("#EXT-X-KEY:")
                            or stripped.upper().startswith("#EXT-X-MAP:")
                        ):
                            def _rewrite_attr(m):
                                abs_u = urljoin(url, m.group(1))
                                return 'URI="%s"' % (make_seg_url(abs_u) if proxy_segments else abs_u)
                            line = URI_ATTR_RE.sub(_rewrite_attr, line)
                        rewritten.append(line)
                    elif stripped:
                        abs_u = urljoin(url, stripped)
                        rewritten.append(make_seg_url(abs_u) if proxy_segments else abs_u)
                    else:
                        rewritten.append(line)
                out_text = "\n".join(rewritten).strip() + "\n"

            self.send_bytes(200, out_text.encode("utf-8"), "application/vnd.apple.mpegurl", send_body)
        except httpx.HTTPError as exc:
            log("Cannot proxy HLS playlist: %s" % exc, xbmc.LOGWARNING)
            self.send_error(502)
        except Exception as exc:
            log("Unexpected HLS proxy error: %s" % exc, xbmc.LOGWARNING)
            self.send_error(500)

    def send_media_payload(self, payload, send_body):
        total = len(payload)
        byte_range = parse_byte_range(self.headers.get("Range"), total)
        if byte_range == (-1, -1):
            self.send_response(416)
            self.send_header("Content-Range", "bytes */%d" % total)
            self.send_header("Content-Length", "0")
            self.end_headers()
            return

        if byte_range is not None:
            start, end = byte_range
            body = payload[start:end + 1]
            self.send_response(206)
            self.send_header("Content-Type", "video/mp2t")
            self.send_header("Accept-Ranges", "bytes")
            self.send_header("Content-Range", "bytes %d-%d/%d" % (start, end, total))
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            if send_body:
                self.wfile.write(body)
        else:
            self.send_response(200)
            self.send_header("Content-Type", "video/mp2t")
            self.send_header("Accept-Ranges", "bytes")
            self.send_header("Content-Length", str(total))
            self.end_headers()
            if send_body:
                self.wfile.write(payload)

    def _stream_large_segment(self, url, referer, send_body):
        headers = build_origin_headers(referer)
        range_header = self.headers.get("Range")
        if range_header:
            headers["Range"] = range_header
        method = "GET" if send_body else "HEAD"
        headers_sent = False
        try:
            with self.server.media_http_client.stream(method, url, headers=headers, timeout=MEDIA_TIMEOUT) as response:
                if response.status_code >= 400:
                    self.send_error(response.status_code)
                    return
                self.send_response(response.status_code)
                self.send_header("Content-Type", "video/mp2t")
                has_length = False
                for key in ("Content-Length", "Content-Range", "Accept-Ranges"):
                    value = response.headers.get(key)
                    if value:
                        if key == "Content-Length":
                            has_length = True
                        self.send_header(key, value)
                if not has_length:
                    self.send_header("Connection", "close")
                    self.close_connection = True
                self.end_headers()
                headers_sent = True
                if send_body:
                    for chunk in response.iter_bytes(chunk_size=65536):
                        if chunk:
                            self.wfile.write(chunk)
        except (BrokenPipeError, ConnectionResetError):
            self.close_connection = True
            return
        except Exception as exc:
            self.close_connection = True
            if not headers_sent:
                log("Cannot stream large segment: %s" % exc, xbmc.LOGWARNING)
                self.send_error(502)

    def serve_segment(self, query, send_body):
        try:
            url = query_value(query, "u")
            referer = query_value(query, "r")
            if not is_valid_http_url(url):
                self.send_error(403)
                return

            if not send_body:
                cached = self.server._ts_store.get_if_cached(url)
                if cached is not None:
                    self.send_media_payload(cached, send_body=False)
                    return
                self._stream_large_segment(url, referer, send_body=False)
                return

            self.server.trigger_readahead("segment", url)
            try:
                payload = self.server.get_or_fetch_ts(url, referer)
            except _TooLargeToBuffer:
                self._stream_large_segment(url, referer, send_body=True)
                return
            except _UpstreamStatusError as exc:
                self.send_error(exc.status_code)
                return
            except (httpx.HTTPError, OSError) as exc:
                log("Cannot proxy segment: %s" % exc, xbmc.LOGWARNING)
                self.send_error(502)
                return

            self.send_media_payload(payload, send_body=True)
        except (BrokenPipeError, ConnectionResetError):
            self.close_connection = True
            return
        except Exception as exc:
            log("Unexpected proxy error: %s" % exc, xbmc.LOGWARNING)
            self.send_error(500)

    def serve_fhdc_segment(self, query, send_body):
        """Giai ma segment PNG (stEg / iTXt) cua FHDC thanh MPEG-TS va ho tro
        Range + singleflight + read-ahead + fallback qua CDN #HDC-SHOP-ALT."""
        try:
            url = query_value(query, "u")
            referer = query_value(query, "r")
            alt_raw = query_value(query, "a")
            candidates = []
            for candidate in [url] + [item.strip() for item in alt_raw.splitlines() if item.strip()]:
                if is_valid_http_url(candidate) and candidate not in candidates:
                    candidates.append(candidate)

            if not candidates:
                self.send_error(403)
                return

            if send_body:
                self.server.trigger_readahead("fhdc", url)

            try:
                payload = self.server.get_or_fetch_fhdc(url, candidates, referer)
            except _UpstreamStatusError as exc:
                self.send_error(exc.status_code)
                return
            except (httpx.HTTPError, OSError, ValueError) as exc:
                log("Cannot proxy FHDC segment: %s" % exc, xbmc.LOGWARNING)
                self.send_error(502)
                return

            self.send_media_payload(payload, send_body=send_body)
        except (BrokenPipeError, ConnectionResetError):
            self.close_connection = True
            return
        except Exception as exc:
            log("Unexpected FHDC proxy error: %s" % exc, xbmc.LOGWARNING)
            self.send_error(500)

    def send_bytes(self, status, data, content_type, send_body):
        try:
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            if send_body:
                self.wfile.write(data)
        except (BrokenPipeError, ConnectionResetError):
            self.close_connection = True
            return


def _warm_home_catalog(server, monitor):
    if monitor.waitForAbort(2):
        return
    try:
        html = scraper.get_home_html()
        movies = scraper.parse_movies(html, scraper.BASE_URL + "/")
        urls = [movie["url"] for movie in movies if movie.get("url")]
        if urls and not monitor.abortRequested():
            server.enqueue_prefetch(urls)
    except Exception as exc:
        log("Home warmup skipped: %s" % exc, xbmc.LOGINFO)


def run():
    server = None
    proxy_port = None
    try:
        server = ProxyServer((HOST, PORT), ProxyHandler)
        proxy_port = server.server_address[1]
        write_proxy_state(proxy_port)
    except Exception as exc:
        log("Proxy did not start: %s" % exc, xbmc.LOGWARNING)
        if server is not None:
            server.server_close()
        return
    worker = threading.Thread(target=server.serve_forever)
    worker.daemon = True
    worker.start()
    log("Local proxy started on port %s" % proxy_port)
    monitor = xbmc.Monitor()
    warmup = threading.Thread(target=_warm_home_catalog, args=(server, monitor))
    warmup.daemon = True
    warmup.start()
    try:
        while not monitor.abortRequested():
            monitor.waitForAbort(1)
    finally:
        server.shutdown()
        server.server_close()
        clear_proxy_state(proxy_port)


if __name__ == "__main__":
    run()
