# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

import hashlib
import json
import os
import sys
import traceback
from urllib.parse import parse_qsl, urlencode
from urllib.request import Request

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from resources.lib import scraper
from resources.lib.adblock import clean_subtitle_text
from resources.lib.meta_cache import get_cached_meta_many
from resources.lib.proxy_state import read_proxy_base


ADDON = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo("name")
HANDLE = int(sys.argv[1])
PLUGIN_URL = sys.argv[0]


def get_bool_setting(setting_id, default=False):
    try:
        return ADDON.getSettingBool(setting_id)
    except Exception:
        val = (ADDON.getSetting(setting_id) or "").strip().lower()
        if val in ("true", "1", "yes"):
            return True
        if val in ("false", "0", "no"):
            return False
        return default


def get_int_setting(setting_id, default=0):
    try:
        return ADDON.getSettingInt(setting_id)
    except Exception:
        try:
            return int(ADDON.getSetting(setting_id) or default)
        except (TypeError, ValueError):
            return default


def build_url(params):
    return PLUGIN_URL + "?" + urlencode(params)


def notify(message, level=xbmcgui.NOTIFICATION_INFO):
    xbmcgui.Dialog().notification(ADDON_NAME, str(message), level, 5000)


def log_error(exc):
    xbmc.log("[%s] %s\n%s" % (ADDON_NAME, exc, traceback.format_exc()), xbmc.LOGERROR)


def _set_video_info(item, info):
    if not info:
        return
    if hasattr(item, "getVideoInfoTag"):
        try:
            tag = item.getVideoInfoTag()
            if info.get("title"):
                tag.setTitle(str(info["title"]))
            if info.get("originaltitle"):
                tag.setOriginalTitle(str(info["originaltitle"]))
            if info.get("plot"):
                tag.setPlot(str(info["plot"]))
            if info.get("plotoutline"):
                tag.setPlotOutline(str(info["plotoutline"]))
            if info.get("tagline"):
                tag.setTagLine(str(info["tagline"]))
            if info.get("mediatype"):
                tag.setMediaType(str(info["mediatype"]))
            if info.get("genre"):
                genres = [g.strip() for g in str(info["genre"]).split(",") if g.strip()]
                if genres:
                    tag.setGenres(genres)
            if info.get("country"):
                countries = [c.strip() for c in str(info["country"]).split(",") if c.strip()]
                if countries:
                    tag.setCountries(countries)
            if info.get("director"):
                directors = [d.strip() for d in str(info["director"]).split(",") if d.strip()]
                if directors:
                    tag.setDirectors(directors)
            if scraper.safe_int(info.get("year")) > 0:
                tag.setYear(scraper.safe_int(info["year"]))
            if scraper.safe_int(info.get("episode")) > 0:
                tag.setEpisode(scraper.safe_int(info["episode"]))
            if info.get("cast"):
                actors = [xbmc.Actor(name=str(name)) for name in info["cast"] if str(name).strip()]
                if actors:
                    tag.setCast(actors)
            return
        except Exception:
            pass
    item.setInfo("video", info)


def list_item(label, art=None, info=None, playable=False):
    item = xbmcgui.ListItem(label=label)
    if art:
        item.setArt({
            "thumb": art,
            "icon": art,
            "poster": art,
            "fanart": art,
        })
    if info:
        _set_video_info(item, info)
    if playable:
        item.setProperty("IsPlayable", "true")
    return item


def add_folder(label, params, art=None, info=None, context_items=None):
    item = list_item(label, art=art, info=info)
    if context_items:
        item.addContextMenuItems(context_items)
    xbmcplugin.addDirectoryItem(
        HANDLE,
        build_url(params),
        item,
        isFolder=True,
    )


def add_playable(label, params, art=None, info=None, context_items=None):
    item = list_item(label, art=art, info=info, playable=True)
    if context_items:
        item.addContextMenuItems(context_items)
    xbmcplugin.addDirectoryItem(
        HANDLE,
        build_url(params),
        item,
        isFolder=False,
    )


def finish(content="videos", succeeded=True):
    xbmcplugin.setContent(HANDLE, content)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(HANDLE, succeeded=succeeded)


def show_root():
    add_folder("Trang chủ / Phim đề cử", {
        "mode": "listing",
        "url": scraper.BASE_URL + "/",
        "title": "Trang chủ",
    })
    add_folder("Tìm kiếm", {"mode": "search"})
    add_folder("Phim Thuyết Minh & Lồng Tiếng", {
        "mode": "lang_menu",
        "group": "dubbed",
        "title": "Phim Thuyết Minh & Lồng Tiếng",
    })
    add_folder("Phim Phụ Đề (Vietsub)", {
        "mode": "lang_menu",
        "group": "subtitled",
        "title": "Phim Phụ Đề (Vietsub)",
    })
    for label, url in scraper.MAIN_LISTS:
        add_folder(label, {"mode": "listing", "url": url, "title": label})
    add_folder("Thể loại", {"mode": "nav", "group": "genres", "title": "Thể loại"})
    add_folder("Quốc gia & Danh mục", {"mode": "nav", "group": "categories", "title": "Quốc gia & Danh mục"})
    finish("videos")


def show_lang_menu(group):
    if group == "dubbed":
        items = [
            ("Tất cả Phim Thuyết Minh & Lồng Tiếng", "dubbed_all"),
            ("Phim Thuyết Minh (Đơn ngữ & Song ngữ)", "thuyet_minh"),
            ("Phim Lồng Tiếng (Hồng Kông / TVB / Chọn lọc)", "long_tieng"),
            ("Phim Song Ngữ (Phụ Đề + Thuyết Minh/Lồng Tiếng)", "dual_audio"),
        ]
    else:
        items = [
            ("Tất cả Phim Phụ Đề (Vietsub)", "vietsub_all"),
            ("Phim Song Ngữ (Phụ Đề + Thuyết Minh/Lồng Tiếng)", "dual_audio"),
        ]
    for label, group_key in items:
        add_folder(label, {
            "mode": "lang_listing",
            "group_key": group_key,
            "page": "1",
            "title": label,
        })
    finish("videos")


def format_movie_plot(meta, badge_override=""):
    header_parts = []
    lang_badge = (meta.get("lang_badge") or "").strip()
    if lang_badge:
        header_parts.append("[COLOR gold][B]%s[/B][/COLOR]" % lang_badge)

    ep_badge = (badge_override or meta.get("episode_total") or meta.get("label") or "").strip()
    if ep_badge:
        header_parts.append("[COLOR limegreen]%s tập[/COLOR]" % ep_badge if ep_badge.isdigit() else ep_badge)

    year = scraper.safe_int(meta.get("year"))
    if year > 0:
        header_parts.append(str(year))

    country = (meta.get("country") or "").strip()
    if country:
        header_parts.append(country)

    top_lines = []
    if header_parts:
        top_lines.append(" • ".join(header_parts))

    status = (meta.get("status") or "").strip()
    if status:
        top_lines.append("[COLOR lightskyblue]Trạng thái:[/COLOR] %s" % status)

    genres = (meta.get("genres") or "").strip()
    if genres:
        top_lines.append("[COLOR lightskyblue]Thể loại:[/COLOR] %s" % genres)

    title = (meta.get("title") or "").strip()
    original_title = (meta.get("original_title") or "").strip()
    if original_title and original_title.lower() != title.lower():
        top_lines.append("[COLOR lightskyblue]Tên gốc / Năm:[/COLOR] %s" % original_title)

    plot_text = (meta.get("plot") or "").strip() or "Chưa có nội dung giới thiệu cho phim này."

    footer_lines = []
    actors_raw = (meta.get("actors") or "").strip()
    if actors_raw:
        actor_list = [actor.strip() for actor in actors_raw.split(",") if actor.strip()]
        if actor_list:
            shown = ", ".join(actor_list[:6])
            if len(actor_list) > 6:
                shown += ", ..."
            footer_lines.append("[COLOR silver]Diễn viên: %s[/COLOR]" % shown)

    director = (meta.get("director") or "").strip()
    if director:
        footer_lines.append("[COLOR silver]Đạo diễn: %s[/COLOR]" % director)

    sections = []
    if top_lines:
        sections.append("\n".join(top_lines))
    sections.append(plot_text)
    if footer_lines:
        sections.append("\n".join(footer_lines))
    return "\n\n".join(sections)


def build_video_info(meta, title=None, mediatype="movie", badge_override=""):
    plot_formatted = format_movie_plot(meta, badge_override=badge_override)
    raw_plot = (meta.get("plot") or "").strip()
    info = {
        "title": title or meta.get("title", ""),
        "plot": plot_formatted,
        "plotoutline": raw_plot or plot_formatted,
        "mediatype": mediatype,
    }
    tagline = (badge_override or meta.get("lang_badge") or meta.get("label") or "").strip()
    if tagline:
        info["tagline"] = tagline
    if meta.get("original_title"):
        info["originaltitle"] = meta["original_title"]
    if meta.get("genres"):
        info["genre"] = meta["genres"]
    if meta.get("country"):
        info["country"] = meta["country"]
    if meta.get("director"):
        info["director"] = meta["director"]

    year = scraper.safe_int(meta.get("year"))
    if year > 0:
        info["year"] = year

    actors = (meta.get("actors") or "").strip()
    if actors:
        cast_list = [actor.strip() for actor in actors.split(",") if actor.strip()]
        if cast_list:
            info["cast"] = cast_list
    return info


def _movie_info_context_item(url, title):
    info_url = build_url({
        "mode": "movie_info",
        "url": url,
        "title": title,
    })
    return ("Đọc giới thiệu phim (Toàn màn hình)", "RunPlugin(%s)" % info_url)


def _trigger_background_prefetch(movies):
    proxy_base = read_proxy_base()
    if not proxy_base or not movies:
        return
    urls = [m["url"] for m in movies if m.get("url")]
    if not urls:
        return
    try:
        payload = json.dumps({"urls": urls}).encode("utf-8")
        req = Request(
            proxy_base + "/prefetch",
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with scraper.HTTP_OPENER.open(req, timeout=1):
            pass
    except Exception:
        pass


def _add_movie_items(movies):
    for movie in movies:
        info = build_video_info(movie, title=movie["title"], mediatype="movie")
        add_folder(
            movie["display_title"],
            {
                "mode": "details",
                "url": movie["url"],
            },
            art=movie.get("thumb") or movie.get("poster"),
            info=info,
            context_items=[_movie_info_context_item(movie["url"], movie["title"])],
        )


def show_lang_listing(group_key, page, title):
    page_num = max(1, scraper.safe_int(page) or 1)
    data = scraper.get_language_listing(group_key, page=page_num)
    xbmcplugin.setContent(HANDLE, "movies")
    _add_movie_items(data["movies"])

    if data.get("has_next"):
        add_folder("Trang tiếp theo", {
            "mode": "lang_listing",
            "group_key": group_key,
            "page": str(page_num + 1),
            "title": title or data.get("title", ""),
        })
    finish("movies")


def show_nav(group, title):
    links = scraper.get_nav_links(group)
    for entry in links:
        add_folder(entry["title"], {
            "mode": "listing",
            "url": entry["url"],
            "title": entry["title"],
        })
    finish("videos")


def show_listing(url, title):
    enrich = get_bool_setting("enrich_listings", True)
    page = scraper.get_listing(url, enrich=enrich)
    if not enrich:
        _trigger_background_prefetch(page["movies"])
    xbmcplugin.setContent(HANDLE, "movies")
    _add_movie_items(page["movies"])

    if page.get("next_url"):
        add_folder("Trang tiếp theo", {
            "mode": "listing",
            "url": page["next_url"],
            "title": title,
        })
    finish("movies")


def show_movie_info(url, title=""):
    cached = get_cached_meta_many([url]).get(url)
    if cached and cached.get("plot"):
        detail = dict(cached)
        if not detail.get("title"):
            detail["title"] = title
    else:
        detail = scraper.get_detail(url, load_all_episodes=False)
    xbmcgui.Dialog().textviewer(
        detail.get("title") or title or ADDON_NAME,
        format_movie_plot(detail),
    )


def show_details(url):
    preferred_lang = get_int_setting("preferred_lang", 0)
    auto_play = get_bool_setting("auto_play", False)
    detail = scraper.get_detail(url, load_all_episodes=False, preferred_lang=preferred_lang)
    info_ctx = _movie_info_context_item(url, detail.get("title", ""))
    art = detail.get("poster") or detail.get("thumb") or ""
    groups = detail.get("episode_groups") or []

    if detail.get("watch_url") and not groups:
        watch_info = build_video_info(detail, title=detail.get("title", ""), mediatype="movie")
        if auto_play:
            add_playable(
                "Phát ngay (Không quảng cáo)",
                {
                    "mode": "play_episode",
                    "url": detail["watch_url"],
                    "title": detail.get("title", ""),
                    "art": art,
                },
                art=art,
                info=watch_info,
                context_items=[info_ctx],
            )
        else:
            add_folder(
                "Chọn nguồn phát",
                {
                    "mode": "sources",
                    "url": detail["watch_url"],
                    "title": detail.get("title", ""),
                    "art": art,
                },
                art=art,
                info=watch_info,
                context_items=[info_ctx],
            )

    for group in groups:
        label = scraper.display_group_title(group)
        group_info = build_video_info(detail, title=label, mediatype="movie", badge_override=label)
        episodes = group.get("episodes") or []
        if len(episodes) == 1 and (episodes[0].get("title") or "").strip().lower() == "full":
            ep = episodes[0]
            full_title = "%s - %s" % (detail.get("title", ""), group.get("title", ""))
            play_params = {
                "mode": "play_episode",
                "url": ep["url"],
                "title": full_title,
                "art": art,
            }
            if auto_play:
                add_playable(
                    label,
                    play_params,
                    art=art,
                    info=group_info,
                    context_items=[info_ctx],
                )
            else:
                add_folder(
                    label,
                    {
                        "mode": "sources",
                        "url": ep["url"],
                        "title": full_title,
                        "art": art,
                    },
                    art=art,
                    info=group_info,
                    context_items=[
                        ("Phát tự động ngay (Không QC)", "PlayMedia(%s)" % build_url(play_params)),
                        info_ctx,
                    ],
                )
        else:
            add_folder(
                label,
                {
                    "mode": "episodes",
                    "url": url,
                    "group_key": group.get("key", ""),
                    "title": "%s - %s" % (detail.get("title", ""), group.get("title", "")),
                },
                art=art,
                info=group_info,
                context_items=[info_ctx],
            )

    if not detail.get("watch_url") and not groups:
        notify("Không tìm thấy tập phim.", xbmcgui.NOTIFICATION_WARNING)
    finish("episodes")


def show_episode_group(url, group_key, title):
    preferred_lang = get_int_setting("preferred_lang", 0)
    auto_play = get_bool_setting("auto_play", False)
    detail = scraper.get_detail(url, load_all_episodes=True, preferred_lang=preferred_lang)
    art = detail.get("poster") or detail.get("thumb") or ""
    groups = detail.get("episode_groups") or []

    group = None
    for candidate in groups:
        if candidate.get("key") == group_key:
            group = candidate
            break
    if not group and groups:
        group = groups[0]

    if not group:
        notify("Không tìm thấy danh sách tập phim.", xbmcgui.NOTIFICATION_WARNING)
        finish("episodes", succeeded=False)
        return

    xbmcplugin.setContent(HANDLE, "episodes")
    group_name = group.get("title") or "Phim"
    for episode in scraper.sort_episodes_ascending(group["episodes"]):
        ep_raw_title = (episode.get("title") or "").strip()
        ep_label_part = "Tập Full" if ep_raw_title.lower() == "full" else ("Tập %s" % ep_raw_title)
        display_label = "%s - %s" % (group_name, ep_label_part)
        full_title = "%s - %s" % (detail.get("title") or title, ep_label_part)
        episode_info = build_video_info(
            detail,
            title=full_title,
            mediatype="episode",
            badge_override=ep_label_part,
        )
        ep_num = scraper.episode_sort_key(episode)[1]
        if ep_num:
            episode_info["episode"] = ep_num

        play_params = {
            "mode": "play_episode",
            "url": episode["url"],
            "title": full_title,
            "art": art,
        }
        sources_params = {
            "mode": "sources",
            "url": episode["url"],
            "title": full_title,
            "art": art,
        }
        if auto_play:
            add_playable(
                display_label,
                play_params,
                art=art,
                info=episode_info,
                context_items=[
                    ("Chọn Server thủ công", "Container.Update(%s)" % build_url(sources_params)),
                ],
            )
        else:
            add_folder(
                display_label,
                sources_params,
                art=art,
                info=episode_info,
                context_items=[
                    ("Phát tự động ngay (Không QC)", "PlayMedia(%s)" % build_url(play_params)),
                ],
            )

    finish("episodes")


def show_search():
    keyboard = xbmc.Keyboard("", "Tìm phim trên Phim VN2 (Vietsub & Thuyết minh)")
    keyboard.doModal()
    if not keyboard.isConfirmed() or not keyboard.getText().strip():
        finish("videos", succeeded=False)
        return

    keyword = keyboard.getText().strip()
    enrich = get_bool_setting("enrich_listings", True)
    page = scraper.search_movies(keyword, enrich=enrich)
    if not page["movies"]:
        notify("Không tìm thấy phim phù hợp cho: %s" % keyword, xbmcgui.NOTIFICATION_INFO)
    xbmcplugin.setContent(HANDLE, "movies")
    _add_movie_items(page["movies"])
    if page.get("next_url"):
        add_folder("Trang tiếp theo", {
            "mode": "listing",
            "url": page["next_url"],
            "title": "Tìm kiếm: " + keyword,
        })
    finish("movies")


def show_sources(episode_url, title, art):
    sources = scraper.get_episode_sources(episode_url)
    auto_label = "Tự động phát nhanh (Không quảng cáo)"
    add_playable(
        auto_label,
        {
            "mode": "play_episode",
            "url": episode_url,
            "title": title,
            "art": art,
        },
        art=art,
        info={"title": auto_label, "plot": "Tập đã chọn: %s" % title},
    )

    for source in sources:
        label = "%s [%s - Không quảng cáo]" % (source.get("name", "Server"), source.get("lang", "VN2"))
        add_playable(
            label,
            {
                "mode": "play_stream",
                "url": source["url"],
                "title": "%s - %s" % (title, source.get("name", "Server")),
                "art": art,
            },
            art=art,
            info={"title": label, "plot": "Tập đã chọn: %s" % title},
        )
    finish("videos")


def prepare_subtitles(subtitles):
    paths = []
    if not subtitles:
        return paths

    temp_dir = xbmcvfs.translatePath("special://temp/plugin.video.vn2im-subtitles")
    if not xbmcvfs.exists(temp_dir):
        xbmcvfs.mkdirs(temp_dir)
    if not os.path.isdir(temp_dir):
        os.makedirs(temp_dir, exist_ok=True)

    for subtitle in subtitles[:3]:
        try:
            url = subtitle.get("url", "")
            if not url:
                continue
            label = subtitle.get("label", "subtitle")
            digest = hashlib.md5(url.encode("utf-8")).hexdigest()
            path = os.path.join(temp_dir, "%s-%s.srt" % (safe_filename(label), digest))
            text = scraper.request_text(url, headers={"Referer": subtitle.get("referer", "")}, timeout=6)
            text = clean_subtitle_text(text)
            if not text:
                continue
            with open(path, "w", encoding="utf-8-sig", newline="\n") as handle:
                handle.write(text)
            paths.append(path)
        except Exception as exc:
            xbmc.log("[%s] Không tải được phụ đề %s: %s" % (ADDON_NAME, subtitle, exc), xbmc.LOGWARNING)
    return paths


def safe_filename(value):
    cleaned = "".join(ch for ch in str(value or "subtitle") if ch.isalnum() or ch in ("-", "_", "."))
    return cleaned or "subtitle"


def resolve_and_play(media):
    item = xbmcgui.ListItem(path=media["url"])
    item.setProperty("IsPlayable", "true")
    try:
        item.setContentLookup(False)
    except AttributeError:
        pass
    if media.get("mime"):
        item.setMimeType(media["mime"])

    # Neu la luong HLS va Kodi co cai inputstream.adaptive thi cau hinh header day du
    if media.get("mime") == "application/vnd.apple.mpegurl":
        try:
            if xbmc.getCondVisibility("System.HasAddon(inputstream.adaptive)"):
                stream_headers = urlencode(media.get("headers") or {})
                item.setProperty("inputstream", "inputstream.adaptive")
                item.setProperty("inputstream.adaptive.manifest_type", "hls")
                if stream_headers:
                    item.setProperty("inputstream.adaptive.manifest_headers", stream_headers)
                    item.setProperty("inputstream.adaptive.stream_headers", stream_headers)
        except Exception:
            pass

    if media.get("title"):
        _set_video_info(item, {"title": media["title"]})
    if media.get("art"):
        item.setArt({"thumb": media["art"], "poster": media["art"], "icon": media["art"]})

    subtitles = prepare_subtitles(media.get("subtitles") or [])
    if subtitles:
        item.setSubtitles(subtitles)

    xbmcplugin.setResolvedUrl(HANDLE, True, item)


def play_episode(episode_url, title, art):
    progress = _busy("Đang tìm luồng phát sạch...")
    try:
        enable_adblock = get_bool_setting("enable_hls_adblock", True)
        media = scraper.resolve_episode_media(episode_url, enable_hls_adblock=enable_adblock)
    finally:
        _busy_close(progress)
    media["title"] = title
    media["art"] = art
    resolve_and_play(media)


def play_stream(url, title, art):
    progress = _busy("Đang kiểm tra server phát...")
    try:
        enable_adblock = get_bool_setting("enable_hls_adblock", True)
        media = scraper.resolve_stream(url, enable_hls_adblock=enable_adblock)
    finally:
        _busy_close(progress)
    media["title"] = title
    media["art"] = art
    resolve_and_play(media)


def _busy(message):
    try:
        progress = xbmcgui.DialogProgressBG()
        progress.create(ADDON_NAME, message)
        return progress
    except Exception:
        return None


def _busy_close(progress):
    if progress is None:
        return
    try:
        progress.close()
    except Exception:
        pass


def router():
    params = dict(parse_qsl(sys.argv[2][1:]))
    mode = params.get("mode", "root")

    try:
        if mode == "root":
            show_root()
        elif mode == "lang_menu":
            show_lang_menu(params.get("group", "dubbed"))
        elif mode == "lang_listing":
            show_lang_listing(params.get("group_key", ""), params.get("page", "1"), params.get("title", ""))
        elif mode == "nav":
            show_nav(params.get("group", ""), params.get("title", ""))
        elif mode == "listing":
            show_listing(params["url"], params.get("title", ""))
        elif mode == "details":
            show_details(params["url"])
        elif mode == "movie_info":
            show_movie_info(params["url"], params.get("title", ""))
        elif mode == "episodes":
            show_episode_group(params["url"], params.get("group_key", ""), params.get("title", ""))
        elif mode == "search":
            show_search()
        elif mode == "sources":
            show_sources(params["url"], params.get("title", ""), params.get("art", ""))
        elif mode == "play_episode":
            play_episode(params["url"], params.get("title", ""), params.get("art", ""))
        elif mode == "play_stream":
            play_stream(params["url"], params.get("title", ""), params.get("art", ""))
        else:
            show_root()
    except scraper.ScraperError as exc:
        log_error(exc)
        notify(exc, xbmcgui.NOTIFICATION_ERROR)
        if mode.startswith("play"):
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        else:
            finish("videos", succeeded=False)
    except Exception as exc:
        log_error(exc)
        notify("Có lỗi khi xử lý addon.", xbmcgui.NOTIFICATION_ERROR)
        if mode.startswith("play"):
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        else:
            finish("videos", succeeded=False)


if __name__ == "__main__":
    router()
