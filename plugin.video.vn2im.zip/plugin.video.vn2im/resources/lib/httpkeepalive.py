# -*- coding: utf-8 -*-
"""Keep-alive urllib opener an toan da luong (LIFO connection pool per host)."""
from __future__ import absolute_import, unicode_literals

import http.client
import io
import socket
import ssl
import threading
from urllib.error import URLError
from urllib.request import HTTPCookieProcessor, HTTPHandler, HTTPSHandler, build_opener
from urllib.response import addinfourl


MAX_IDLE_PER_HOST = 8


class _ConnectionPool(object):
    """Giu toi da MAX_IDLE_PER_HOST ket noi ranh dang LIFO cho moi (scheme, host)."""

    def __init__(self, max_per_host=MAX_IDLE_PER_HOST):
        self._max_per_host = max(1, int(max_per_host))
        self._lock = threading.Lock()
        self._idle = {}

    def checkout(self, scheme, host, factory, timeout):
        key = (scheme, host)
        conn = None
        with self._lock:
            stack = self._idle.get(key)
            if stack:
                conn = stack.pop()
        if conn is not None:
            conn.timeout = timeout
            if getattr(conn, "sock", None) is not None:
                try:
                    conn.sock.settimeout(timeout)
                except OSError:
                    pass
            return conn
        return factory(host, timeout=timeout)

    def release(self, scheme, host, conn):
        if conn is None:
            return
        if getattr(conn, "sock", None) is None:
            self.close_conn(conn)
            return
        key = (scheme, host)
        overflow = None
        with self._lock:
            stack = self._idle.setdefault(key, [])
            if len(stack) < self._max_per_host:
                stack.append(conn)
                return
            overflow = conn
        self.close_conn(overflow)

    @staticmethod
    def close_conn(conn):
        if conn is None:
            return
        try:
            conn.close()
        except Exception:
            pass

    def close_all(self):
        with self._lock:
            stacks = list(self._idle.values())
            self._idle.clear()
        for stack in stacks:
            for conn in stack:
                self.close_conn(conn)


class _KeepAliveMixin(object):
    _scheme = "http"

    def do_open(self, conn_factory, req):
        host = req.host
        if not host:
            raise URLError("no host given")
        timeout = req.timeout if getattr(req, "timeout", None) else 15
        pool = self._pool
        scheme = self._scheme

        headers = dict(req.unredirected_hdrs)
        for key, value in req.headers.items():
            headers.setdefault(key, value)
        headers["Connection"] = "keep-alive"
        body = req.data

        conn = None
        response = None
        payload = b""
        for attempt in range(2):
            conn = pool.checkout(scheme, host, conn_factory, timeout)
            try:
                conn.request(req.get_method(), req.selector, body, headers)
                response = conn.getresponse()
                payload = response.read()
                break
            except (
                http.client.BadStatusLine,
                http.client.ResponseNotReady,
                http.client.HTTPException,
                ConnectionError,
                BrokenPipeError,
                socket.error,
                OSError,
            ) as exc:
                pool.close_conn(conn)
                conn = None
                if attempt >= 1:
                    raise URLError(exc)

        conn_hdr = (response.getheader("Connection") or "").lower()
        if "close" in conn_hdr or response.version == 10:
            pool.close_conn(conn)
        else:
            pool.release(scheme, host, conn)

        wrapped = addinfourl(io.BytesIO(payload), response.msg, req.get_full_url())
        wrapped.code = response.status
        wrapped.msg = response.reason
        return wrapped


class _KeepAliveHTTPHandler(_KeepAliveMixin, HTTPHandler):
    _scheme = "http"

    def __init__(self, pool):
        HTTPHandler.__init__(self)
        self._pool = pool

    def http_open(self, req):
        return self.do_open(http.client.HTTPConnection, req)


class _KeepAliveHTTPSHandler(_KeepAliveMixin, HTTPSHandler):
    _scheme = "https"

    def __init__(self, pool, context=None):
        HTTPSHandler.__init__(self, context=context)
        self._pool = pool
        self._context = context or ssl.create_default_context()

    def https_open(self, req):
        return self.do_open(
            lambda host, timeout=15: http.client.HTTPSConnection(
                host, timeout=timeout, context=self._context
            ),
            req,
        )


def build_keepalive_opener(cookie_jar=None):
    """Tao urllib opener tai su dung ket noi keep-alive cho moi host."""
    pool = _ConnectionPool()
    handlers = [
        _KeepAliveHTTPHandler(pool),
        _KeepAliveHTTPSHandler(pool),
    ]
    if cookie_jar is not None:
        handlers.append(HTTPCookieProcessor(cookie_jar))
    opener = build_opener(*handlers)
    opener._pool = pool
    return opener
