# -*- coding: utf-8 -*-
"""Scraper & resolver khong quang cao cho https://www.vn2.im/."""
from __future__ import absolute_import, unicode_literals

import base64
from concurrent.futures import ThreadPoolExecutor
import gzip
import html as html_lib
import json
import os
import re
import sys
import threading
import time
import unicodedata
from http.cookiejar import CookieJar
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlencode, urljoin, urlparse
from urllib.request import Request

_LIB_DIR = os.path.dirname(os.path.abspath(__file__))
if _LIB_DIR not in sys.path:
    sys.path.insert(0, _LIB_DIR)

import httpx

from resources.lib.httpkeepalive import build_keepalive_opener
from resources.lib.meta_cache import get_cached_meta_many, put_cached_meta_many
from resources.lib.proxy_state import read_proxy_base


BASE_URL = "https://www.vn2.im"
DATA_BASE_URL = "https://vn2data.com"
MIRROR_HOSTS = (
    "vn2.im",
    "www.vn2.im",
    "vn2z.pro",
    "www.vn2z.pro",
    "vn2d.my",
    "www.vn2d.my",
)
SITE_HOSTS = ("vn2.im", "www.vn2.im")
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
)
RETRYABLE_STATUS_CODES = (408, 429, 500, 502, 503, 504)

MAIN_LISTS = [
    ("Phim Mới Cập Nhật", BASE_URL + "/phim-moi"),
    ("Phim Xem Nhiều Nhất", BASE_URL + "/phim-xem-nhieu/top"),
    ("Top Trending / Yêu Thích", BASE_URL + "/top-phim-duoc-nhieu-yeu-thich/trending"),
    ("Phim Lẻ Chọn Lọc", BASE_URL + "/the-loai/phim-le-33"),
    ("Phim Chiếu Rạp", BASE_URL + "/danh-muc/chieu-rap-23"),
    ("Hoạt Hình - Anime", BASE_URL + "/the-loai2/hoat-hinh-anime-29"),
]

FALLBACK_GENRES = [
    {"title": "Hành Động", "url": BASE_URL + "/the-loai/hanh-dong-1"},
    {"title": "Tình Cảm", "url": BASE_URL + "/the-loai/tinh-cam-19"},
    {"title": "Cổ Trang Tổng Hợp", "url": BASE_URL + "/the-loai/co-trang-tong-hop-26"},
    {"title": "Ngôn Tình Xuyên Không", "url": BASE_URL + "/the-loai/ngon-tinh-xuyen-khong-4"},
    {"title": "Tình Cảm Hài Hước", "url": BASE_URL + "/the-loai/tinh-cam-hai-huoc-20"},
    {"title": "Tình cảm Hành động", "url": BASE_URL + "/the-loai/tinh-cam-hanh-dong-5"},
    {"title": "Cờ Bạc Xã Hội Đen", "url": BASE_URL + "/the-loai/co-bac-xa-hoi-den-16"},
    {"title": "Hành Động Hình Sự", "url": BASE_URL + "/the-loai/hanh-dong-hinh-su-22"},
    {"title": "Hành động Hài Hước", "url": BASE_URL + "/the-loai/hanh-dong-hai-huoc-24"},
    {"title": "Võ Thuật", "url": BASE_URL + "/the-loai/vo-thuat-17"},
    {"title": "Võ Thuật Kiếm Hiệp", "url": BASE_URL + "/the-loai/vo-thuat-kiem-hiep-6"},
    {"title": "Bí ẩn - Kinh dị", "url": BASE_URL + "/the-loai/bi-an-kinh-di-27"},
    {"title": "Phim Lẻ Hay", "url": BASE_URL + "/the-loai/phim-le-hay-31"},
    {"title": "Phim Lẻ", "url": BASE_URL + "/the-loai/phim-le-33"},
    {"title": "HOẠT HÌNH - ANIME", "url": BASE_URL + "/the-loai/hoat-hinh-anime-29"},
    {"title": "Ca Nhạc", "url": BASE_URL + "/the-loai/ca-nhac-32"},
    {"title": "TOP Drama YOUTUBE", "url": BASE_URL + "/the-loai3/top-drama-youtube-35"},
]

FALLBACK_CATEGORIES = [
    {"title": "Trung Quốc", "url": BASE_URL + "/danh-muc/trung-quoc-7"},
    {"title": "Hàn Quốc", "url": BASE_URL + "/danh-muc/han-quoc-10"},
    {"title": "Thái Lan", "url": BASE_URL + "/danh-muc/thai-lan-8"},
    {"title": "Hồng Kông", "url": BASE_URL + "/danh-muc/hong-kong-9"},
    {"title": "Mỹ", "url": BASE_URL + "/danh-muc/my-2"},
    {"title": "Việt Nam", "url": BASE_URL + "/danh-muc/viet-nam-1"},
    {"title": "Nhật Bản", "url": BASE_URL + "/danh-muc/nhat-ban-11"},
    {"title": "Nhiều quốc gia", "url": BASE_URL + "/danh-muc/nhieu-quoc-gia-17"},
    {"title": "Chiếu rạp", "url": BASE_URL + "/danh-muc/chieu-rap-23"},
    {"title": "Lẻ Đề Cử", "url": BASE_URL + "/danh-muc/le-de-cu-20"},
    {"title": "LẺ Tổng Hợp", "url": BASE_URL + "/danh-muc/le-tong-hop-16"},
    {"title": "Ca Nhạc - Hài Cười", "url": BASE_URL + "/danh-muc/ca-nhac-hai-cuoi-21"},
    {"title": "Thiếu nhi - Kinh Phật", "url": BASE_URL + "/danh-muc/thieu-nhi-kinh-phat-26"},
    {"title": "Phim Drama TikTok", "url": BASE_URL + "/danh-muc2/phim-drama-tiktok-19"},
    {"title": "TOP CA NHẠC", "url": BASE_URL + "/danh-muc2/top-ca-nhac-28"},
]

LANGUAGE_GROUPS = {
    "dubbed_all": {
        "title": "Tất cả Phim Thuyết Minh & Lồng Tiếng",
        "sources": (BASE_URL + "/phim-moi",),
        "predicate": lambda m: bool(m.get("has_dub")),
    },
    "thuyet_minh": {
        "title": "Phim Thuyết Minh (Đơn ngữ & Song ngữ)",
        "sources": (BASE_URL + "/phim-moi",),
        "predicate": lambda m: bool(m.get("has_dub")),
    },
    "long_tieng": {
        "title": "Phim Lồng Tiếng (Hồng Kông / TVB / Chọn lọc)",
        "sources": (BASE_URL + "/danh-muc/hong-kong-9", BASE_URL + "/phim-moi"),
        "predicate": lambda m: bool(m.get("is_long_tieng")),
    },
    "vietsub_all": {
        "title": "Tất cả Phim Phụ Đề (Vietsub)",
        "sources": (BASE_URL + "/phim-moi",),
        "predicate": lambda m: bool(m.get("has_sub")),
    },
    "dual_audio": {
        "title": "Phim Song Ngữ (Phụ Đề + Thuyết Minh/Lồng Tiếng)",
        "sources": (BASE_URL + "/phim-moi",),
        "predicate": lambda m: bool(m.get("has_dub") and m.get("has_sub")),
    },
}

LANGUAGE_PAGE_SIZE = 24

# Opener dung chung ket noi keep-alive (khong luu cookie quang cao khi duyet trang)
HTTP_OPENER = build_keepalive_opener(cookie_jar=None)
# Opener cho fallback ASP.NET POST neu can giu cookie tam
COOKIE_JAR = CookieJar()
SESSION_OPENER = build_keepalive_opener(cookie_jar=COOKIE_JAR)

_CHECK_USER_LOCK = threading.Lock()
_CHECK_USER_CACHE = {
    "keyfix": "",
    "cookie": "",
    "channel_time": "",
    "hour": None,
    "fetched_at": 0.0,
}


class ScraperError(Exception):
    pass


def safe_int(value, default=0):
    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        return default


def clean_text(value):
    if value is None:
        return ""
    value = re.sub(r"(?is)<script.*?</script>|<style.*?</style>", " ", str(value))
    value = re.sub(r"(?s)<[^>]+>", " ", value)
    value = html_lib.unescape(value)
    value = value.replace("\xa0", " ")
    value = re.sub(r"\s+", " ", value)
    return value.strip()


def attr(tag, name, default=""):
    patterns = [
        r'\b%s\s*=\s*"([^"]*)"' % re.escape(name),
        r"\b%s\s*=\s*'([^']*)'" % re.escape(name),
    ]
    for pattern in patterns:
        match = re.search(pattern, tag, re.I)
        if match:
            return html_lib.unescape(match.group(1))
    return default


def normalize_url(url, base=BASE_URL):
    url = html_lib.unescape((url or "").strip())
    if not url or url.startswith("javascript:") or url.startswith("#"):
        return ""
    if url.startswith("//"):
        url = "https:" + url
    url = urljoin(base, url)
    parsed = urlparse(url)
    host = (parsed.hostname or "").lower()
    if host in MIRROR_HOSTS:
        path = parsed.path or "/"
        query = ("?" + parsed.query) if parsed.query else ""
        return "%s%s%s" % (BASE_URL, path, query)
    return url


def is_site_url(url):
    host = (urlparse(url).hostname or "").lower()
    return host in SITE_HOSTS


def strip_vn_accents(text):
    """Chuyen tieng Viet co dau thanh khong dau (giu nguyen thuong/hoa tuy ham goi)."""
    value = str(text or "")
    value = value.replace("đ", "d").replace("Đ", "D")
    nfkd = unicodedata.normalize("NFKD", value)
    return "".join(ch for ch in nfkd if not unicodedata.combining(ch))


def slugify_vn(text):
    value = strip_vn_accents(text).lower()
    value = re.sub(r"[^a-z0-9]+", "-", value)
    return value.strip("-")


def search_slug(keyword):
    return slugify_vn(keyword)


def fix_tap_url_name(tap_name):
    """Port chinh xac ham fixNameUrl() tu add-tap.js cua vn2.im."""
    value = strip_vn_accents(str(tap_name or "")).lower()
    value = re.sub(r"\s+", "-", value)
    value = re.sub(r"-+", "-", value)
    return value.strip("-")


def extract_year(text):
    match = re.search(r"\b(19\d{2}|20\d{2})\b", text or "")
    return int(match.group(1)) if match else 0


def _decode_response_bytes(raw, content_encoding="", charset="utf-8"):
    if "gzip" in (content_encoding or "").lower():
        try:
            raw = gzip.decompress(raw)
        except OSError:
            pass
    if raw.startswith(b"\xff\xfe"):
        return raw[2:].decode("utf-16-le", "ignore")
    return raw.decode(charset or "utf-8", "ignore")


def request_raw(url, data=None, headers=None, method=None, timeout=12, use_session=False):
    body = None
    final_headers = {
        "User-Agent": USER_AGENT,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "vi,en-US;q=0.9,en;q=0.8",
        "Accept-Encoding": "gzip",
    }
    if headers:
        final_headers.update(headers)

    if isinstance(data, dict):
        body = urlencode(data).encode("utf-8")
        final_headers.setdefault("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
    elif data is not None:
        body = data

    opener = SESSION_OPENER if use_session else HTTP_OPENER
    for attempt in range(2):
        try:
            req = Request(url, data=body, headers=final_headers, method=method)
            with opener.open(req, timeout=timeout) as response:
                raw = response.read()
                resp_headers = response.headers
                final_url = response.geturl()
                status_code = getattr(response, "status", None) or getattr(response, "code", 200)
                return raw, resp_headers, final_url, status_code
        except HTTPError as exc:
            if exc.code not in RETRYABLE_STATUS_CODES or attempt == 1:
                raise ScraperError("HTTP %s khi tải %s" % (exc.code, url))
        except URLError as exc:
            if attempt == 1:
                raise ScraperError("Không kết nối được %s: %s" % (url, exc.reason))
        except Exception as exc:
            if attempt == 1:
                raise ScraperError("Không tải được %s: %s" % (url, exc))
        time.sleep(0.25 * (attempt + 1))


def request_text(url, data=None, headers=None, method=None, timeout=12, use_session=False):
    raw, resp_headers, _, _ = request_raw(
        url, data=data, headers=headers, method=method, timeout=timeout, use_session=use_session
    )
    encoding = resp_headers.get("Content-Encoding", "") if resp_headers else ""
    charset = resp_headers.get_content_charset() if hasattr(resp_headers, "get_content_charset") else None
    return _decode_response_bytes(raw, encoding, charset or "utf-8")


def ready_proxy_base(retries=8):
    base = read_proxy_base()
    if not base:
        return ""
    for attempt in range(retries):
        try:
            req = Request(base + "/ping", headers={"User-Agent": USER_AGENT})
            with HTTP_OPENER.open(req, timeout=1) as resp:
                if resp.read() == b"ok":
                    return base
        except (HTTPError, URLError, OSError):
            pass
        if attempt < retries - 1:
            time.sleep(0.12)
    return ""


H2_CLIENT = httpx.Client(
    http2=True,
    follow_redirects=True,
    timeout=httpx.Timeout(12.0, connect=4.0),
    limits=httpx.Limits(max_keepalive_connections=10, max_connections=20),
    headers={"User-Agent": USER_AGENT},
)


def encode_proxy_token(value):
    return base64.urlsafe_b64encode(str(value).encode("utf-8")).decode("ascii").rstrip("=")


def build_video_stream_headers(referer="https://vn2data.com/", byte_range=""):
    headers = {
        "User-Agent": USER_AGENT,
        "Referer": referer or (DATA_BASE_URL + "/"),
        "Accept": "*/*",
        "Accept-Encoding": "identity;q=1, *;q=0",
        "Sec-Fetch-Dest": "video",
        "Sec-Fetch-Mode": "no-cors",
        "Sec-Fetch-Site": "cross-site",
    }
    if byte_range:
        headers["Range"] = byte_range
    return headers


def get_home_html():
    return request_text(BASE_URL + "/")


def get_nav_links(group):
    try:
        html = get_home_html()
    except ScraperError:
        html = ""

    if group == "genres":
        menu_class = "widget_nav_menu1"
        path_prefixes = ("/the-loai/", "/the-loai2/", "/the-loai3/")
        fallback = FALLBACK_GENRES
    elif group == "categories":
        menu_class = "widget_nav_menu2"
        path_prefixes = ("/danh-muc/", "/danh-muc2/")
        fallback = FALLBACK_CATEGORIES
    else:
        return []

    links = []
    seen = set()
    if html:
        m_menu = re.search(
            r'<div\b[^>]*class=["\'][^"\']*\b%s\b[^"\']*["\'][^>]*>(.*?)</div>\s*</div>' % re.escape(menu_class),
            html,
            re.S | re.I,
        )
        section = m_menu.group(1) if m_menu else html
        for match in re.finditer(r"<a\b[^>]*href=[\"']([^\"']+)[\"'][^>]*>(.*?)</a>", section, re.S | re.I):
            url = normalize_url(match.group(1))
            parsed_path = urlparse(url).path
            if not parsed_path.startswith(path_prefixes):
                continue
            title = clean_text(match.group(2))
            if not title or url in seen:
                continue
            seen.add(url)
            links.append({"title": title, "url": url})

    return links or list(fallback)


def parse_movies(html, page_url=BASE_URL):
    """Phan tich danh sach phim tu HTML cua vn2.im (chi lay Form2, FormCanhac2 va boxtk,
    tuyet doi khong lay nham sidebar goi y box_pc / boxtopnew / vn2fixview)."""
    source_html = html or ""
    movies = []
    seen = set()

    # 1. The phim chinh: <div class="Form2">
    form2_parts = source_html.split('<div class="Form2">')
    for chunk in form2_parts[1:]:
        block = chunk[:1400]
        end_pos = len(block)
        for marker in ('<table class="c8"', '<div class="paggingDiv"', '<div class="form_fix"', '<div class="boxrightqc_fix"'):
            pos = block.find(marker)
            if pos != -1 and pos < end_pos:
                end_pos = pos
        block = block[:end_pos]

        link_m = re.search(r'<p\s+class=["\']Form2Text["\'][^>]*>\s*<a\b[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>', block, re.S | re.I)
        if not link_m:
            link_m = re.search(r'<div\s+class=["\']Form2Img["\'][^>]*>\s*<a\b[^>]*href=["\']([^"\']+)["\'][^>]*>', block, re.S | re.I)
        if not link_m:
            continue

        url = normalize_url(link_m.group(1), page_url)
        if not url or not is_site_url(url) or url in seen:
            continue

        title = clean_text(link_m.group(2)) if link_m.lastindex and link_m.lastindex >= 2 else ""
        img_m = re.search(r"<img\b[^>]*>", block, re.I)
        thumb = normalize_url(attr(img_m.group(0), "src"), page_url) if img_m else ""
        if not title and img_m:
            title = clean_text(attr(img_m.group(0), "alt"))
        if not title:
            a_tag = re.search(r'<div\s+class=["\']Form2Img["\'][^>]*>\s*<a\b[^>]*>', block, re.S | re.I)
            if a_tag:
                title = clean_text(attr(a_tag.group(0), "title"))
        if not title:
            continue

        seen.add(url)
        ep_m = re.search(r'<span\s+class=["\']boxtt_tap["\'][^>]*>(.*?)</span>', block, re.S | re.I)
        ep_badge = clean_text(ep_m.group(1)) if ep_m else ""

        country_m = re.search(r'<div\s+class=["\']infoquuocgia["\'][^>]*>(.*?)</div>', block, re.S | re.I)
        country = clean_text(country_m.group(1)) if country_m else ""
        if country.lower().startswith("phim "):
            country = country[5:].strip()

        year = extract_year(title)
        display_title = "%s [%s]" % (title, ep_badge) if ep_badge else title
        movies.append({
            "title": title,
            "display_title": display_title,
            "url": url,
            "thumb": thumb,
            "poster": thumb,
            "label": ep_badge,
            "episode_total": ep_badge,
            "country": country,
            "year": year,
            "is_video": "/video/" in url,
        })

    # 2. The ket qua tim kiem: <div class="boxtk">
    boxtk_parts = source_html.split('<div class="boxtk">')
    for chunk in boxtk_parts[1:]:
        block = chunk[:1400]
        end_pos = len(block)
        for marker in ('<table class="c8"', '<div class="paggingDiv"', '<h5'):
            pos = block.find(marker)
            if pos != -1 and pos < end_pos:
                end_pos = pos
        block = block[:end_pos]

        link_m = re.search(r'<p\s+class=["\']nametk["\'][^>]*>\s*<a\b[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>', block, re.S | re.I)
        if not link_m:
            link_m = re.search(r'<div\s+class=["\']boxtk_img["\'][^>]*>\s*<a\b[^>]*href=["\']([^"\']+)["\'][^>]*>', block, re.S | re.I)
        if not link_m:
            continue

        url = normalize_url(link_m.group(1), page_url)
        if not url or not is_site_url(url) or url in seen:
            continue

        title = clean_text(link_m.group(2)) if link_m.lastindex and link_m.lastindex >= 2 else ""
        img_m = re.search(r"<img\b[^>]*>", block, re.I)
        thumb = normalize_url(attr(img_m.group(0), "src"), page_url) if img_m else ""
        if not title and img_m:
            title = clean_text(attr(img_m.group(0), "alt"))
        if not title:
            continue

        seen.add(url)
        ep_m = re.search(r'<div\s+class=["\']taptk["\'][^>]*>(.*?)</div>', block, re.S | re.I)
        ep_badge = clean_text(ep_m.group(1)) if ep_m else ""
        if ep_badge.lower().startswith("tập phim "):
            ep_badge = ep_badge[9:].strip()

        country_m = re.search(r'<div\s+class=["\']nametk["\'][^>]*>(.*?)</div>', block, re.S | re.I)
        country = clean_text(country_m.group(1)) if country_m else ""
        if country.lower().startswith("phim "):
            country = country[5:].strip()

        year = extract_year(title)
        display_title = "%s [%s]" % (title, ep_badge) if ep_badge else title
        movies.append({
            "title": title,
            "display_title": display_title,
            "url": url,
            "thumb": thumb,
            "poster": thumb,
            "label": ep_badge,
            "episode_total": ep_badge,
            "country": country,
            "year": year,
            "is_video": "/video/" in url,
        })

    # 3. The Drama TikTok / YouTube / Ca nhac: <div class="FormCanhac2">
    canhac_parts = source_html.split('<div class="FormCanhac2">')
    for chunk in canhac_parts[1:]:
        block = chunk[:1000]
        end_pos = len(block)
        for marker in ('<table class="c8"', '<div class="paggingDiv"', '<div class="boxrightqc_fix"'):
            pos = block.find(marker)
            if pos != -1 and pos < end_pos:
                end_pos = pos
        block = block[:end_pos]

        link_m = re.search(r'<p\s+class=["\']CanhacText["\'][^>]*>\s*<a\b[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>', block, re.S | re.I)
        if not link_m:
            continue
        url = normalize_url(link_m.group(1), page_url)
        if not url or not is_site_url(url) or url in seen:
            continue
        title = clean_text(link_m.group(2))
        if not title:
            continue
        seen.add(url)
        img_m = re.search(r"<img\b[^>]*>", block, re.I)
        thumb = normalize_url(attr(img_m.group(0), "src"), page_url) if img_m else ""
        movies.append({
            "title": title,
            "display_title": title,
            "url": url,
            "thumb": thumb,
            "poster": thumb,
            "label": "",
            "episode_total": "",
            "country": "",
            "year": extract_year(title),
            "is_video": "/video/" in url,
        })

    return movies


def find_next_page(html, page_url):
    pdiv_m = re.search(r'<div\b[^>]*class=["\']paggingDiv["\'][^>]*>(.*?)</div>', html or "", re.S | re.I)
    if not pdiv_m:
        return ""
    pdiv = pdiv_m.group(1)

    next_m = re.search(r'<a\b[^>]*href=["\']([^"\']+)["\'][^>]*>\s*Trang sau\s*</a>', pdiv, re.S | re.I)
    if next_m:
        href = normalize_url(next_m.group(1), page_url)
        if href and href != normalize_url(page_url):
            return href

    curr_m = re.search(r"<span\b[^>]*>\s*(\d+)\s*</span>", pdiv, re.I)
    if curr_m:
        target_num = str(int(curr_m.group(1)) + 1)
        for link_m in re.finditer(r'<a\b[^>]*href=["\']([^"\']+)["\'][^>]*>\s*(\d+)\s*</a>', pdiv, re.I):
            if link_m.group(2) == target_num:
                href = normalize_url(link_m.group(1), page_url)
                if href and href != normalize_url(page_url):
                    return href
    return ""


def _extract_js_var(html, name, default=""):
    match = re.search(r'var\s+%s\s*=\s*([\'"])(.*?)\1' % re.escape(name), html or "", re.S)
    return match.group(2) if match else default


def _format_movie_display_title(movie):
    title = (movie.get("title") or "").strip()
    parts = []
    ep_badge = (movie.get("episode_total") or movie.get("label") or "").strip()
    if ep_badge:
        parts.append(ep_badge)
    lang_badge = (movie.get("lang_badge") or "").strip()
    if lang_badge:
        parts.append(lang_badge)
    if parts:
        return "%s [%s]" % (title, " • ".join(parts))
    return title


def extract_movie_meta_from_html(html, url):
    """Trich xuat day du thong tin metadata & trang thai Phu de / Thuyet minh tu HTML chi tiet."""
    url = normalize_url(url)
    title_m = re.search(r'<h1\b[^>]*class=["\']header-title["\'][^>]*>(.*?)</h1>', html, re.S | re.I)
    title = clean_text(title_m.group(1)) if title_m else ""
    if not title:
        title = clean_text(_extract_js_var(html, "name_title"))
    if not title:
        h1_m = re.search(r'<h1\b[^>]*class=["\']titleplay2["\'][^>]*>(.*?)</h1>', html, re.S | re.I)
        if h1_m:
            title = clean_text(h1_m.group(1))
            title = re.sub(r"\s*-\s*Tập\s+.*$", "", title, flags=re.I)

    poster_m = re.search(r'<img\b[^>]*class=["\'][^"\']*\bc13\b[^"\']*["\'][^>]*>', html, re.I)
    poster = normalize_url(attr(poster_m.group(0), "src"), url) if poster_m else ""
    if not poster:
        poster = normalize_url(_extract_js_var(html, "name_fixload"), url)

    genres_m = re.search(
        r'<h2\b[^>]*class=["\']fontf1["\'][^>]*>\s*THỂ LOẠI:\s*<span\b[^>]*class=["\']fontf8["\'][^>]*>(.*?)</span>',
        html,
        re.S | re.I,
    )
    genres = clean_text(genres_m.group(1)) if genres_m else ""

    # Luu y: Tren vn2.im, muc "DIEN VIEN PHIM:" thuc te chua Quoc gia / Danh muc
    country_m = re.search(
        r'<span\b[^>]*class=["\']fontf1["\'][^>]*>\s*DIỄN VIÊN PHIM:\s*</span>\s*<span\b[^>]*class=["\']fontf8["\'][^>]*>(.*?)</span>',
        html,
        re.S | re.I,
    )
    country = clean_text(country_m.group(1)) if country_m else ""
    if not country:
        country = clean_text(_extract_js_var(html, "name_quocgia"))

    status_m = re.search(
        r'TRẠNG THÁI:\s*<span\b[^>]*class=["\']fontf2["\'][^>]*>(.*?)</span>\s*</p>',
        html,
        re.S | re.I,
    )
    if not status_m:
        status_m = re.search(
            r'TRẠNG THÁI:\s*<span\b[^>]*class=["\']fontf2["\'][^>]*>(.*?)</span>',
            html,
            re.S | re.I,
        )
    status = clean_text(status_m.group(1)) if status_m else ""
    is_completed = "hoàn tất" in status.lower() or "full" in status.lower()

    ep_total = ""
    ep_tot_m = re.search(r"(\d+\s*/\s*\d+)", status)
    if ep_tot_m:
        ep_total = re.sub(r"\s+", "", ep_tot_m.group(1))
    elif _extract_js_var(html, "sv_name"):
        ep_total = clean_text(_extract_js_var(html, "sv_name"))

    # Trich xuat noi dung phim, dao dien va dien vien that tu wiew_info va boxblack/boxinfo2
    plot_paragraphs = []
    director = ""
    actors = ""

    wiew_m = re.search(r'<div\b[^>]*class=["\']wiew_info["\'][^>]*>(.*?)</div>\s*</div>', html, re.S | re.I)
    if wiew_m:
        for p_m in re.finditer(r"<p\b[^>]*>(.*?)</p>", wiew_m.group(1), re.S | re.I):
            txt = clean_text(p_m.group(1))
            if txt:
                plot_paragraphs.append(txt)

    for box_m in re.finditer(r'<div\b[^>]*class=["\']boxblack["\'][^>]*>\s*<div\b[^>]*class=["\']boxinfo2["\'][^>]*>(.*?)</div>\s*</div>', html, re.S | re.I):
        inner = box_m.group(1)
        items = re.findall(r"<(?:p|div)\b[^>]*>(.*?)</(?:p|div)>", inner, re.S | re.I)
        if not items:
            items = [inner]
        for raw_item in items:
            txt = clean_text(raw_item)
            if not txt:
                continue
            dir_m = re.match(r"^(?:Đạo diễn(?: bộ phim .*?)?(?: là)?)\s*:\s*(.+)$", txt, re.I)
            act_m = re.match(r"^(?:Diễn viên(?: chính)?)\s*:\s*(.+)$", txt, re.I)
            if dir_m:
                director = dir_m.group(1).strip().rstrip(".")
            elif act_m:
                actors = act_m.group(1).strip().rstrip(".")
            else:
                plot_paragraphs.append(txt)

    if not plot_paragraphs:
        vid_info_m = re.search(r'<div\b[^>]*class=["\']boxinfo["\'][^>]*>\s*<div\b[^>]*class=["\']fontf8["\'][^>]*>(.*?)</div>', html, re.S | re.I)
        if vid_info_m:
            txt = clean_text(vid_info_m.group(1))
            if txt:
                plot_paragraphs.append(txt)

    plot = "\n".join(dict.fromkeys(plot_paragraphs))

    original_title = ""
    year = extract_year(title)
    if plot_paragraphs:
        paren_m = re.search(r"\(([^()]{3,80})\)", plot_paragraphs[0])
        if paren_m:
            cand = paren_m.group(1).strip()
            if not re.match(r"^(?:vn2|tap|tập|vietsub|thuyết minh)", cand, re.I):
                original_title = cand
                y2 = extract_year(cand)
                if y2:
                    year = y2
    if not year:
        year = extract_year(plot[:400])

    # Xac dinh chinh xac Phien ban ngon ngu co tren trang
    form_m = re.search(r'<(?:div|table)\b[^>]*class=["\']formnum["\'][^>]*>(.*?)</table>', html, re.S | re.I)
    form_html = form_m.group(1) if form_m else ""
    ep_hrefs = [m.lower() for m in re.findall(r'href=["\']([^"\']+)["\']', form_html, re.I)]

    has_sub = any("-vietsub-" in href for href in ep_hrefs)
    has_dub = any(("-thuyet-minh-" in href or "-tm2-" in href) for href in ep_hrefs)
    if not has_sub and not has_dub and "/video/" in url:
        # Trang /video/ mot tap mac dinh la Thuyet minh hoac Long tieng
        has_dub = True

    is_long_tieng = False
    if has_dub:
        hint_text = (title + " " + plot[:250]).lower()
        if "lồng tiếng" in hint_text or "hồng kông" in country.lower() or "hong kong" in country.lower():
            is_long_tieng = True

    if has_sub and has_dub:
        lang_badge = "Vietsub + Lồng Tiếng" if is_long_tieng else "Vietsub + Thuyết Minh"
    elif has_dub:
        lang_badge = "Lồng Tiếng" if is_long_tieng else "Thuyết Minh"
    elif has_sub:
        lang_badge = "Phụ Đề (Vietsub)"
    else:
        lang_badge = ""

    return {
        "title": title,
        "original_title": original_title,
        "poster": poster,
        "thumb": poster,
        "genres": genres,
        "country": country,
        "status": status,
        "episode_total": ep_total,
        "is_completed": is_completed,
        "plot": plot,
        "director": director,
        "actors": actors,
        "year": year,
        "has_sub": has_sub,
        "has_dub": has_dub,
        "is_long_tieng": is_long_tieng,
        "lang_badge": lang_badge,
    }


def _apply_meta_to_movie(movie, meta):
    if not meta:
        return
    for key in (
        "original_title",
        "genres",
        "status",
        "plot",
        "director",
        "actors",
        "has_sub",
        "has_dub",
        "is_long_tieng",
        "lang_badge",
        "is_completed",
    ):
        if key in meta and meta[key] not in ("", None):
            movie[key] = meta[key]
        elif key not in movie and key in meta:
            movie[key] = meta[key]

    if meta.get("country") and not movie.get("country"):
        movie["country"] = meta["country"]
    if meta.get("poster") and not movie.get("poster"):
        movie["poster"] = meta["poster"]
    if meta.get("thumb") and not movie.get("thumb"):
        movie["thumb"] = meta["thumb"]
    if meta.get("episode_total") and not movie.get("episode_total"):
        movie["episode_total"] = meta["episode_total"]
    if safe_int(meta.get("year")) > 0 and not safe_int(movie.get("year")):
        movie["year"] = safe_int(meta["year"])
    movie["display_title"] = _format_movie_display_title(movie)


def enrich_movies_metadata(movies, enabled=True):
    """Bo sung metadata & nhan ngon ngu cho danh sach phim bang cache SQLite + tai song song."""
    if not movies:
        return movies

    urls = [m["url"] for m in movies if m.get("url")]
    cached = get_cached_meta_many(urls)

    missing_urls = []
    for movie in movies:
        url = movie.get("url")
        if not url:
            continue
        if url in cached:
            _apply_meta_to_movie(movie, cached[url])
        elif enabled:
            missing_urls.append(url)

    if enabled and missing_urls:
        fetched_map = {}

        def fetch_one(target_url):
            try:
                html = request_text(target_url, timeout=6)
                return target_url, extract_movie_meta_from_html(html, target_url)
            except Exception:
                return target_url, None

        with ThreadPoolExecutor(max_workers=min(8, len(missing_urls))) as executor:
            for target_url, meta in executor.map(fetch_one, missing_urls):
                if meta:
                    fetched_map[target_url] = meta

        if fetched_map:
            put_cached_meta_many(fetched_map)
            for movie in movies:
                meta = fetched_map.get(movie.get("url"))
                if meta:
                    _apply_meta_to_movie(movie, meta)

    return movies


def get_listing(url, enrich=True):
    url = normalize_url(url)
    html = request_text(url)
    movies = parse_movies(html, url)
    enrich_movies_metadata(movies, enabled=enrich)
    return {
        "movies": movies,
        "next_url": find_next_page(html, url),
    }


def search_movies(keyword, url="", enrich=True):
    if url:
        return get_listing(url, enrich=enrich)

    keyword = (keyword or "").strip()
    if not keyword:
        return {"movies": [], "next_url": ""}

    slug = search_slug(keyword)
    if not slug:
        return {"movies": [], "next_url": ""}

    target_url = BASE_URL + "/tim-kiem/" + slug
    html = request_text(target_url)
    movies = parse_movies(html, target_url)
    next_url = find_next_page(html, target_url)

    if not movies:
        # Thu fallback qua ASP.NET form POST mot lan neu slug tim kiem dac biet khac quy uoc
        try:
            home_html = request_text(BASE_URL + "/", use_session=True)
            vs_m = re.search(r'id="__VIEWSTATE"\s+value="([^"]*)"', home_html)
            vsg_m = re.search(r'id="__VIEWSTATEGENERATOR"\s+value="([^"]*)"', home_html)
            ev_m = re.search(r'id="__EVENTVALIDATION"\s+value="([^"]*)"', home_html)
            if vs_m and vsg_m:
                form_data = {
                    "__VIEWSTATE": vs_m.group(1),
                    "__VIEWSTATEGENERATOR": vsg_m.group(1),
                    "ctl00$txtSearch": keyword,
                    "ctl00$btnSearch": "Tìm kiếm",
                }
                if ev_m:
                    form_data["__EVENTVALIDATION"] = ev_m.group(1)
                raw, resp_hdrs, final_url, _ = request_raw(
                    BASE_URL + "/",
                    data=form_data,
                    headers={"Referer": BASE_URL + "/"},
                    timeout=10,
                    use_session=True,
                )
                encoding = resp_hdrs.get("Content-Encoding", "") if resp_hdrs else ""
                post_html = _decode_response_bytes(raw, encoding, "utf-8")
                movies = parse_movies(post_html, final_url)
                next_url = find_next_page(post_html, final_url)
        except Exception:
            pass

    enrich_movies_metadata(movies, enabled=enrich)
    return {
        "movies": movies,
        "next_url": next_url,
    }


def get_language_listing(group_key, page=1):
    """Loc va phan trang phim theo ngon ngu (Thuyet minh / Long tieng / Vietsub / Song ngu)."""
    group = LANGUAGE_GROUPS.get(group_key)
    if not group:
        raise ScraperError("Danh mục ngôn ngữ không hợp lệ.")

    page = max(1, safe_int(page) or 1)
    start = (page - 1) * LANGUAGE_PAGE_SIZE
    end = page * LANGUAGE_PAGE_SIZE
    predicate = group["predicate"]
    sources = list(group["sources"])

    # Quet lan luot tung nguon (vd: long_tieng quet hong-kong-9 + phim-moi)
    matched = []
    seen = set()
    has_more_pages = False
    max_site_pages_per_source = max(4, page * 2 + 2)

    for src_base in sources:
        current_url = src_base
        pages_fetched = 0
        while current_url and pages_fetched < max_site_pages_per_source and len(matched) < end + 1:
            pages_fetched += 1
            html = request_text(current_url)
            site_movies = parse_movies(html, current_url)
            enrich_movies_metadata(site_movies, enabled=True)
            for movie in site_movies:
                if movie["url"] in seen:
                    continue
                if predicate(movie):
                    seen.add(movie["url"])
                    matched.append(movie)
            next_url = find_next_page(html, current_url)
            if not site_movies:
                next_url = ""
            current_url = next_url
        if current_url:
            has_more_pages = True

    page_movies = matched[start:end]
    has_next = len(matched) > end or has_more_pages
    return {
        "movies": page_movies,
        "has_next": has_next,
        "title": group["title"],
    }


def _fix_taps_spec(raw_spec):
    """Port ham FixTaps() trong add-tap.js."""
    text = (raw_spec or "").replace("vvv", "&").replace("bbb", "=").replace("fvf", "&fixs").replace("=stop", "")
    if "-End" in text:
        num_fix_end = text.replace("-End", "")
        if num_fix_end.isdigit():
            text = "%s&fixs%s=%s" % (num_fix_end, num_fix_end, text)
        elif "&" in text:
            num_cat = text.split("&", 1)[0].replace("-End", "")
            if num_cat.isdigit():
                text = "%s&fixs%s=%s" % (num_cat, num_cat, text)
    elif text.lower() == "full":
        text = "1&fixs1=Full"
    return text


def _build_add_tap_list(tap_start_str, tap_total_spec, num_cut=50):
    """Port logic sinh danh sach tap an o giua (tu tap 11 den tap_end - num_cut) cua add-tap.js."""
    if not tap_start_str or not tap_total_spec:
        return []
    tap_total = _fix_taps_spec(tap_total_spec)

    if "fixscat&" in tap_total and "&cut" in tap_total:
        after = tap_total.split("fixscat&", 1)[1]
        fix_start_str = after.split("&", 1)[0]
        if fix_start_str.isdigit():
            fix_start = int(fix_start_str)
            num_start = safe_int(tap_start_str, 1)
            if num_start > 1:
                tap_start_str = str(fix_start + (num_start - 1))
            else:
                tap_start_str = str(fix_start)

    head_m = re.match(r"^(\d+)", tap_total)
    if not head_m:
        return []
    tap_begin = safe_int(tap_start_str, -1)
    tap_end = int(head_m.group(1))
    if tap_begin < 0 or tap_begin > tap_end:
        return []

    fix_list = {}
    fix_text = tap_total[len(head_m.group(1)):]
    if fix_text:
        for part in ("fixs" + fix_text).split("fixs")[1:]:
            if not part:
                continue
            num_m = re.match(r"^(\d+)", part)
            if not num_m:
                continue
            fix_num = num_m.group(1)
            rest = part[len(fix_num):]
            replace_list = []
            if rest.startswith("="):
                replace_text = rest[1:]
                if replace_text:
                    replace_list = [v for v in replace_text.split("&") if v]
            fix_list[fix_num] = replace_list

    tap_list = []
    for tap in range(tap_begin, tap_end + 1):
        key = str(tap)
        if key in fix_list:
            tap_list.extend(fix_list[key])
        else:
            tap_list.append(key)

    limit = max(0, len(tap_list) - max(0, int(num_cut)))
    return tap_list[:limit]


def expand_add_tap_from_watch_html(watch_html):
    """Giai ma cac danh sach tap bi cat o giua (listvie_linktap1 / 2 / 3) tu HTML trang xem phim."""
    channel_full = _extract_js_var(watch_html, "channel_full")
    name_fixfull = _extract_js_var(watch_html, "name_fixfull")
    name_fixfull2 = _extract_js_var(watch_html, "name_fixfull2")
    nameurl = _extract_js_var(watch_html, "nameurl")
    name_idphim = _extract_js_var(watch_html, "name_idphim")

    if not nameurl or not name_idphim:
        return {}

    full_addjs = channel_full.split("links", 1)[0] if "links" in channel_full else ""
    if "cutSt" not in full_addjs and "sv22" not in name_fixfull:
        return {}

    num_cut = 0 if "sv22" in name_fixfull else 50
    result = {}

    if "totTm" in full_addjs and "cutSt" in full_addjs and "totSu" in full_addjs:
        pos1 = full_addjs.index("totTm")
        pos2 = full_addjs.index("cutSt")
        pos3 = full_addjs.index("totSu")
        tap_start1 = full_addjs[:pos1]
        tap_total1 = full_addjs[pos1 + 5:pos2]
        tap_start3 = full_addjs[pos2 + 5:pos3]
        tap_total3 = full_addjs[pos3 + 5:]

        tm_names = _build_add_tap_list(tap_start1, tap_total1, num_cut=num_cut)
        if tm_names:
            result["thuyet_minh"] = [
                {
                    "title": name,
                    "url": "%s/phim/%s/tap-%s-thuyet-minh-%s" % (BASE_URL, nameurl, fix_tap_url_name(name), name_idphim),
                }
                for name in tm_names
            ]

        sub_names = _build_add_tap_list(tap_start3, tap_total3, num_cut=num_cut)
        if sub_names:
            result["vietsub"] = [
                {
                    "title": name,
                    "url": "%s/phim/%s/tap-%s-vietsub-%s" % (BASE_URL, nameurl, fix_tap_url_name(name), name_idphim),
                }
                for name in sub_names
            ]

    if "sv22" in name_fixfull and name_fixfull2:
        sv2_label = name_fixfull.split("sv22")[-1].strip() or "Server 2"
        sv2_names = _build_add_tap_list("1", name_fixfull2, num_cut=0)
        if sv2_names:
            result["tm2"] = {
                "title": sv2_label,
                "episodes": [
                    {
                        "title": name,
                        "url": "%s/phim/%s/tap-%s-tm2-%s" % (BASE_URL, nameurl, fix_tap_url_name(name), name_idphim),
                    }
                    for name in sv2_names
                ],
            }

    return result


def episode_sort_key(ep):
    title = (ep.get("title") or "").strip()
    if title.lower() == "full":
        return (0, 0, "")
    match = re.match(r"^(\d+)(.*)$", title)
    if match:
        return (1, int(match.group(1)), match.group(2).lower())
    url = (ep.get("url") or "").lower()
    m_url = re.search(r"/tap-(\d+)(?:-([a-z0-9]+))?-", url)
    if m_url:
        return (1, int(m_url.group(1)), m_url.group(2) or "")
    return (2, 0, title.lower())


def sort_episodes_ascending(episodes):
    return sorted(episodes, key=episode_sort_key)


def _dedup_episodes(episodes):
    out = []
    seen = set()
    for ep in episodes:
        u = ep.get("url")
        if not u or u in seen:
            continue
        seen.add(u)
        out.append(ep)
    return out


def _parse_episode_groups_from_detail_html(html, page_url, is_long_tieng=False):
    form_m = re.search(r'<(?:div|table)\b[^>]*class=["\']formnum["\'][^>]*>(.*?)</table>', html, re.S | re.I)
    if not form_m:
        return [], False

    form_html = form_m.group(1)
    needs_expansion = False
    tm_eps = []
    tm2_eps = []
    sub_eps = []

    for box_m in re.finditer(r'<div\b[^>]*class=["\']box_film_title["\'][^>]*>(.*?)</div>', form_html, re.S | re.I):
        box = box_m.group(1)
        if "..." in box or "XEM FULL" in box.upper() or "listvie_linktap" in box:
            needs_expansion = True

        for a_m in re.finditer(r'<a\b[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>', box, re.S | re.I):
            href = normalize_url(a_m.group(1), page_url)
            ep_label = clean_text(a_m.group(2))
            if not href or not ep_label:
                continue
            if ep_label.upper() == "XEM FULL":
                needs_expansion = True
                continue
            item = {"title": ep_label, "url": href}
            lower_href = href.lower()
            if "-vietsub-" in lower_href:
                sub_eps.append(item)
            elif "-tm2-" in lower_href:
                tm2_eps.append(item)
            else:
                tm_eps.append(item)

    groups = []
    if tm_eps:
        groups.append({
            "key": "thuyet_minh",
            "title": "Lồng Tiếng" if is_long_tieng else "Thuyết Minh",
            "episodes": _dedup_episodes(tm_eps),
        })
    if sub_eps:
        groups.append({
            "key": "vietsub",
            "title": "Phụ Đề (Vietsub)",
            "episodes": _dedup_episodes(sub_eps),
        })
    if tm2_eps:
        groups.append({
            "key": "tm2",
            "title": "Thuyết Minh / Lồng Tiếng (Server phụ)",
            "episodes": _dedup_episodes(tm2_eps),
        })

    return groups, needs_expansion


def display_group_title(group):
    base = group.get("title") or "Danh sách tập"
    eps = group.get("episodes") or []
    count = len(eps)
    if count == 1 and (eps[0].get("title") or "").strip().lower() == "full":
        return "%s - Full" % base
    if count > 0:
        return "%s (%d tập)" % (base, count)
    return base


def get_detail(url, load_all_episodes=True, preferred_lang=0):
    url = normalize_url(url)
    html = request_text(url)
    meta = extract_movie_meta_from_html(html, url)

    groups, needs_expansion = _parse_episode_groups_from_detail_html(
        html, url, is_long_tieng=bool(meta.get("is_long_tieng"))
    )

    # Tim link trang xem dau tien de lay JS expand_add_tap hoac lam watch_url mac dinh
    watch_url = ""
    play_btn_m = re.search(r'<div\b[^>]*class=["\']playphim["\'][^>]*>\s*<a\b[^>]*href=["\']([^"\']+)["\']', html, re.S | re.I)
    if play_btn_m:
        watch_url = normalize_url(play_btn_m.group(1), url)
    if not watch_url and groups:
        watch_url = groups[0]["episodes"][0]["url"]
    if not watch_url and "/video/" in url:
        watch_url = url

    # Neu la phim dai tap (>50 tap) co moc XEM FULL / ..., goi watch page de mo rong day du tap
    if load_all_episodes and needs_expansion and watch_url:
        try:
            watch_html = request_text(watch_url)
            expanded = expand_add_tap_from_watch_html(watch_html)

            # Parse them cac tap co dinh tren watch_html (thuong co 1..10 va 50 tap cuoi)
            watch_groups, _ = _parse_episode_groups_from_detail_html(
                watch_html, watch_url, is_long_tieng=bool(meta.get("is_long_tieng"))
            )
            by_key = {g["key"]: g for g in groups}
            for wg in watch_groups:
                key = wg["key"]
                if key in by_key:
                    by_key[key]["episodes"] = _dedup_episodes(by_key[key]["episodes"] + wg["episodes"])
                else:
                    by_key[key] = wg
                    groups.append(wg)

            for key in ("thuyet_minh", "vietsub"):
                if key in expanded and key in by_key:
                    by_key[key]["episodes"] = _dedup_episodes(by_key[key]["episodes"] + expanded[key])
                elif key in expanded:
                    new_g = {
                        "key": key,
                        "title": "Lồng Tiếng" if (key == "thuyet_minh" and meta.get("is_long_tieng")) else (
                            "Thuyết Minh" if key == "thuyet_minh" else "Phụ Đề (Vietsub)"
                        ),
                        "episodes": _dedup_episodes(expanded[key]),
                    }
                    by_key[key] = new_g
                    groups.append(new_g)

            if "tm2" in expanded:
                tm2_info = expanded["tm2"]
                if "tm2" in by_key:
                    by_key["tm2"]["title"] = tm2_info["title"]
                    by_key["tm2"]["episodes"] = _dedup_episodes(by_key["tm2"]["episodes"] + tm2_info["episodes"])
                else:
                    groups.append({
                        "key": "tm2",
                        "title": tm2_info["title"],
                        "episodes": _dedup_episodes(tm2_info["episodes"]),
                    })
        except Exception:
            pass

    for g in groups:
        g["episodes"] = sort_episodes_ascending(g.get("episodes") or [])

    # Sap xep nhom tap theo tuy chon uu tien cua nguoi dung
    pref = safe_int(preferred_lang, 0)
    if pref == 1:
        order = {"thuyet_minh": 0, "tm2": 1, "vietsub": 2}
        groups.sort(key=lambda g: order.get(g.get("key"), 9))
    elif pref == 2:
        order = {"vietsub": 0, "thuyet_minh": 1, "tm2": 2}
        groups.sort(key=lambda g: order.get(g.get("key"), 9))

    # Cap nhat cache voi metadata moi nhat
    put_cached_meta_many({url: meta})

    detail = dict(meta)
    detail["url"] = url
    detail["watch_url"] = watch_url
    detail["episode_groups"] = groups
    return detail


def _detect_source_lang_label(episode_url):
    lower = (episode_url or "").lower()
    if "-vietsub-" in lower:
        return "Phụ Đề (Vietsub)"
    if "-tm2-" in lower:
        return "Thuyết Minh (Phụ)"
    return "Thuyết Minh"


def get_episode_sources(episode_url):
    """Lay danh sach Server 1 / Server 2 / Server 3 tu trang xem phim (khong probe truoc)."""
    episode_url = normalize_url(episode_url)
    html = request_text(episode_url)
    lang_label = _detect_source_lang_label(episode_url)

    sources = []
    seen = set()
    div_m = re.search(r'<div\b[^>]*class=["\']num_film2["\'][^>]*>(.*?)</div>', html, re.S | re.I)
    if div_m:
        for a_m in re.finditer(r'<a\b[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>', div_m.group(1), re.S | re.I):
            srv_url = normalize_url(a_m.group(1), episode_url)
            srv_name = clean_text(a_m.group(2)) or "Server"
            if not srv_url or srv_url in seen:
                continue
            seen.add(srv_url)
            sources.append({
                "name": srv_name,
                "url": srv_url,
                "lang": lang_label,
                "kind": "HLS/MP4",
            })

    if not sources:
        sources.append({
            "name": "Server 1",
            "url": episode_url,
            "lang": lang_label,
            "kind": "HLS/MP4",
        })
    return sources


def _fetch_check_user(force_refresh=False):
    now = time.time()
    curr_hour = time.localtime().tm_hour
    with _CHECK_USER_LOCK:
        if (
            not force_refresh
            and _CHECK_USER_CACHE["keyfix"]
            and _CHECK_USER_CACHE["hour"] == curr_hour
            and (now - _CHECK_USER_CACHE["fetched_at"]) < 45.0
        ):
            return dict(_CHECK_USER_CACHE)

    check_url = DATA_BASE_URL + "/check-user.php?url=www.vn2.im"
    raw, resp_headers, _, _ = request_raw(
        check_url,
        headers={"Referer": BASE_URL + "/"},
        timeout=10,
        use_session=False,
    )
    js_text = _decode_response_bytes(raw, resp_headers.get("Content-Encoding", "") if resp_headers else "", "utf-8")

    kf_m = re.search(r'var\s+channel_keyfix\s*=\s*"([^"]*)"', js_text)
    keyfix = kf_m.group(1) if kf_m else ""
    ct_m = re.search(r'var\s+channel_time\s*=\s*"([^"]*)"', js_text)
    channel_time = ct_m.group(1) if ct_m else ""

    cookie_pairs = []
    if resp_headers is not None:
        all_cookies = resp_headers.get_all("Set-Cookie") if hasattr(resp_headers, "get_all") else []
        if not all_cookies:
            single = resp_headers.get("Set-Cookie")
            if single:
                all_cookies = [single]
        for sc in all_cookies:
            pair = sc.split(";", 1)[0].strip()
            if pair:
                cookie_pairs.append(pair)
    cookie_header = "; ".join(cookie_pairs)

    with _CHECK_USER_LOCK:
        _CHECK_USER_CACHE["keyfix"] = keyfix
        _CHECK_USER_CACHE["cookie"] = cookie_header
        _CHECK_USER_CACHE["channel_time"] = channel_time
        _CHECK_USER_CACHE["hour"] = curr_hour
        _CHECK_USER_CACHE["fetched_at"] = time.time()
        return dict(_CHECK_USER_CACHE)


def _extract_stream_candidates_from_player_html(player_html):
    """Trich xuat danh sach link phat that + phu de + canh bao node CDN hong tu play.php / play2.php."""
    broken_hosts = set()
    cdn_m = re.search(r'mynumcdn\s*:\s*"([^"]+)"', player_html)
    if cdn_m:
        for node in re.findall(r"(ns\d+)-", cdn_m.group(1), re.I):
            broken_hosts.add(node.lower() + ".cloudcdnvn.com")

    urls_by_priority = []
    for var_name in ("link_video_hd", "link_video_sd", "link_video_load"):
        for found in re.findall(r'var\s+%s\s*=\s*"(https?://[^"]+)"' % var_name, player_html, re.I):
            cleaned = found.strip()
            if cleaned and cleaned not in urls_by_priority:
                urls_by_priority.append(cleaned)

    # Dua cac host khoe len dau, node nam trong danh sach -loi xuong cuoi
    healthy = []
    flagged = []
    for u in urls_by_priority:
        host = (urlparse(u).hostname or "").lower()
        if host in broken_hosts:
            flagged.append(u)
        else:
            healthy.append(u)

    subtitles = []
    seen_subs = set()
    for sub_var in ("link_textsub", "link_textsub2"):
        for sub_u in re.findall(r'var\s+%s\s*=\s*"(https?://[^"]+)"' % sub_var, player_html, re.I):
            su = sub_u.strip()
            if su and su not in seen_subs:
                seen_subs.add(su)
                subtitles.append({"url": su, "label": "Vietsub", "referer": DATA_BASE_URL + "/"})
    for trk_u in re.findall(r'["\']?(?:file|src)["\']?\s*:\s*["\'](https?://[^"\']+\.(?:srt|vtt)[^"\']*)["\']', player_html, re.I):
        su = trk_u.strip()
        if su and su not in seen_subs:
            seen_subs.add(su)
            subtitles.append({"url": su, "label": "Phụ đề", "referer": DATA_BASE_URL + "/"})

    play2_urls = re.findall(r'var\s+php_content_embed\s*=\s*"(https?://[^"]+)"', player_html, re.I)

    return {
        "candidates": healthy + flagged,
        "subtitles": subtitles,
        "play2_urls": play2_urls,
    }


def _fetch_watch_page_with_cookie(ep_url):
    raw, ep_hdrs, _, _ = request_raw(
        ep_url,
        headers={"Referer": BASE_URL + "/"},
        timeout=12,
        use_session=False,
    )
    enc = ep_hdrs.get("Content-Encoding", "") if ep_hdrs else ""
    charset = ep_hdrs.get_content_charset() if hasattr(ep_hdrs, "get_content_charset") else None
    watch_html = _decode_response_bytes(raw, enc, charset or "utf-8")

    mycookieplay = ""
    if ep_hdrs is not None:
        all_cookies = ep_hdrs.get_all("Set-Cookie") if hasattr(ep_hdrs, "get_all") else []
        if not all_cookies:
            single = ep_hdrs.get("Set-Cookie")
            if single:
                all_cookies = [single]
        for sc in all_cookies:
            m = re.search(r"iduser-myplay=([^;\s]+)", sc or "")
            if m:
                mycookieplay = m.group(1).strip()
                break
    return watch_html, mycookieplay


def _build_play_php_url(watch_html, ep_url, channel_keyfix, mycookieplay=""):
    ck_m = re.search(r"var\s+channel_key\s*=\s*'(\d+)'\s*\+\s*channel_keyfix", watch_html)
    tv_m = re.search(r"var\s+totalview\s*=\s*channel_key\s*\+\s*'([^']+)'\s*\+\s*screen\.width", watch_html)
    if not ck_m or not tv_m:
        return "", []

    ck_prefix = ck_m.group(1)
    tv_mid = tv_m.group(1)

    name_fixfull = _extract_js_var(watch_html, "name_fixfull")
    name_fixfull2 = _extract_js_var(watch_html, "name_fixfull2")
    name_numget = _extract_js_var(watch_html, "name_numget")
    name_idphim = _extract_js_var(watch_html, "name_idphim")
    name_fix = _extract_js_var(watch_html, "name_fix")
    name_fixload = _extract_js_var(watch_html, "name_fixload")
    domain_api = _extract_js_var(watch_html, "domain_api", DATA_BASE_URL + "/play")
    channel_full = _extract_js_var(watch_html, "channel_full")
    channel_fix_direct = _extract_js_var(watch_html, "channel_fix")
    channel2_fix = _extract_js_var(watch_html, "channel2_fix")
    channel3_fix = _extract_js_var(watch_html, "channel3_fix")
    link_fullhd = _extract_js_var(watch_html, "link_fullhd")

    if channel_full:
        channel_fix = channel_full.split("links", 1)[1] if "links" in channel_full else channel_full
    else:
        channel_fix = channel_fix_direct

    channel_fix_iframe = ""
    if "ok.ru" in channel_fix:
        channel_fix_iframe = channel_fix
        channel_fix = ""

    content_link1 = channel_fix.strip()
    content_link2 = channel2_fix.strip()
    fix_load3 = name_fixfull.strip()
    fix_load4 = "nofb1" if "nofb1" in channel_fix else ""
    link_content_drive = channel3_fix.strip()
    cookie_num = name_fix.strip()

    direct_candidates = []
    ep_norm = ep_url.replace("/vn2-", "-vn2-")
    if "https:" in content_link1 and "-vn2-" not in ep_norm:
        if "https:" in link_fullhd:
            direct_candidates.append(link_fullhd.strip())
        direct_candidates.append(content_link1)

    start_tap = ep_url.rfind("tap-")
    sv_tap_now = "-thuyet-minh-"
    if start_tap != -1:
        if "-vietsub-" in ep_url[start_tap:]:
            sv_tap_now = "-vietsub-"
        elif "-tm2-" in ep_url[start_tap:]:
            sv_tap_now = "-tm2-"
    end_cat = ep_url.find(sv_tap_now, start_tap) if start_tap != -1 else -1
    name_tapphim = ep_url[start_tap + 4:end_cat] if (start_tap != -1 and end_cat != -1) else ""

    num_sv = "111"
    if "-vietsub-" in ep_url and "fix-to111" not in name_fixfull:
        num_sv = "333"
    elif "-tm2-" in ep_url:
        num_sv = "222"
    if "fix-to333" in name_fixfull:
        num_sv = "333"
    if "/video/" in ep_url and "-thuyet-minh-" not in ep_url and "-vietsub-" not in ep_url:
        name_tapphim = link_content_drive

    # Luon dung kich thuoc man hinh chuan (khong +2000 anti-adblock) va cookie iduser-myplay that
    device_user = "notyescookienumw"
    numchecks = "1"
    fixpeaksv1 = "usersvcatasiavn"
    channel_key = "%s%s%scatcookie%s" % (ck_prefix, channel_keyfix, mycookieplay or "", device_user)
    totalview = "%s%s1920clientw1280%s" % (channel_key, tv_mid, fixpeaksv1)
    idplay = "%ssv%sid%dnumview%schankey%s" % (name_tapphim, num_sv, safe_int(name_idphim), totalview, numchecks)

    embed_url = (
        "%s/js_fix/9x/play.php?link=%s"
        "vn2fix1%svn2fix2%svn2fix3%s"
        "vn2fixload%svn2fixurl4%svn2fixurl5"
        "6O548l721190%s%s"
        "vn2myname%sfolderfix%scatnumget%s%s"
    ) % (
        domain_api,
        idplay,
        content_link1,
        content_link2,
        channel_fix_iframe,
        fix_load3,
        fix_load4,
        cookie_num,
        link_content_drive,
        name_fixload,
        name_numget,
        name_fixfull2,
        ep_url,
    )
    embed_url = embed_url.replace("&", "vn2_fix")
    return embed_url, direct_candidates


def _is_hls_url(url):
    return ".m3u8" in (urlparse(url).path or "").lower() or ".m3u8" in url.lower()


def _parse_total_size_from_headers(headers, status_code):
    cr = headers.get("Content-Range") or ""
    m = re.search(r"/(\d+)\s*$", cr)
    if m:
        return safe_int(m.group(1), 0)
    if status_code == 200:
        return safe_int(headers.get("Content-Length"), 0)
    return 0


def _probe_mp4_url(stream_url, referer=""):
    try:
        resp = H2_CLIENT.get(
            stream_url,
            headers=build_video_stream_headers(referer or (DATA_BASE_URL + "/"), "bytes=0-1023"),
            timeout=httpx.Timeout(5.0, connect=3.5),
        )
    except Exception:
        return False, 0

    if resp.status_code not in (200, 206):
        return False, 0
    ctype = (resp.headers.get("Content-Type") or "").lower()
    sample = resp.content[:1024]
    if "text/html" in ctype or b"<html" in sample[:256].lower():
        return False, 0
    if "video/" in ctype or b"ftyp" in sample[:64] or b"moov" in sample or b"mdat" in sample or len(sample) >= 32:
        total_size = _parse_total_size_from_headers(resp.headers, resp.status_code)
        return True, total_size
    return False, 0


def _probe_hls_url(stream_url, referer=""):
    headers = {"User-Agent": USER_AGENT}
    if referer:
        headers["Referer"] = referer
        parsed = urlparse(referer)
        if parsed.scheme in ("http", "https") and parsed.netloc:
            headers["Origin"] = "%s://%s" % (parsed.scheme, parsed.netloc)
    text = request_text(stream_url, headers=headers, timeout=6)
    return "#EXTM3U" in text


def refresh_mp4_candidates(episode_url):
    """Lay lai danh sach link CDN MP4 moi tu vn2.im / play.php / play2.php khi token cu het han."""
    ep_url = normalize_url(episode_url)
    if not ep_url:
        return []
    candidates = []
    try:
        watch_html, mycookieplay = _fetch_watch_page_with_cookie(ep_url)
        cu = _fetch_check_user(force_refresh=True)
        embed_url, direct_candidates = _build_play_php_url(
            watch_html, ep_url, cu["keyfix"], mycookieplay=mycookieplay
        )
        for u in direct_candidates:
            if u and not _is_hls_url(u) and u not in candidates:
                candidates.append(u)
        if embed_url:
            play_headers = {"Referer": BASE_URL + "/"}
            if cu.get("cookie"):
                play_headers["Cookie"] = cu["cookie"]
            play_html = request_text(embed_url, headers=play_headers, timeout=12)
            ext = _extract_stream_candidates_from_player_html(play_html)
            for u in ext["candidates"]:
                if u and not _is_hls_url(u) and u not in candidates:
                    candidates.append(u)
            if not candidates:
                for p2_url in ext["play2_urls"]:
                    try:
                        p2_headers = {"Referer": embed_url}
                        if cu.get("cookie"):
                            p2_headers["Cookie"] = cu["cookie"]
                        p2_html = request_text(p2_url, headers=p2_headers, timeout=12)
                        p2_ext = _extract_stream_candidates_from_player_html(p2_html)
                        for u in p2_ext["candidates"]:
                            if u and not _is_hls_url(u) and u not in candidates:
                                candidates.append(u)
                    except Exception:
                        continue
    except Exception:
        pass
    return candidates


def validate_candidate_url(
    stream_url,
    referer="",
    subtitles=None,
    enable_hls_adblock=True,
    alt_urls=None,
    episode_url="",
    use_mp4_proxy=True,
):
    """Kiem tra luong phat that va dong goi metadata phat cho Kodi."""
    if not stream_url or not stream_url.startswith(("http://", "https://")):
        return None

    subtitles = list(subtitles or [])
    eff_ref = referer or (DATA_BASE_URL + "/")
    if _is_hls_url(stream_url):
        if not _probe_hls_url(stream_url, referer=eff_ref):
            return None
        play_url = stream_url
        if enable_hls_adblock:
            proxy_base = ready_proxy_base()
            if proxy_base:
                play_url = "%s/hls.m3u8?%s" % (
                    proxy_base,
                    urlencode({
                        "u": encode_proxy_token(stream_url),
                        "r": encode_proxy_token(eff_ref),
                    }),
                )
        return {
            "url": play_url if play_url.startswith("http://127.0.0.1:") else (
                play_url + "|" + urlencode({"User-Agent": USER_AGENT, "Referer": eff_ref})
            ),
            "raw_url": stream_url,
            "mime": "application/vnd.apple.mpegurl",
            "headers": {"User-Agent": USER_AGENT, "Referer": eff_ref},
            "subtitles": subtitles,
        }

    ok, total_size = _probe_mp4_url(stream_url, referer=eff_ref)
    if not ok:
        return None

    if use_mp4_proxy:
        proxy_base = ready_proxy_base()
        if proxy_base:
            params = [
                ("u", encode_proxy_token(stream_url)),
                ("r", encode_proxy_token(eff_ref)),
            ]
            alts = [u for u in (alt_urls or []) if u and u != stream_url][:4]
            if alts:
                params.append(("a", encode_proxy_token("\n".join(alts))))
            if episode_url:
                params.append(("ep", encode_proxy_token(episode_url)))
            if total_size > 0:
                params.append(("s", str(total_size)))
            return {
                "url": "%s/video.mp4?%s" % (proxy_base, urlencode(params)),
                "raw_url": stream_url,
                "total_size": total_size,
                "mime": "video/mp4",
                "headers": {},
                "subtitles": subtitles,
            }

    return {
        "url": stream_url + "|" + urlencode({"User-Agent": USER_AGENT, "Referer": eff_ref}),
        "raw_url": stream_url,
        "total_size": total_size,
        "mime": "video/mp4",
        "headers": {"User-Agent": USER_AGENT, "Referer": eff_ref},
        "subtitles": subtitles,
    }


def resolve_stream(episode_url, enable_hls_adblock=True, use_mp4_proxy=True):
    """Giai ma luong phat sach (khong quang cao) cho mot link server cu the."""
    ep_url = normalize_url(episode_url)
    last_err = None

    for attempt in range(2):
        force_refresh = attempt > 0
        watch_html, mycookieplay = _fetch_watch_page_with_cookie(ep_url)
        cu = _fetch_check_user(force_refresh=force_refresh)
        embed_url, direct_candidates = _build_play_php_url(
            watch_html, ep_url, cu["keyfix"], mycookieplay=mycookieplay
        )

        # Thu link truc tiep neu server cho phep bo qua play.php
        for cand in direct_candidates:
            try:
                media = validate_candidate_url(
                    cand,
                    referer=ep_url,
                    subtitles=[],
                    enable_hls_adblock=enable_hls_adblock,
                    alt_urls=direct_candidates,
                    episode_url=ep_url,
                    use_mp4_proxy=use_mp4_proxy,
                )
                if media:
                    return media
            except Exception as exc:
                last_err = exc

        if not embed_url:
            continue

        play_headers = {"Referer": BASE_URL + "/"}
        if cu.get("cookie"):
            play_headers["Cookie"] = cu["cookie"]

        try:
            play_html = request_text(embed_url, headers=play_headers, timeout=12)
        except Exception as exc:
            last_err = exc
            continue

        extracted = _extract_stream_candidates_from_player_html(play_html)
        if not extracted["candidates"] and not extracted["play2_urls"]:
            # Co the gap moc doi gio (:59 -> :00), thu lay token moi o lan lap thu 2
            continue

        for cand in extracted["candidates"]:
            try:
                media = validate_candidate_url(
                    cand,
                    referer=DATA_BASE_URL + "/",
                    subtitles=extracted["subtitles"],
                    enable_hls_adblock=enable_hls_adblock,
                    alt_urls=extracted["candidates"],
                    episode_url=ep_url,
                    use_mp4_proxy=use_mp4_proxy,
                )
                if media:
                    return media
            except Exception as exc:
                last_err = exc

        # Fallback qua play2.php neu tat ca mirror cua play.php deu loi
        for p2_url in extracted["play2_urls"]:
            try:
                p2_headers = {"Referer": embed_url}
                if cu.get("cookie"):
                    p2_headers["Cookie"] = cu["cookie"]
                p2_html = request_text(p2_url, headers=p2_headers, timeout=12)
                p2_ext = _extract_stream_candidates_from_player_html(p2_html)
                subs = p2_ext["subtitles"] or extracted["subtitles"]
                for cand in p2_ext["candidates"]:
                    try:
                        media = validate_candidate_url(
                            cand,
                            referer=DATA_BASE_URL + "/",
                            subtitles=subs,
                            enable_hls_adblock=enable_hls_adblock,
                            alt_urls=p2_ext["candidates"],
                            episode_url=ep_url,
                            use_mp4_proxy=use_mp4_proxy,
                        )
                        if media:
                            return media
                    except Exception as exc:
                        last_err = exc
            except Exception as exc:
                last_err = exc

    if last_err:
        raise ScraperError("Không tìm thấy luồng phát khả dụng (%s)" % last_err)
    raise ScraperError("Không tìm thấy luồng phát khả dụng cho tập này.")


def resolve_episode_media(episode_url, enable_hls_adblock=True, use_mp4_proxy=True):
    """Tu dong thu lan luot cac Server (Server 1 -> Server 2 -> Server 3) cho den khi phat duoc."""
    sources = get_episode_sources(episode_url)
    last_error = None
    for source in sources:
        try:
            media = resolve_stream(
                source["url"],
                enable_hls_adblock=enable_hls_adblock,
                use_mp4_proxy=use_mp4_proxy,
            )
            if media:
                media["server_name"] = source.get("name", "Server")
                return media
        except Exception as exc:
            last_error = exc
            continue
    raise ScraperError(str(last_error or "Tất cả các server của tập này hiện không phản hồi."))
