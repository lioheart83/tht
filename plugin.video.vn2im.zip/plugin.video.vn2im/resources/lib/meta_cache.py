# -*- coding: utf-8 -*-
"""Bo nho dem SQLite nhe cho metadata phim va trang thai ngon ngu (Phu de / Thuyet minh)."""
from __future__ import absolute_import, unicode_literals

import json
import os
import sqlite3
import time

try:
    import xbmcaddon
    import xbmcvfs
except ImportError:
    xbmcaddon = None
    xbmcvfs = None

from resources.lib.proxy_state import proxy_workspace_dir


DB_FILENAME = "movie_meta.sqlite3"
ONGOING_TTL = 6 * 3600
COMPLETED_TTL = 3 * 86400


def _cache_db_path():
    candidates = []
    if xbmcaddon is not None and xbmcvfs is not None:
        try:
            profile_dir = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile"))
            if profile_dir:
                candidates.append(profile_dir)
        except Exception:
            pass
    try:
        candidates.append(proxy_workspace_dir())
    except Exception:
        pass

    for directory in candidates:
        try:
            if not os.path.isdir(directory):
                if xbmcvfs is not None:
                    xbmcvfs.mkdirs(directory)
                if not os.path.isdir(directory):
                    os.makedirs(directory, exist_ok=True)
            path = os.path.join(directory, DB_FILENAME)
            if os.path.isfile(path) or os.access(directory, os.W_OK):
                return path
        except Exception:
            continue
    return ""


def _open_connection():
    path = _cache_db_path()
    if not path:
        return None
    conn = sqlite3.connect(path, timeout=3.0)
    conn.execute(
        "CREATE TABLE IF NOT EXISTS movie_meta ("
        "url TEXT PRIMARY KEY, "
        "updated_at INTEGER NOT NULL, "
        "is_completed INTEGER NOT NULL DEFAULT 0, "
        "data_json TEXT NOT NULL)"
    )
    cols = {row[1] for row in conn.execute("PRAGMA table_info(movie_meta)").fetchall()}
    if "is_completed" not in cols:
        conn.execute("ALTER TABLE movie_meta ADD COLUMN is_completed INTEGER NOT NULL DEFAULT 0")
    return conn


def get_cached_meta_many(urls, ongoing_ttl=ONGOING_TTL, completed_ttl=COMPLETED_TTL):
    clean_urls = [url for url in dict.fromkeys(urls or []) if url]
    if not clean_urls:
        return {}
    now = int(time.time())
    ongoing_cutoff = now - max(0, int(ongoing_ttl))
    completed_cutoff = now - max(0, int(completed_ttl))
    result = {}
    conn = None
    try:
        conn = _open_connection()
        if conn is None:
            return {}
        for offset in range(0, len(clean_urls), 400):
            chunk = clean_urls[offset:offset + 400]
            placeholders = ",".join("?" for _ in chunk)
            query = (
                "SELECT url, data_json FROM movie_meta "
                "WHERE ((is_completed = 1 AND updated_at >= ?) OR (is_completed = 0 AND updated_at >= ?)) "
                "AND url IN (%s)" % placeholders
            )
            cursor = conn.execute(query, [completed_cutoff, ongoing_cutoff] + chunk)
            for url, raw_json in cursor.fetchall():
                try:
                    parsed = json.loads(raw_json)
                    if isinstance(parsed, dict):
                        result[url] = parsed
                except (TypeError, ValueError, json.JSONDecodeError):
                    continue
        return result
    except (sqlite3.Error, OSError, TypeError, ValueError):
        return {}
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass


def put_cached_meta_many(items_by_url):
    if not items_by_url:
        return
    now = int(time.time())
    rows = []
    for url, meta in items_by_url.items():
        if not url or not isinstance(meta, dict):
            continue
        try:
            completed_flag = 1 if meta.get("is_completed") else 0
            rows.append((str(url), now, completed_flag, json.dumps(meta, ensure_ascii=False)))
        except (TypeError, ValueError):
            continue
    if not rows:
        return

    conn = None
    try:
        conn = _open_connection()
        if conn is None:
            return
        with conn:
            conn.executemany(
                "INSERT OR REPLACE INTO movie_meta (url, updated_at, is_completed, data_json) VALUES (?, ?, ?, ?)",
                rows,
            )
    except (sqlite3.Error, OSError, TypeError, ValueError):
        pass
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass
