# -*- coding: utf-8 -*-
"""Quan ly trang thai va thu muc tam cua proxy cuc bo."""
from __future__ import absolute_import, unicode_literals

import json
import os
import tempfile
import time

try:
    import xbmcvfs
except ImportError:
    xbmcvfs = None


STATE_FILENAME = "proxy_state.json"
WORKSPACE_NAME = "plugin.video.vn2im"


def proxy_base(port):
    return "http://127.0.0.1:%d" % int(port)


def proxy_workspace_dir():
    """Tra ve thu muc lam viec tam cho addon (special://temp trong Kodi)."""
    if xbmcvfs is not None:
        try:
            temp_root = xbmcvfs.translatePath("special://temp/")
            workspace = os.path.realpath(os.path.join(temp_root, WORKSPACE_NAME))
            if not os.path.isdir(workspace):
                xbmcvfs.mkdirs(workspace)
            if not os.path.isdir(workspace):
                os.makedirs(workspace, exist_ok=True)
            return workspace
        except Exception:
            pass
    workspace = os.path.realpath(os.path.join(tempfile.gettempdir(), WORKSPACE_NAME))
    os.makedirs(workspace, exist_ok=True)
    return workspace


def state_path():
    return os.path.join(proxy_workspace_dir(), STATE_FILENAME)


def write_proxy_state(port):
    """Ghi thong tin cong proxy dang chay vao proxy_state.json."""
    port_num = int(port)
    if port_num < 1 or port_num > 65535:
        raise ValueError("Cong proxy khong hop le: %s" % port)
    path = state_path()
    directory = os.path.dirname(path)
    if directory and not os.path.isdir(directory):
        os.makedirs(directory, exist_ok=True)
    tmp_path = path + ".tmp"
    payload = {
        "host": "127.0.0.1",
        "port": port_num,
        "updated_at": time.time(),
    }
    with open(tmp_path, "w", encoding="utf-8") as handle:
        json.dump(payload, handle)
    os.replace(tmp_path, path)
    return proxy_base(port_num)


def read_proxy_base():
    """Doc dia chi proxy cuc bo (hoac chuoi rong neu chua khoi chay)."""
    try:
        with open(state_path(), "r", encoding="utf-8") as handle:
            data = json.load(handle)
        port_num = int(data.get("port") or 0)
        if 1 <= port_num <= 65535:
            host = str(data.get("host") or "127.0.0.1").strip() or "127.0.0.1"
            return "http://%s:%d" % (host, port_num)
    except (IOError, OSError, TypeError, ValueError, json.JSONDecodeError):
        pass
    return ""


def clear_proxy_state(port=None):
    """Xoa tep trang thai proxy khi service tat."""
    path = state_path()
    if port is not None:
        try:
            with open(path, "r", encoding="utf-8") as handle:
                if int(json.load(handle).get("port") or 0) != int(port):
                    return
        except (IOError, OSError, TypeError, ValueError, json.JSONDecodeError):
            return
    try:
        os.remove(path)
    except OSError:
        pass
