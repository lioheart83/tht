# Phim VN2 (`plugin.video.vn2im`)

Addon Kodi Python 3 xem phim đầy đủ **Phụ đề (Vietsub)**, **Thuyết minh** và **Lồng tiếng** từ `https://www.vn2.im/` — loại bỏ hoàn toàn quảng cáo.

## Tính năng chính

- **Đầy đủ Phụ đề & Thuyết minh / Lồng tiếng**:
  - Hỗ trợ duyệt chuyên mục riêng cho **Phim Thuyết Minh & Lồng Tiếng** (Tất cả Thuyết Minh & Lồng Tiếng, Thuyết Minh, Lồng Tiếng Hồng Kông/TVB, Song Ngữ) và **Phim Phụ Đề (Vietsub)** (Tất cả Vietsub, Song Ngữ).
  - Tự động nhận diện và gắn nhãn phiên bản ngay trên danh sách phim (`[39/39 • Vietsub + Thuyết Minh]`, `[11/11 • Lồng Tiếng]`, `[20/20 • Phụ Đề (Vietsub)]`).
  - Trong trang chi tiết phim, hiển thị tách biệt từng nhóm tập (`Thuyết Minh`, `Lồng Tiếng`, `Phụ Đề (Vietsub)`, server phụ) và có thể chỉnh thứ tự ưu tiên trong cài đặt addon.
- **Mở rộng đầy đủ tập phim cho bộ dài tập**:
  - Tự động giải mã logic `add-tap.js` của website để mở rộng đầy đủ tất cả tập bị ẩn ở giữa cho các bộ phim 100–1000+ tập (ví dụ *Thám Tử Lừng Danh Conan*, *One Piece*, *Tân Tam Quốc Diễn Nghĩa*...).
- **Hỗ trợ trọn vẹn mọi danh mục trên `vn2.im`**:
  - Trang chủ / Phim đề cử, Phim Mới Cập Nhật, Phim Xem Nhiều Nhất, Top Trending / Yêu Thích, Phim Lẻ Chọn Lọc, Phim Chiếu Rạp, Hoạt Hình - Anime, Drama TikTok / YouTube, Top Ca Nhạc, Thể loại & Quốc gia.
  - Tìm kiếm nhanh hỗ trợ tiếng Việt có dấu và không dấu, không lẫn kết quả gợi ý sidebar.
- **Loại bỏ 100% quảng cáo đa tầng**:
  - Không tải các script popup, banner, tab-under hay mạng quảng cáo VAST từ trình duyệt web.
  - Bỏ qua cơ chế chống chặn quảng cáo (`check-user.php`) và tự động thử lại khi gặp mốc đổi giờ hoặc node CDN chết (`mynumcdn` / `play2.php` fallback).
  - Proxy cục bộ (`service.py`) tự động cắt sạch quảng cáo chèn qua `#EXT-X-DISCONTINUITY` hoặc domain/đường dẫn quảng cáo trong playlist HLS (`.m3u8`).
  - Lọc bỏ các dòng quảng cáo cá độ/rác nếu có phụ đề rời (`.srt` / `.vtt`).
- **Tua phim mượt không treo & Tối ưu tốc độ trên Android TV / Windows / Linux**:
  - Proxy cục bộ `/video.mp4` (`service.py`) sử dụng `HTTP/2` (`httpx` + `h2`) bơm luồng MP4 theo khối nhỏ giới hạn (`256 KB` đầu sau khi tua → `1 MB` ổn định), `HEAD` phản hồi tức thì, tự động chuyển đổi node CDN dự phòng và tự làm mới token khi tạm dừng lâu — khắc phục hoàn toàn tình trạng đứng/treo Kodi khi tua.
  - Kết nối HTTP keep-alive đa luồng an toàn kết hợp nén `gzip` và bộ nhớ đệm SQLite (`movie_meta.sqlite3`) giúp duyệt danh sách mượt mà.

## Cài đặt vào Kodi

### Cách 1: Cài trực tiếp từ file `.zip` (Khuyên dùng)
1. Mở **Kodi** → **Add-ons** → biểu tượng hộp (**Install from zip file**).
2. Chọn file `plugin.video.vn2im.zip`.
3. Chờ thông báo cài đặt thành công và mở **Phim VN2** trong mục **Video add-ons**.

### Cách 2: Copy thư mục addon
Copy thư mục `plugin.video.vn2im` vào thư mục `addons` của Kodi, sau đó bật addon trong phần **Video add-ons**.

## Cấu hình tùy chọn (Settings)

- **Tự động phát ngay khi chọn tập**: Bỏ qua menu chọn Server 1/2/3, tự động phát nguồn sạch đầu tiên hoạt động tốt.
- **Thứ tự ưu tiên nhóm tập**: Mặc định / Ưu tiên Thuyết Minh & Lồng Tiếng / Ưu tiên Phụ Đề (Vietsub).
- **Lọc quảng cáo HLS qua Proxy cục bộ**: Bật/tắt xử lý cắt quảng cáo `.m3u8` trên proxy nội bộ.
- **Hiển thị nhãn Phụ đề / Thuyết minh & nội dung phim ngoài danh sách**: Tải trước thông tin chi tiết và nhãn ngôn ngữ ngay ngoài trang danh sách.
