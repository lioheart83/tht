# Changelog

## 1.1.0
- Khắc phục triệt để lỗi treo Kodi (`Kodi is not responding`) khi tua nhanh / tua tiến lùi video MP4 trên các máy chủ `cloudcdnvn.com`:
  - Đóng gói thư viện thuần Python `httpx` + `h2` (`HTTP/2` ALPN) vào `resources/lib/` và định tuyến toàn bộ luồng MP4 qua endpoint proxy cục bộ `/video.mp4` trong `service.py` (do `cloudcdnvn.com` bóp/treo các request `Range` dài qua `HTTP/1.1` của Kodi `CCurlFile`).
  - Triển khai bơm dữ liệu dạng chunk giới hạn qua `HTTP/2` (`256 KB` cho chunk đầu ngay sau khi tua để phát tiếp dưới 150ms, sau đó `1 MB` liên tục), hỗ trợ `HEAD` tức thì không tốn request mạng và ngắt sạch kết nối khi Kodi hủy tua giữa chừng.
  - Bổ sung tách cookie `iduser-myplay` từ trang tập phim vào token phát `play.php`, tự động chuyển mirror dự phòng khi một node CDN lỗi và tự làm mới token qua `refresh_mp4_candidates()` nếu tạm dừng xem quá lâu.

## 1.0.0
- Phiên bản phát hành đầu tiên cho `https://www.vn2.im/` (`plugin.video.vn2im`).
- Hỗ trợ đầy đủ danh mục Phim Mới, Phim Xem Nhiều, Top Trending, Phim Lẻ, Chiếu Rạp, Hoạt Hình - Anime, Drama TikTok/YouTube, Thể loại, Quốc gia/Danh mục và Tìm kiếm.
- Bổ sung menu duyệt riêng cho **Phim Thuyết Minh & Lồng Tiếng**, **Phim Phụ Đề (Vietsub)** và **Phim Song Ngữ**.
- Tích hợp mở rộng đầy đủ tập cho phim bộ dài tập (`add-tap.js` port, hỗ trợ cả phần bù `fixscat` và tập chia `fixs` như `590-a`, `590-b`).
- Resolver không quảng cáo qua `check-user.php` + `play.php` + fallback `play2.php` + kiểm tra byte-range MP4 / manifest HLS thực tế trước khi phát, bỏ qua node CDN chết.
- Tích hợp `service.py` proxy cục bộ cắt quảng cáo HLS (`#EXT-X-DISCONTINUITY`) và `adblock.py` làm sạch phụ đề `.srt`/`.vtt`.
