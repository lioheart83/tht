# -*- coding: utf-8 -*-
"""Service chay nen cua Phim VN2: proxy loc quang cao HLS va prefetch metadata."""
from __future__ import absolute_import, unicode_literals

import base64
from collections import OrderedDict, deque
import json
import os
import re
import socket
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlencode, urljoin, urlparse
from urllib.request import Request

try:
    import xbmc
except ImportError:
    xbmc = None

_ADDON_DIR = os.path.dirname(os.path.abspath(__file__))
_LIB_DIR = os.path.join(_ADDON_DIR, "resources", "lib")
for _path in (_ADDON_DIR, _LIB_DIR):
    if _path not in sys.path:
        sys.path.insert(0, _path)

import httpx

from resources.lib import scraper
from resources.lib.adblock import strip_hls_ads
from resources.lib.httpkeepalive import build_keepalive_opener
from resources.lib.meta_cache import get_cached_meta_many, put_cached_meta_many
from resources.lib.proxy_state import clear_proxy_state, write_proxy_state


HOST = "127.0.0.1"
PORT = 0
USER_AGENT = scraper.USER_AGENT
URI_ATTR_RE = re.compile(r'URI="([^"]+)"')
FIRST_MP4_CHUNK_BYTES = 262144
STEADY_MP4_CHUNK_BYTES = 1048576
MP4_META_CACHE_MAX = 64


def log(message, level=None):
    if xbmc is None:
        return
    if level is None:
        level = xbmc.LOGINFO
    xbmc.log("[Phim VN2 proxy] %s" % message, level)


def encode_token(value):
    return base64.urlsafe_b64encode(str(value).encode("utf-8")).decode("ascii").rstrip("=")


def decode_token(value):
    raw = (value or "").encode("ascii")
    raw += b"=" * (-len(raw) % 4)
    return base64.urlsafe_b64decode(raw).decode("utf-8")


def query_value(query, key):
    values = query.get(key) or []
    return decode_token(values[0]) if values else ""


def is_valid_http_url(url):
    try:
        target = urlparse(url)
        return target.scheme in ("http", "https") and bool(target.hostname)
    except Exception:
        return False


def build_origin_headers(referer):
    headers = {"User-Agent": USER_AGENT}
    if referer:
        headers["Referer"] = referer
        parsed = urlparse(referer)
        if parsed.scheme in ("http", "https") and parsed.netloc:
            headers["Origin"] = "%s://%s" % (parsed.scheme, parsed.netloc)
    return headers


def parse_byte_range(range_header, total_size):
    if not range_header or total_size <= 0:
        return None
    match = re.match(r"^\s*bytes=(\d*)-(\d*)\s*$", range_header, re.I)
    if not match:
        return None
    start_str, end_str = match.group(1), match.group(2)
    if not start_str and not end_str:
        return None
    if not start_str:
        suffix = int(end_str)
        if suffix <= 0:
            return (-1, -1)
        start = max(0, total_size - suffix)
        end = total_size - 1
        return (start, end)
    start = int(start_str)
    end = int(end_str) if end_str else total_size - 1
    end = min(end, total_size - 1)
    if start >= total_size or start > end:
        return (-1, -1)
    return (start, end)


class ProxyServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, server_address, RequestHandlerClass, bind_and_activate=True):
        self.http_opener = build_keepalive_opener(cookie_jar=None)
        self.http_client = httpx.Client(
            http2=True,
            follow_redirects=True,
            timeout=httpx.Timeout(12.0, connect=4.0),
            limits=httpx.Limits(max_keepalive_connections=12, max_connections=24),
            headers={"User-Agent": USER_AGENT},
        )
        self._mp4_size_cache = OrderedDict()
        self._mp4_fresh_cache = OrderedDict()
        self._mp4_lock = threading.Lock()
        self._prefetch_queue = deque()
        self._prefetch_queued = set()
        self._prefetch_cond = threading.Condition()
        self._stopping = False
        super(ProxyServer, self).__init__(
            server_address,
            RequestHandlerClass,
            bind_and_activate=bind_and_activate,
        )
        self._prefetch_thread = threading.Thread(target=self._prefetch_worker)
        self._prefetch_thread.daemon = True
        self._prefetch_thread.start()

    def get_mp4_size(self, key):
        if not key:
            return 0
        with self._mp4_lock:
            val = self._mp4_size_cache.get(key)
            if val:
                self._mp4_size_cache.move_to_end(key)
            return val or 0

    def put_mp4_size(self, key, size):
        size = scraper.safe_int(size, 0)
        if not key or size <= 0:
            return
        with self._mp4_lock:
            self._mp4_size_cache[key] = size
            self._mp4_size_cache.move_to_end(key)
            while len(self._mp4_size_cache) > MP4_META_CACHE_MAX:
                self._mp4_size_cache.popitem(last=False)

    def get_fresh_candidates(self, ep_url, max_age=120.0):
        if not ep_url:
            return []
        now = time.time()
        with self._mp4_lock:
            entry = self._mp4_fresh_cache.get(ep_url)
            if not entry:
                return []
            ts, urls = entry
            if (now - ts) > max_age:
                self._mp4_fresh_cache.pop(ep_url, None)
                return []
            self._mp4_fresh_cache.move_to_end(ep_url)
            return list(urls)

    def put_fresh_candidates(self, ep_url, urls):
        clean = [u for u in (urls or []) if is_valid_http_url(u)]
        if not ep_url or not clean:
            return
        with self._mp4_lock:
            self._mp4_fresh_cache[ep_url] = (time.time(), list(clean))
            self._mp4_fresh_cache.move_to_end(ep_url)
            while len(self._mp4_fresh_cache) > MP4_META_CACHE_MAX:
                self._mp4_fresh_cache.popitem(last=False)

    def resolve_total_size(self, candidates, ep_url, referer):
        cache_key = ep_url or (candidates[0] if candidates else "")
        cached = self.get_mp4_size(cache_key)
        if cached > 0:
            return cached

        for attempt in range(2):
            for cand in list(candidates):
                try:
                    resp = self.http_client.get(
                        cand,
                        headers=scraper.build_video_stream_headers(referer, "bytes=0-1023"),
                        timeout=httpx.Timeout(6.0, connect=3.5),
                    )
                    if resp.status_code in (200, 206):
                        total = scraper._parse_total_size_from_headers(resp.headers, resp.status_code)
                        if total > 0:
                            self.put_mp4_size(cache_key, total)
                            return total
                except Exception:
                    continue
            if attempt == 0 and ep_url:
                fresh = scraper.refresh_mp4_candidates(ep_url)
                if fresh:
                    self.put_fresh_candidates(ep_url, fresh)
                    candidates[:] = fresh
                    continue
            break
        return 0

    def fetch_mp4_chunk(self, candidates, ep_url, referer, start, end):
        cache_key = ep_url or (candidates[0] if candidates else "")
        for attempt in range(2):
            for idx, cand in enumerate(list(candidates)):
                try:
                    resp = self.http_client.get(
                        cand,
                        headers=scraper.build_video_stream_headers(
                            referer, "bytes=%d-%d" % (start, end)
                        ),
                        timeout=httpx.Timeout(8.0, connect=3.5),
                    )
                    if resp.status_code == 206:
                        data = resp.content
                        if data:
                            total = scraper._parse_total_size_from_headers(resp.headers, resp.status_code)
                            if total > 0:
                                self.put_mp4_size(cache_key, total)
                            if idx > 0 and cand in candidates:
                                candidates.remove(cand)
                                candidates.insert(0, cand)
                            return data
                    elif resp.status_code == 200:
                        data = resp.content[start:end + 1]
                        if data:
                            if idx > 0 and cand in candidates:
                                candidates.remove(cand)
                                candidates.insert(0, cand)
                            return data
                except Exception:
                    continue
            if attempt == 0 and ep_url:
                fresh = scraper.refresh_mp4_candidates(ep_url)
                if fresh:
                    self.put_fresh_candidates(ep_url, fresh)
                    candidates[:] = fresh
                    continue
            break
        return b""

    def enqueue_prefetch(self, urls):
        clean_urls = [
            url for url in dict.fromkeys(urls or [])
            if url and is_valid_http_url(url) and scraper.is_site_url(url)
        ]
        if not clean_urls:
            return
        already_cached = set(get_cached_meta_many(clean_urls).keys())
        with self._prefetch_cond:
            if self._stopping:
                return
            added = False
            for url in clean_urls:
                if url not in already_cached and url not in self._prefetch_queued:
                    self._prefetch_queue.append(url)
                    self._prefetch_queued.add(url)
                    added = True
            if added:
                self._prefetch_cond.notify_all()

    def _prefetch_worker(self):
        while True:
            with self._prefetch_cond:
                while not self._prefetch_queue and not self._stopping:
                    self._prefetch_cond.wait(timeout=1.0)
                if self._stopping:
                    return
                url = self._prefetch_queue.popleft()
                self._prefetch_queued.discard(url)

            try:
                if get_cached_meta_many([url]):
                    continue
                req = Request(
                    url,
                    headers={
                        "User-Agent": USER_AGENT,
                        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                        "Accept-Language": "vi,en-US;q=0.9,en;q=0.8",
                        "Accept-Encoding": "gzip",
                    },
                )
                with self.http_opener.open(req, timeout=10) as resp:
                    status = getattr(resp, "status", None) or getattr(resp, "code", 200)
                    if status == 200:
                        raw = resp.read()
                        enc = resp.headers.get("Content-Encoding", "")
                        html = scraper._decode_response_bytes(raw, enc, "utf-8")
                        meta = scraper.extract_movie_meta_from_html(html, url)
                        put_cached_meta_many({url: meta})
            except Exception as exc:
                log("Prefetch skipped %s: %s" % (url, exc))

            with self._prefetch_cond:
                if self._stopping:
                    return
                self._prefetch_cond.wait(timeout=0.25)
                if self._stopping:
                    return

    def server_close(self):
        with self._prefetch_cond:
            self._stopping = True
            self._prefetch_cond.notify_all()
        try:
            if getattr(self, "_prefetch_thread", None) and self._prefetch_thread.is_alive():
                self._prefetch_thread.join(timeout=1.5)
        except Exception:
            pass
        try:
            self.http_client.close()
        except Exception:
            pass
        try:
            pool = getattr(self.http_opener, "_pool", None)
            if pool is not None:
                pool.close_all()
        except Exception:
            pass
        super(ProxyServer, self).server_close()


class ProxyHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, format_, *args):
        return

    def do_GET(self):
        self.handle_request(send_body=True)

    def do_HEAD(self):
        self.handle_request(send_body=False)

    def do_POST(self):
        parsed = urlparse(self.path)
        if parsed.path != "/prefetch":
            self.send_error(404)
            return
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            length = 0
        if length <= 0 or length > 65536:
            self.send_error(400)
            return
        try:
            body = self.rfile.read(length)
            payload = json.loads(body.decode("utf-8"))
            urls = payload.get("urls") if isinstance(payload, dict) else None
            if not isinstance(urls, list):
                self.send_error(400)
                return
            valid_urls = [
                item.strip()
                for item in urls
                if isinstance(item, str) and is_valid_http_url(item.strip()) and scraper.is_site_url(item.strip())
            ]
            self.server.enqueue_prefetch(valid_urls)
            self.send_bytes(200, b"queued", "text/plain", True)
        except Exception:
            self.send_error(400)

    def local_base_url(self):
        return "http://127.0.0.1:%s" % self.server.server_address[1]

    def handle_request(self, send_body):
        parsed = urlparse(self.path)
        query = parse_qs(parsed.query)
        if parsed.path == "/ping":
            self.send_bytes(200, b"ok", "text/plain", send_body)
            return
        if parsed.path == "/video.mp4":
            self.serve_mp4(query, send_body)
            return
        if parsed.path == "/hls.m3u8":
            self.serve_hls_playlist(query, send_body)
            return
        if parsed.path == "/segment.ts":
            self.serve_segment(query, send_body)
            return
        self.send_error(404)

    def serve_mp4(self, query, send_body):
        try:
            if getattr(self, "connection", None) is not None:
                try:
                    self.connection.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                    self.connection.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 131072)
                except Exception:
                    pass

            url = query_value(query, "u")
            referer = query_value(query, "r") or (scraper.DATA_BASE_URL + "/")
            alt_raw = query_value(query, "a")
            ep_url = query_value(query, "ep")
            size_hint = scraper.safe_int((query.get("s") or ["0"])[0], 0)

            candidates = []
            for cand in self.server.get_fresh_candidates(ep_url) + [url] + [
                item.strip() for item in alt_raw.splitlines() if item.strip()
            ]:
                if is_valid_http_url(cand) and cand not in candidates:
                    candidates.append(cand)

            if not candidates:
                self.send_error(403)
                return

            cache_key = ep_url or candidates[0]
            if size_hint > 0:
                self.server.put_mp4_size(cache_key, size_hint)
            total_size = size_hint or self.server.resolve_total_size(candidates, ep_url, referer)
            if total_size <= 0:
                self.send_error(502)
                return

            byte_range = parse_byte_range(self.headers.get("Range"), total_size)
            if byte_range == (-1, -1):
                self.send_response(416)
                self.send_header("Content-Range", "bytes */%d" % total_size)
                self.end_headers()
                return

            if byte_range is not None:
                start, end = byte_range
                length = (end - start) + 1
                self.send_response(206)
                self.send_header("Content-Type", "video/mp4")
                self.send_header("Accept-Ranges", "bytes")
                self.send_header("Content-Range", "bytes %d-%d/%d" % (start, end, total_size))
                self.send_header("Content-Length", str(length))
            else:
                start, end = 0, total_size - 1
                self.send_response(200)
                self.send_header("Content-Type", "video/mp4")
                self.send_header("Accept-Ranges", "bytes")
                self.send_header("Content-Length", str(total_size))

            if not send_body:
                self.end_headers()
                return

            self.send_header("Connection", "close")
            self.close_connection = True
            self.end_headers()

            pos = start
            first_chunk = True
            while pos <= end:
                chunk_target = FIRST_MP4_CHUNK_BYTES if first_chunk else STEADY_MP4_CHUNK_BYTES
                req_end = min(end, pos + chunk_target - 1)
                chunk = self.server.fetch_mp4_chunk(candidates, ep_url, referer, pos, req_end)
                if not chunk:
                    break
                self.wfile.write(chunk)
                self.wfile.flush()
                pos += len(chunk)
                first_chunk = False
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, socket.error, OSError):
            return
        except Exception as exc:
            log("Unexpected MP4 proxy error: %s" % exc, xbmc.LOGWARNING if xbmc else None)
            try:
                self.send_error(500)
            except Exception:
                return

    def serve_hls_playlist(self, query, send_body):
        try:
            url = query_value(query, "u")
            referer = query_value(query, "r")
            proxy_segments = (query.get("sp") or [""])[0] == "1"
            if not is_valid_http_url(url):
                self.send_error(403)
                return

            headers = build_origin_headers(referer)
            headers["Accept"] = "application/vnd.apple.mpegurl,application/x-mpegURL,*/*;q=0.8"
            resp = self.server.http_client.get(url, headers=headers)
            if resp.status_code >= 400:
                self.send_error(resp.status_code)
                return
            text = resp.text

            if "#EXTM3U" not in text:
                self.send_error(502)
                return

            local_base = self.local_base_url()
            effective_referer = referer or url

            def make_hls_url(target_url):
                params = {
                    "u": encode_token(target_url),
                    "r": encode_token(effective_referer),
                }
                if proxy_segments:
                    params["sp"] = "1"
                return "%s/hls.m3u8?%s" % (local_base, urlencode(params))

            def make_seg_url(target_url):
                return "%s/segment.ts?%s" % (
                    local_base,
                    urlencode({
                        "u": encode_token(target_url),
                        "r": encode_token(effective_referer),
                    }),
                )

            if "#EXT-X-STREAM-INF" in text:
                rewritten = []
                for line in text.splitlines():
                    stripped = line.strip()
                    if stripped.startswith("#"):
                        if 'URI="' in stripped:
                            line = URI_ATTR_RE.sub(
                                lambda m: 'URI="%s"' % make_hls_url(urljoin(url, m.group(1))),
                                line,
                            )
                        rewritten.append(line)
                    elif stripped:
                        rewritten.append(make_hls_url(urljoin(url, stripped)))
                    else:
                        rewritten.append(line)
                out_text = "\n".join(rewritten).strip() + "\n"
            else:
                cleaned = strip_hls_ads(text, url)
                rewritten = []
                for line in cleaned.splitlines():
                    stripped = line.strip()
                    if stripped.startswith("#"):
                        if 'URI="' in stripped and (
                            stripped.upper().startswith("#EXT-X-KEY:")
                            or stripped.upper().startswith("#EXT-X-MAP:")
                        ):
                            def _rewrite_attr(m):
                                abs_u = urljoin(url, m.group(1))
                                return 'URI="%s"' % (make_seg_url(abs_u) if proxy_segments else abs_u)
                            line = URI_ATTR_RE.sub(_rewrite_attr, line)
                        rewritten.append(line)
                    elif stripped:
                        abs_u = urljoin(url, stripped)
                        rewritten.append(make_seg_url(abs_u) if proxy_segments else abs_u)
                    else:
                        rewritten.append(line)
                out_text = "\n".join(rewritten).strip() + "\n"

            self.send_bytes(200, out_text.encode("utf-8"), "application/vnd.apple.mpegurl", send_body)
        except httpx.HTTPError as exc:
            log("Cannot proxy HLS playlist: %s" % exc, xbmc.LOGWARNING if xbmc else None)
            self.send_error(502)
        except Exception as exc:
            log("Unexpected HLS proxy error: %s" % exc, xbmc.LOGWARNING if xbmc else None)
            self.send_error(500)

    def serve_segment(self, query, send_body):
        try:
            url = query_value(query, "u")
            referer = query_value(query, "r")
            if not is_valid_http_url(url):
                self.send_error(403)
                return

            headers = build_origin_headers(referer)
            range_header = self.headers.get("Range")
            if range_header:
                headers["Range"] = range_header
            method = "GET" if send_body else "HEAD"

            with self.server.http_client.stream(method, url, headers=headers) as response:
                if response.status_code >= 400:
                    self.send_error(response.status_code)
                    return
                self.send_response(response.status_code)
                self.send_header("Content-Type", response.headers.get("Content-Type") or "video/mp2t")
                has_length = False
                for key in ("Content-Length", "Content-Range", "Accept-Ranges"):
                    value = response.headers.get(key)
                    if value:
                        if key == "Content-Length":
                            has_length = True
                        self.send_header(key, value)
                if not has_length:
                    self.send_header("Connection", "close")
                    self.close_connection = True
                self.end_headers()
                if send_body:
                    for chunk in response.iter_bytes(chunk_size=65536):
                        if chunk:
                            self.wfile.write(chunk)
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            return
        except httpx.HTTPError as exc:
            log("Cannot proxy segment: %s" % exc, xbmc.LOGWARNING if xbmc else None)
            self.send_error(502)
        except Exception as exc:
            log("Unexpected proxy error: %s" % exc, xbmc.LOGWARNING if xbmc else None)
            self.send_error(500)

    def send_bytes(self, status, data, content_type, send_body):
        try:
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            if send_body:
                self.wfile.write(data)
        except (BrokenPipeError, ConnectionResetError):
            return


def _warm_home_catalog(server, monitor):
    if monitor.waitForAbort(2):
        return
    try:
        html = scraper.get_home_html()
        movies = scraper.parse_movies(html, scraper.BASE_URL + "/")
        urls = [movie["url"] for movie in movies if movie.get("url")]
        if urls and not monitor.abortRequested():
            server.enqueue_prefetch(urls)
    except Exception as exc:
        log("Home warmup skipped: %s" % exc)


def run():
    server = None
    proxy_port = None
    try:
        server = ProxyServer((HOST, PORT), ProxyHandler)
        proxy_port = server.server_address[1]
        write_proxy_state(proxy_port)
    except Exception as exc:
        log("Proxy did not start: %s" % exc, xbmc.LOGWARNING if xbmc else None)
        if server is not None:
            server.server_close()
        return

    worker = threading.Thread(target=server.serve_forever)
    worker.daemon = True
    worker.start()
    log("Local proxy started on port %s" % proxy_port)

    monitor = xbmc.Monitor()
    warmup = threading.Thread(target=_warm_home_catalog, args=(server, monitor))
    warmup.daemon = True
    warmup.start()

    try:
        while not monitor.waitForAbort(1):
            pass
    finally:
        try:
            server.shutdown()
        except Exception:
            pass
        try:
            server.server_close()
        except Exception:
            pass
        clear_proxy_state(proxy_port)
        log("Local proxy stopped")


if __name__ == "__main__":
    run()
