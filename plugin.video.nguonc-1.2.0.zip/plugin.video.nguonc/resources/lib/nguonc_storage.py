import hashlib
import json
import os
import threading
import time

import xbmc
import xbmcaddon

try:
    import xbmcvfs
except ImportError:
    xbmcvfs = None

MAX_HISTORY_ITEMS = 50
MAX_SEARCH_HISTORY = 20

_STORAGE_LOCK = threading.RLock()


def _translate_path(path):
    if xbmcvfs is not None and hasattr(xbmcvfs, 'translatePath'):
        return xbmcvfs.translatePath(path)
    if hasattr(xbmc, 'translatePath'):
        return xbmc.translatePath(path)
    return path


def get_profile_dir():
    addon = xbmcaddon.Addon()
    raw_profile = addon.getAddonInfo('profile')
    profile_dir = _translate_path(raw_profile)
    if profile_dir:
        os.makedirs(profile_dir, exist_ok=True)
    return profile_dir


def get_cache_dir():
    cache_dir = os.path.join(get_profile_dir(), 'cache')
    os.makedirs(cache_dir, exist_ok=True)
    return cache_dir


def _read_json_file(path, default):
    if not os.path.exists(path):
        return default
    try:
        with open(path, 'r', encoding='utf-8') as handle:
            return json.load(handle)
    except Exception:
        return default


def _write_json_atomic(path, payload):
    parent = os.path.dirname(path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    tmp_path = f'{path}.{os.getpid()}.{threading.get_ident()}.tmp'
    try:
        with open(tmp_path, 'w', encoding='utf-8') as handle:
            json.dump(payload, handle, ensure_ascii=False)
        os.replace(tmp_path, path)
    finally:
        if os.path.exists(tmp_path):
            try:
                os.remove(tmp_path)
            except OSError:
                pass


def _cache_file_path(key):
    digest = hashlib.sha256(str(key).encode('utf-8')).hexdigest()
    return os.path.join(get_cache_dir(), digest + '.json')


def cache_get(key, max_age_seconds):
    if max_age_seconds is None or max_age_seconds <= 0:
        return None
    path = _cache_file_path(key)
    with _STORAGE_LOCK:
        entry = _read_json_file(path, None)
    if not isinstance(entry, dict):
        return None
    ts = entry.get('ts')
    if not isinstance(ts, (int, float)):
        return None
    if (time.time() - ts) > max_age_seconds:
        return None
    return entry.get('data')


def cache_set(key, data):
    path = _cache_file_path(key)
    payload = {'ts': time.time(), 'data': data}
    with _STORAGE_LOCK:
        _write_json_atomic(path, payload)


def cache_clear():
    cache_dir = get_cache_dir()
    removed = 0
    with _STORAGE_LOCK:
        try:
            names = os.listdir(cache_dir)
        except OSError:
            return 0
        for name in names:
            if name.endswith('.json') or name.endswith('.tmp'):
                full_path = os.path.join(cache_dir, name)
                try:
                    if os.path.isfile(full_path):
                        os.remove(full_path)
                        removed += 1
                except OSError:
                    pass
    return removed


def _normalize_movie_summary(movie_summary):
    movie_summary = movie_summary or {}
    return {
        'slug': str(movie_summary.get('slug') or ''),
        'name': str(movie_summary.get('name') or ''),
        'original_name': str(movie_summary.get('original_name') or ''),
        'year': str(movie_summary.get('year') or ''),
        'quality': str(movie_summary.get('quality') or ''),
        'language': str(movie_summary.get('language') or ''),
        'current_episode': str(movie_summary.get('current_episode') or ''),
        'total_episodes': movie_summary.get('total_episodes') or '',
        'thumb_url': str(movie_summary.get('thumb_url') or ''),
        'poster_url': str(movie_summary.get('poster_url') or ''),
    }


def _favorites_path():
    return os.path.join(get_profile_dir(), 'favorites.json')


def get_favorites():
    with _STORAGE_LOCK:
        data = _read_json_file(_favorites_path(), [])
        return data if isinstance(data, list) else []


def is_favorite(slug):
    if not slug:
        return False
    return any(item.get('slug') == slug for item in get_favorites())


def add_favorite(movie_summary):
    entry = _normalize_movie_summary(movie_summary)
    slug = entry['slug']
    if not slug:
        return False
    entry['added_at'] = int(time.time())
    with _STORAGE_LOCK:
        items = _read_json_file(_favorites_path(), [])
        if not isinstance(items, list):
            items = []
        items = [it for it in items if isinstance(it, dict) and it.get('slug') != slug]
        items.insert(0, entry)
        _write_json_atomic(_favorites_path(), items)
    return True


def remove_favorite(slug):
    if not slug:
        return False
    with _STORAGE_LOCK:
        items = _read_json_file(_favorites_path(), [])
        if not isinstance(items, list):
            return False
        filtered = [it for it in items if isinstance(it, dict) and it.get('slug') != slug]
        if len(filtered) == len(items):
            return False
        _write_json_atomic(_favorites_path(), filtered)
    return True


def _history_path():
    return os.path.join(get_profile_dir(), 'history.json')


def get_watch_history():
    with _STORAGE_LOCK:
        data = _read_json_file(_history_path(), [])
        return data if isinstance(data, list) else []


def record_watch_history(movie_summary, episode_label=''):
    entry = _normalize_movie_summary(movie_summary)
    slug = entry['slug']
    if not slug:
        return False
    entry['last_episode'] = str(episode_label or '')
    entry['watched_at'] = int(time.time())
    with _STORAGE_LOCK:
        items = _read_json_file(_history_path(), [])
        if not isinstance(items, list):
            items = []
        existing = next((it for it in items if isinstance(it, dict) and it.get('slug') == slug), None)
        if existing:
            for key in ('name', 'original_name', 'year', 'quality', 'language', 'current_episode', 'total_episodes', 'thumb_url', 'poster_url'):
                if not entry.get(key) and existing.get(key):
                    entry[key] = existing[key]
        items = [it for it in items if isinstance(it, dict) and it.get('slug') != slug]
        items.insert(0, entry)
        _write_json_atomic(_history_path(), items[:MAX_HISTORY_ITEMS])
    return True


def remove_history_item(slug):
    if not slug:
        return False
    with _STORAGE_LOCK:
        items = _read_json_file(_history_path(), [])
        if not isinstance(items, list):
            return False
        filtered = [it for it in items if isinstance(it, dict) and it.get('slug') != slug]
        if len(filtered) == len(items):
            return False
        _write_json_atomic(_history_path(), filtered)
    return True


def clear_watch_history():
    with _STORAGE_LOCK:
        _write_json_atomic(_history_path(), [])


def _search_history_path():
    return os.path.join(get_profile_dir(), 'search_history.json')


def get_search_history():
    with _STORAGE_LOCK:
        data = _read_json_file(_search_history_path(), [])
        return [str(k) for k in data if str(k).strip()] if isinstance(data, list) else []


def add_search_keyword(keyword):
    kw = str(keyword or '').strip()
    if not kw:
        return False
    with _STORAGE_LOCK:
        items = _read_json_file(_search_history_path(), [])
        if not isinstance(items, list):
            items = []
        cleaned = [str(k).strip() for k in items if str(k).strip() and str(k).strip().lower() != kw.lower()]
        cleaned.insert(0, kw)
        _write_json_atomic(_search_history_path(), cleaned[:MAX_SEARCH_HISTORY])
    return True


def remove_search_keyword(keyword):
    kw = str(keyword or '').strip()
    if not kw:
        return False
    with _STORAGE_LOCK:
        items = _read_json_file(_search_history_path(), [])
        if not isinstance(items, list):
            return False
        filtered = [str(k).strip() for k in items if str(k).strip() and str(k).strip().lower() != kw.lower()]
        if len(filtered) == len(items):
            return False
        _write_json_atomic(_search_history_path(), filtered)
    return True


def clear_search_history():
    with _STORAGE_LOCK:
        _write_json_atomic(_search_history_path(), [])
