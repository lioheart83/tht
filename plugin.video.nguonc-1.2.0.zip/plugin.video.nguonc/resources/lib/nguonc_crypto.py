import base64
import binascii
import hashlib
import hmac
import struct
from array import array

_STRUCT_4I = struct.Struct('>4I')

try:
    from Cryptodome.Cipher import AES as _PyCryptoAES
except ImportError:
    try:
        from Crypto.Cipher import AES as _PyCryptoAES
    except ImportError:
        _PyCryptoAES = None

try:
    from cryptography.hazmat.primitives.ciphers import Cipher as _CryptoCipher
    from cryptography.hazmat.primitives.ciphers import algorithms as _CryptoAlgorithms
    from cryptography.hazmat.primitives.ciphers import modes as _CryptoModes
except ImportError:
    _CryptoCipher = None
    _CryptoAlgorithms = None
    _CryptoModes = None

AES_SBOX = array('B', binascii.unhexlify(
    '637c777bf26b6fc53001672bfed7ab76'
    'ca82c97dfa5947f0add4a2af9ca472c0'
    'b7fd9326363ff7cc34a5e5f171d83115'
    '04c723c31896059a071280e2eb27b275'
    '09832c1a1b6e5aa0523bd6b329e32f84'
    '53d100ed20fcb15b6acbbe394a4c58cf'
    'd0efaafb434d338545f9027f503c9fa8'
    '51a3408f929d38f5bcb6da2110fff3d2'
    'cd0c13ec5f974417c4a77e3d645d1973'
    '60814fdc222a908846eeb814de5e0bdb'
    'e0323a0a4906245cc2d3ac629195e479'
    'e7c8376d8dd54ea96c56f4ea657aae08'
    'ba78252e1ca6b4c6e8dd741f4bbd8b8a'
    '703eb5664803f60e613557b986c11d9e'
    'e1f8981169d98e949b1e87e9ce5528df'
    '8ca1890dbfe6426841992d0fb054bb16'
))

AES_RCON = array('B', binascii.unhexlify(
    '8d01020408102040801b366cd8ab4d9a'
    '2f5ebc63c697356ad4b37dfaefc59139'
    '72e4d3bd61c29f254a943366cc831d3a'
    '74e8cb8d01020408102040801b366cd8'
    'ab4d9a2f5ebc63c697356ad4b37dfaef'
    'c5913972e4d3bd61c29f254a943366cc'
    '831d3a74e8cb8d01020408102040801b'
    '366cd8ab4d9a2f5ebc63c697356ad4b3'
    '7dfaefc5913972e4d3bd61c29f254a94'
    '3366cc831d3a74e8cb8d010204081020'
    '40801b366cd8ab4d9a2f5ebc63c69735'
    '6ad4b37dfaefc5913972e4d3bd61c29f'
    '254a943366cc831d3a74e8cb8d010204'
    '08102040801b366cd8ab4d9a2f5ebc63'
    'c697356ad4b37dfaefc5913972e4d3bd'
    '61c29f254a943366cc831d3a74e8cb'
))


def galois_multiply(a, b):
    product = 0
    while b:
        if b & 1:
            product ^= a
        a <<= 1
        if a & 0x100:
            a ^= 0x1b
        b >>= 1
    return product & 0xff


GF_MUL_BY_2 = array('B', [galois_multiply(value, 2) for value in range(256)])
GF_MUL_BY_3 = array('B', [galois_multiply(value, 3) for value in range(256)])

# 32-bit T-tables for fast pure-Python AES encryption in CTR mode
TE0 = [0] * 256
TE1 = [0] * 256
TE2 = [0] * 256
TE3 = [0] * 256
for _x in range(256):
    _s = AES_SBOX[_x]
    _s2 = GF_MUL_BY_2[_s]
    _s3 = GF_MUL_BY_3[_s]
    TE0[_x] = (_s2 << 24) | (_s << 16) | (_s << 8) | _s3
    TE1[_x] = (_s3 << 24) | (_s2 << 16) | (_s << 8) | _s
    TE2[_x] = (_s << 24) | (_s3 << 16) | (_s2 << 8) | _s
    TE3[_x] = (_s << 24) | (_s << 16) | (_s3 << 8) | _s2


class AES(object):
    block_size = 16

    def __init__(self, key):
        self.setkey(key)

    def setkey(self, key):
        self.key = key
        self.key_size = len(key)

        if self.key_size == 16:
            self.rounds = 10
        elif self.key_size == 24:
            self.rounds = 12
        elif self.key_size == 32:
            self.rounds = 14
        else:
            raise ValueError('Key length must be 16, 24 or 32 bytes')

        self.expand_key()

    def expand_key(self):
        expanded = array('B', self.key)

        if self.key_size == 16:
            extra_count = 0
        elif self.key_size == 24:
            extra_count = 2
        else:
            extra_count = 3

        word = expanded[-4:]

        for index in range(1, 11):
            word = word[1:4] + word[0:1]

            for inner in range(4):
                word[inner] = AES_SBOX[word[inner]]

            word[0] ^= AES_RCON[index]

            for _ in range(4):
                for inner in range(4):
                    word[inner] ^= expanded[-self.key_size + inner]
                expanded.extend(word)

            if len(expanded) >= (self.rounds + 1) * self.block_size:
                break

            if self.key_size == 32:
                for inner in range(4):
                    word[inner] = AES_SBOX[word[inner]] ^ expanded[-self.key_size + inner]
                expanded.extend(word)

            for _ in range(extra_count):
                for inner in range(4):
                    word[inner] ^= expanded[-self.key_size + inner]
                expanded.extend(word)

        self.exkey = expanded

    def add_round_key(self, block, round_index):
        offset = round_index * 16
        for index in range(16):
            block[index] ^= self.exkey[offset + index]

    def sub_bytes(self, block):
        for index in range(16):
            block[index] = AES_SBOX[block[index]]

    def shift_rows(self, block):
        block[1], block[5], block[9], block[13] = block[5], block[9], block[13], block[1]
        block[2], block[6], block[10], block[14] = block[10], block[14], block[2], block[6]
        block[3], block[7], block[11], block[15] = block[15], block[3], block[7], block[11]

    def mix_columns(self, block):
        for column in range(4):
            offset = column * 4
            value0, value1, value2, value3 = block[offset:offset + 4]
            block[offset] = GF_MUL_BY_2[value0] ^ GF_MUL_BY_3[value1] ^ value2 ^ value3
            block[offset + 1] = value0 ^ GF_MUL_BY_2[value1] ^ GF_MUL_BY_3[value2] ^ value3
            block[offset + 2] = value0 ^ value1 ^ GF_MUL_BY_2[value2] ^ GF_MUL_BY_3[value3]
            block[offset + 3] = GF_MUL_BY_3[value0] ^ value1 ^ value2 ^ GF_MUL_BY_2[value3]

    def encrypt_block(self, block_bytes):
        if len(block_bytes) != 16:
            raise ValueError('AES block must be exactly 16 bytes')

        block = array('B', block_bytes)
        self.add_round_key(block, 0)

        for round_index in range(1, self.rounds):
            self.sub_bytes(block)
            self.shift_rows(block)
            self.mix_columns(block)
            self.add_round_key(block, round_index)

        self.sub_bytes(block)
        self.shift_rows(block)
        self.add_round_key(block, self.rounds)
        return block.tobytes()


def _decrypt_ctr_native(key, iv, ciphertext):
    """Attempt C-extension AES-CTR decryption if available on the host Kodi."""
    if _PyCryptoAES is not None:
        try:
            cipher = _PyCryptoAES.new(key, _PyCryptoAES.MODE_CTR, nonce=iv, initial_value=2)
            return cipher.decrypt(ciphertext)
        except Exception:
            pass

    if _CryptoCipher is not None:
        try:
            cipher = _CryptoCipher(
                _CryptoAlgorithms.AES(key),
                _CryptoModes.CTR(iv + b'\x00\x00\x00\x02'),
            )
            decryptor = cipher.decryptor()
            return decryptor.update(ciphertext) + decryptor.finalize()
        except Exception:
            pass

    return None


def _decrypt_ctr_ttable(key, iv, ciphertext):
    """Fast pure-Python AES-CTR using precomputed 32-bit T-tables."""
    aes_obj = AES(key)
    exkey = aes_obj.exkey
    rounds = aes_obj.rounds
    rk = [
        int.from_bytes(exkey[i:i + 4].tobytes(), 'big')
        for i in range(0, (rounds + 1) * 16, 4)
    ]

    sbox = AES_SBOX
    te0, te1, te2, te3 = TE0, TE1, TE2, TE3
    pack_into = _STRUCT_4I.pack_into

    iv_prefix_0 = int.from_bytes(iv[0:4], 'big') ^ rk[0]
    iv_prefix_1 = int.from_bytes(iv[4:8], 'big') ^ rk[1]
    iv_prefix_2 = int.from_bytes(iv[8:12], 'big') ^ rk[2]
    rk3 = rk[3]
    rk_rounds = [
        (rk[i], rk[i + 1], rk[i + 2], rk[i + 3])
        for i in range(4, rounds * 4, 4)
    ]
    last_rk0, last_rk1, last_rk2, last_rk3 = rk[rounds * 4:rounds * 4 + 4]

    n_len = len(ciphertext)
    num_blocks = (n_len + 15) // 16
    keystream = bytearray(num_blocks * 16)
    ctr = 1
    out_off = 0

    for _ in range(num_blocks):
        ctr = (ctr + 1) & 0xffffffff
        t0 = iv_prefix_0
        t1 = iv_prefix_1
        t2 = iv_prefix_2
        t3 = ctr ^ rk3

        for rk0, rk1, rk2, r3 in rk_rounds:
            a0 = te0[(t0 >> 24) & 0xff] ^ te1[(t1 >> 16) & 0xff] ^ te2[(t2 >> 8) & 0xff] ^ te3[t3 & 0xff] ^ rk0
            a1 = te0[(t1 >> 24) & 0xff] ^ te1[(t2 >> 16) & 0xff] ^ te2[(t3 >> 8) & 0xff] ^ te3[t0 & 0xff] ^ rk1
            a2 = te0[(t2 >> 24) & 0xff] ^ te1[(t3 >> 16) & 0xff] ^ te2[(t0 >> 8) & 0xff] ^ te3[t1 & 0xff] ^ rk2
            a3 = te0[(t3 >> 24) & 0xff] ^ te1[(t0 >> 16) & 0xff] ^ te2[(t1 >> 8) & 0xff] ^ te3[t2 & 0xff] ^ r3
            t0, t1, t2, t3 = a0, a1, a2, a3

        ks0 = ((sbox[(t0 >> 24) & 0xff] << 24) | (sbox[(t1 >> 16) & 0xff] << 16) | (sbox[(t2 >> 8) & 0xff] << 8) | sbox[t3 & 0xff]) ^ last_rk0
        ks1 = ((sbox[(t1 >> 24) & 0xff] << 24) | (sbox[(t2 >> 16) & 0xff] << 16) | (sbox[(t3 >> 8) & 0xff] << 8) | sbox[t0 & 0xff]) ^ last_rk1
        ks2 = ((sbox[(t2 >> 24) & 0xff] << 24) | (sbox[(t3 >> 16) & 0xff] << 16) | (sbox[(t0 >> 8) & 0xff] << 8) | sbox[t1 & 0xff]) ^ last_rk2
        ks3 = ((sbox[(t3 >> 24) & 0xff] << 24) | (sbox[(t0 >> 16) & 0xff] << 16) | (sbox[(t1 >> 8) & 0xff] << 8) | sbox[t2 & 0xff]) ^ last_rk3

        pack_into(keystream, out_off, ks0, ks1, ks2, ks3)
        out_off += 16

    ks_int = int.from_bytes(keystream[:n_len], 'big')
    ct_int = int.from_bytes(ciphertext, 'big')
    return (ct_int ^ ks_int).to_bytes(n_len, 'big')


def aes_gcm_decrypt_no_auth(key, iv, encrypted_payload):
    if len(iv) != 12:
        raise ValueError('Nguonc manifest nonce must be 12 bytes')
    if len(encrypted_payload) <= 16:
        raise ValueError('Nguonc manifest payload is too short')

    ciphertext = encrypted_payload[:-16]
    if not ciphertext:
        return b''

    if len(ciphertext) < (1 << 32) * 16:
        native_result = _decrypt_ctr_native(key, iv, ciphertext)
        if native_result is not None:
            return native_result

    return _decrypt_ctr_ttable(key, iv, ciphertext)


def decrypt_nguonc_manifest(encoded_payload, video_hash, iv_hex):
    encrypted_payload = base64.b64decode(encoded_payload)
    key = hmac.new(b'stream-derive-v1', video_hash.encode('utf-8'), hashlib.sha256).digest()
    plaintext = aes_gcm_decrypt_no_auth(key, bytes.fromhex(iv_hex), encrypted_payload)
    return plaintext.decode('utf-8')


def decrypt_nguonc_bootstrap(envelope, api_url):
    envelope = envelope or {}
    iv_hex = envelope.get('iv') or ''
    payload_b64 = envelope.get('data') or ''
    if envelope.get('format') != 'aesgcm-v1':
        raise ValueError('Bootstrap envelope khong dung dinh dang aesgcm-v1')
    if not iv_hex or len(iv_hex) != 24 or not payload_b64:
        raise ValueError('Bootstrap envelope thieu iv hoac data')

    associated_data = ('stream-bootstrap-v1\n' + api_url).encode('utf-8')
    key = hashlib.sha256(associated_data).digest()
    plaintext = aes_gcm_decrypt_no_auth(key, bytes.fromhex(iv_hex), base64.b64decode(payload_b64))
    return plaintext.decode('utf-8')
