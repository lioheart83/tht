import base64
import hashlib
import json
import re
import threading
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import httpx
import xbmc

from resources.lib.nguonc_api import BASE_URL, HEADERS, log
from resources.lib.nguonc_crypto import decrypt_nguonc_bootstrap, decrypt_nguonc_manifest

_TAG_URI_RE = re.compile(r'URI="([^"]+)"')


def url_origin(url):
    parsed = urllib.parse.urlsplit(url)
    return parsed.scheme + '://' + parsed.netloc


def build_proxy_request_headers(client_headers=None, referer=None, forward_range=True):
    headers = {
        'User-Agent': HEADERS['User-Agent'],
        'Accept': '*/*',
        'Accept-Language': HEADERS['Accept-Language'],
        'Referer': referer or (BASE_URL + '/'),
    }
    if forward_range and client_headers:
        range_header = client_headers.get('Range')
        if range_header:
            headers['Range'] = range_header
    return headers


def _is_playlist_url(url):
    path = urllib.parse.urlsplit(url).path.lower()
    return path.endswith('.m3u8') or path.endswith('.m3u')


def rewrite_manifest(manifest_text, port, base_url, register_resource):
    rewritten_lines = []
    next_is_variant = False

    for line in manifest_text.splitlines():
        stripped = line.strip()
        if not stripped:
            rewritten_lines.append(line)
            continue

        if stripped.startswith('#'):
            upper = stripped.upper()
            if upper.startswith('#EXT-X-STREAM-INF'):
                next_is_variant = True

            if 'URI="' in stripped:
                is_sub_tag = upper.startswith('#EXT-X-MEDIA') or upper.startswith('#EXT-X-I-FRAME-STREAM-INF')

                def _replace_uri(match):
                    raw_uri = match.group(1)
                    if raw_uri.startswith('data:'):
                        return match.group(0)
                    abs_uri = urllib.parse.urljoin(base_url, raw_uri) if base_url else raw_uri
                    if not abs_uri.startswith(('http://', 'https://')):
                        return match.group(0)
                    kind = 'sub' if (is_sub_tag or _is_playlist_url(abs_uri)) else 'asset'
                    res_id = register_resource(kind, abs_uri)
                    if kind == 'sub':
                        return f'URI="http://127.0.0.1:{port}/sub/{res_id}.m3u8"'
                    return f'URI="http://127.0.0.1:{port}/asset/{res_id}.bin"'

                rewritten_lines.append(_TAG_URI_RE.sub(_replace_uri, line))
            else:
                rewritten_lines.append(line)
            continue

        abs_uri = urllib.parse.urljoin(base_url, stripped) if base_url else stripped
        if abs_uri.startswith(('http://', 'https://')):
            is_sub = next_is_variant or _is_playlist_url(abs_uri)
            next_is_variant = False
            kind = 'sub' if is_sub else 'segment'
            res_id = register_resource(kind, abs_uri)
            if kind == 'sub':
                rewritten_lines.append(f'http://127.0.0.1:{port}/sub/{res_id}.m3u8')
            else:
                rewritten_lines.append(f'http://127.0.0.1:{port}/segment/{res_id}.ts')
        else:
            next_is_variant = False
            rewritten_lines.append(line)

    return '\n'.join(rewritten_lines)


def build_proxy_manifest(manifest_text, port, base_url=''):
    resources = []

    def _register(kind, url):
        idx = len(resources)
        resources.append({'kind': kind, 'url': url})
        return idx

    rewritten = rewrite_manifest(manifest_text, port, base_url, _register)
    return rewritten, resources


class NguoncProxyServer(object):
    def __init__(self, manifest_text, referer, base_manifest_url='', video_hash=''):
        self.referer = referer
        self.base_manifest_url = base_manifest_url or referer
        self.video_hash = video_hash or ''
        self.segment_session = httpx.Client(
            http2=True,
            follow_redirects=True,
            timeout=httpx.Timeout(30.0, connect=10.0),
            limits=httpx.Limits(max_keepalive_connections=12, max_connections=24),
            headers={
                'User-Agent': HEADERS['User-Agent'],
                'Accept': '*/*',
                'Accept-Language': HEADERS['Accept-Language'],
            },
        )
        self.timeout = 30.0
        self.httpd = None
        self.thread = None
        self._lock = threading.Lock()
        self.resources = []
        self.manifest_text = ''

        owner = self

        class ProxyHandler(BaseHTTPRequestHandler):
            protocol_version = 'HTTP/1.1'

            def do_HEAD(self):
                self._handle_request(send_body=False)

            def do_GET(self):
                self._handle_request(send_body=True)

            def _send_bytes_response(self, status_code, content_type, payload_bytes, send_body):
                self.send_response(status_code)
                self.send_header('Content-Type', content_type)
                self.send_header('Content-Length', str(len(payload_bytes)))
                self.send_header('Cache-Control', 'no-cache')
                self.end_headers()
                if send_body and payload_bytes:
                    self.wfile.write(payload_bytes)

            def _handle_request(self, send_body):
                headers_sent = False
                try:
                    req_path = urllib.parse.urlsplit(self.path).path

                    if req_path == '/manifest.m3u8':
                        payload = owner.manifest_text.encode('utf-8')
                        headers_sent = True
                        self._send_bytes_response(200, 'application/vnd.apple.mpegurl', payload, send_body)
                        return

                    sub_match = re.match(r'^/sub/(\d+)\.m3u8$', req_path)
                    if sub_match:
                        res = owner._get_resource(int(sub_match.group(1)))
                        if not res:
                            self.send_error(404)
                            return
                        resp = owner.segment_session.get(
                            res['url'],
                            headers=build_proxy_request_headers(None, owner.referer, forward_range=False),
                            timeout=owner.timeout,
                        )
                        if resp.status_code >= 400:
                            self.send_error(502)
                            return
                        sub_text = resp.text
                        if '#ENC-AESGCM' in sub_text and owner.video_hash:
                            sub_text = decrypt_manifest_text(sub_text, owner.video_hash)
                        rewritten_sub = rewrite_manifest(
                            sub_text,
                            owner.port,
                            str(resp.url),
                            owner._register_resource,
                        )
                        payload = rewritten_sub.encode('utf-8')
                        headers_sent = True
                        self._send_bytes_response(200, 'application/vnd.apple.mpegurl', payload, send_body)
                        return

                    seg_match = re.match(r'^/(segment|asset)/(\d+)\.(?:ts|bin)$', req_path)
                    if seg_match:
                        route_kind = seg_match.group(1)
                        res = owner._get_resource(int(seg_match.group(2)))
                        if not res:
                            self.send_error(404)
                            return

                        req_headers = build_proxy_request_headers(self.headers, owner.referer, forward_range=True)

                        if not send_body:
                            head_resp = owner.segment_session.head(
                                res['url'],
                                headers=req_headers,
                                timeout=owner.timeout,
                            )
                            if head_resp.status_code not in (405, 501):
                                if head_resp.status_code >= 400:
                                    self.send_error(502)
                                    return
                                headers_sent = True
                                self._write_upstream_headers(head_resp, route_kind)
                                return

                        with owner.segment_session.stream(
                            'GET',
                            res['url'],
                            headers=req_headers,
                            timeout=owner.timeout,
                        ) as upstream:
                            if upstream.status_code >= 400:
                                self.send_error(502)
                                return

                            headers_sent = True
                            self._write_upstream_headers(upstream, route_kind)

                            if send_body:
                                for chunk in upstream.iter_bytes(chunk_size=64 * 1024):
                                    if chunk:
                                        self.wfile.write(chunk)
                        return

                    self.send_error(404)
                except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                    return
                except Exception as exc:
                    log('Nguonc proxy error: ' + str(exc), xbmc.LOGERROR)
                    if not headers_sent:
                        try:
                            self.send_error(502)
                        except Exception:
                            pass

            def _write_upstream_headers(self, upstream, route_kind):
                self.send_response(upstream.status_code)
                if route_kind == 'segment':
                    content_type = 'video/mp2t'
                else:
                    content_type = upstream.headers.get('Content-Type') or 'application/octet-stream'
                self.send_header('Content-Type', content_type)
                for name in ('Content-Length', 'Content-Range', 'Accept-Ranges'):
                    value = upstream.headers.get(name)
                    if value:
                        self.send_header(name, value)
                self.end_headers()

            def log_message(self, format, *args):
                return

        self.handler_class = ProxyHandler
        self.httpd = ThreadingHTTPServer(('127.0.0.1', 0), self.handler_class)
        self.port = self.httpd.server_address[1]
        self.manifest_text = rewrite_manifest(
            manifest_text,
            self.port,
            self.base_manifest_url,
            self._register_resource,
        )

    def _register_resource(self, kind, url):
        with self._lock:
            idx = len(self.resources)
            self.resources.append({'kind': kind, 'url': url})
            return idx

    def _get_resource(self, idx):
        with self._lock:
            if 0 <= idx < len(self.resources):
                return self.resources[idx]
            return None

    def start(self):
        self.thread = threading.Thread(target=self.httpd.serve_forever, name='NguoncProxy', daemon=True)
        self.thread.start()
        return 'http://127.0.0.1:%d/manifest.m3u8' % self.port

    def stop(self):
        if self.httpd is not None:
            try:
                self.httpd.shutdown()
                self.httpd.server_close()
            except Exception:
                pass
            self.httpd = None
        if self.thread is not None:
            self.thread.join(timeout=1)
            self.thread = None
        try:
            self.segment_session.close()
        except Exception:
            pass


def decrypt_manifest_text(manifest_text, video_hash):
    iv_match = re.search(r'iv=([0-9a-fA-F]+)', manifest_text)
    payload_line = next(
        (line.strip() for line in manifest_text.splitlines() if line.strip() and not line.startswith('#')),
        '',
    )

    if not video_hash or not iv_match or not payload_line:
        raise ValueError('Khong tim duoc du lieu giai ma manifest')

    decrypted_manifest = decrypt_nguonc_manifest(payload_line, video_hash, iv_match.group(1))
    if '#EXTM3U' not in decrypted_manifest:
        raise ValueError('Manifest sau giai ma khong hop le')
    return decrypted_manifest


def open_stream_client():
    return httpx.Client(
        http2=True,
        follow_redirects=True,
        timeout=httpx.Timeout(30.0, connect=10.0),
        headers={
            'User-Agent': HEADERS['User-Agent'],
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': HEADERS['Accept-Language'],
        },
    )


def resolve_bootstrap_playlist(client, play_url):
    """Flow player streamc.xyz: POST bootstrap de nhan grant AES-GCM chua URL playlist da ky san."""
    origin = url_origin(play_url)
    post_headers = {
        'Content-Type': 'application/json',
        'Referer': BASE_URL + '/',
        'Origin': origin,
    }
    common_body = {
        'referrer': BASE_URL + '/',
        'frame_origins': [BASE_URL],
        'playlist_format': 'aesgcm-v2',
        'pretty_url': True,
        'path_chunks': True,
    }

    bootstrap_body = dict(common_body)
    bootstrap_body.update({'action': 'bootstrap', 'request_grant': True, 'bootstrap_format': 'aesgcm-v1'})
    resp = client.post(play_url, headers=post_headers, json=bootstrap_body)
    if resp.status_code == 429:
        raise ValueError('Streamc gioi han tan suat, thu lai sau: ' + (resp.headers.get('Retry-After') or '10s'))
    resp.raise_for_status()

    envelope = resp.json()
    if envelope.get('format') == 'aesgcm-v1':
        grant = json.loads(decrypt_nguonc_bootstrap(envelope, play_url))
    else:
        grant = envelope

    video_hash = grant.get('video') or ''
    if not video_hash:
        video_hash = (urllib.parse.parse_qs(urllib.parse.urlsplit(play_url).query).get('hash') or [''])[0]
    if not video_hash:
        raise ValueError('Bootstrap khong cho thay video hash')

    playlist_url = (grant.get('preissued') or {}).get('playlist')
    if not playlist_url:
        if grant.get('turnstileEnabled'):
            raise ValueError('Streamc bat xac minh Turnstile, chua ho tro tu dong')
        issue_body = dict(common_body)
        issue_body.update({'action': 'issue', 'bootstrap': grant.get('bootstrap'), 'turnstile_response': ''})
        resp = client.post(play_url, headers=post_headers, json=issue_body)
        resp.raise_for_status()
        issued = resp.json()
        playlist_url = issued.get('playlist')
    if not playlist_url:
        raise ValueError('Bootstrap khong tra ve playlist')

    return playlist_url, video_hash


def resolve_legacy_playlist(client, play_url):
    """Flow cu (data-obf hoac link truc tiep tren trang embed) — giu lai lam du phong."""
    headers = {'User-Agent': HEADERS['User-Agent'], 'Referer': BASE_URL + '/'}
    embed_response = client.get(play_url, headers=headers)
    embed_response.raise_for_status()

    body = embed_response.text
    obf_match = re.search(r'data-obf="([^"]+)"', body)
    if obf_match:
        stream_data = json.loads(base64.b64decode(obf_match.group(1)).decode('utf-8'))
        stream_slug = stream_data.get('sUb')
        video_hash = stream_data.get('hD') or hashlib.md5(play_url.encode('utf-8')).hexdigest()
        if not stream_slug:
            raise ValueError('Khong tim thay duong dan manifest')
        manifest_url = urllib.parse.urljoin(str(embed_response.url), stream_slug)
        return manifest_url, video_hash

    if body.lstrip().startswith('#EXTM3U'):
        video_hash = (urllib.parse.parse_qs(urllib.parse.urlsplit(play_url).query).get('hash') or [''])[0]
        return str(embed_response.url), video_hash or hashlib.md5(play_url.encode('utf-8')).hexdigest()

    direct_m3u8 = re.search(r'["\'](https?://[^"\'\s]+\.m3u8[^"\'\s]*)["\']', body)
    if direct_m3u8:
        return direct_m3u8.group(1), hashlib.md5(play_url.encode('utf-8')).hexdigest()

    raise ValueError('Khong tim thay thong tin stream tren trang embed')


def fetch_manifest_text(client, manifest_url, referer):
    manifest_response = client.get(manifest_url, headers={'Referer': referer})
    manifest_response.raise_for_status()
    return manifest_response.text, str(manifest_response.url)


def resolve_kodi_stream(play_url):
    parsed = urllib.parse.urlsplit(play_url)
    path_lower = parsed.path.lower()
    host_lower = parsed.netloc.lower()

    if path_lower.endswith('.mp4') and 'streamc.xyz' not in host_lower:
        kodi_headers = urllib.parse.urlencode({
            'User-Agent': HEADERS['User-Agent'],
            'Referer': BASE_URL + '/',
        })
        return f'{play_url}|{kodi_headers}', None

    client = open_stream_client()
    video_hash = ''
    referer_for_proxy = play_url
    try:
        if _is_playlist_url(play_url) and 'streamc.xyz' not in host_lower:
            referer_for_proxy = BASE_URL + '/'
            manifest_url = play_url
            video_hash = (urllib.parse.parse_qs(parsed.query).get('hash') or [''])[0] or hashlib.md5(play_url.encode('utf-8')).hexdigest()
        else:
            try:
                manifest_url, video_hash = resolve_bootstrap_playlist(client, play_url)
            except Exception as exc:
                log('Bootstrap flow that bai, thu flow du phong: ' + str(exc), xbmc.LOGWARNING)
                manifest_url, video_hash = resolve_legacy_playlist(client, play_url)

        manifest_text, final_manifest_url = fetch_manifest_text(client, manifest_url, referer_for_proxy)
        if '#ENC-AESGCM' in manifest_text:
            manifest_text = decrypt_manifest_text(manifest_text, video_hash)
    finally:
        client.close()

    proxy_server = NguoncProxyServer(
        manifest_text,
        referer=referer_for_proxy,
        base_manifest_url=final_manifest_url,
        video_hash=video_hash,
    )
    proxy_url = proxy_server.start()
    return proxy_url, proxy_server
