import datetime
import html
import math
import re
import threading
import time
import urllib.parse

import httpx
import xbmc

from resources.lib.nguonc_storage import cache_get, cache_set

BASE_URL = 'https://phim.nguonc.com'
API_URL = BASE_URL + '/api'

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
    'Accept': 'application/json, text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7',
    'Referer': BASE_URL + '/',
}

GENRES = [
    ('hanh-dong', 'Hành Động'),
    ('phieu-luu', 'Phiêu Lưu'),
    ('hoat-hinh', 'Hoạt Hình'),
    ('phim-hai', 'Hài'),
    ('hinh-su', 'Hình Sự'),
    ('tai-lieu', 'Tài Liệu'),
    ('chinh-kich', 'Chính Kịch'),
    ('gia-dinh', 'Gia Đình'),
    ('gia-tuong', 'Giả Tưởng'),
    ('lich-su', 'Lịch Sử'),
    ('kinh-di', 'Kinh Dị'),
    ('phim-nhac', 'Nhạc'),
    ('bi-an', 'Bí Ẩn'),
    ('lang-man', 'Lãng Mạn'),
    ('khoa-hoc-vien-tuong', 'Khoa Học Viễn Tưởng'),
    ('gay-can', 'Gây Cấn'),
    ('chien-tranh', 'Chiến Tranh'),
    ('tam-ly', 'Tâm Lý'),
    ('tinh-cam', 'Tình Cảm'),
    ('co-trang', 'Cổ Trang'),
    ('mien-tay', 'Miền Tây'),
    ('phim-18', 'Phim 18+'),
]

COUNTRIES = [
    ('viet-nam', 'Việt Nam'),
    ('han-quoc', 'Hàn Quốc'),
    ('trung-quoc', 'Trung Quốc'),
    ('my', 'Mỹ'),
    ('nhat-ban', 'Nhật Bản'),
    ('thai-lan', 'Thái Lan'),
    ('dai-loan', 'Đài Loan'),
    ('hong-kong', 'Hồng Kông'),
    ('an-do', 'Ấn Độ'),
    ('anh', 'Anh'),
    ('phap', 'Pháp'),
    ('canada', 'Ca-na-đa'),
    ('duc', 'Đức'),
    ('tay-ban-nha', 'Tây Ban Nha'),
    ('italy', 'Italy'),
    ('uc', 'Úc'),
    ('philippines', 'Phi-líp-pin'),
    ('bi', 'Bỉ'),
    ('brazil', 'Bra-xin'),
    ('nga', 'Nga'),
]

LANGUAGES = [
    ('vietsub', 'Phim Vietsub'),
    ('thuyet-minh', 'Phim Thuyết minh'),
    ('long-tieng', 'Phim Lồng tiếng'),
]

_CURRENT_YEAR = max(2026, datetime.datetime.now().year)
YEARS = [(str(y), str(y)) for y in range(_CURRENT_YEAR, 2003, -1)]

_CLIENT_LOCK = threading.Lock()
_HTTP_CLIENT = None


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[NguoncPhim] ' + str(msg), level)


def get_http_client():
    global _HTTP_CLIENT
    with _CLIENT_LOCK:
        if _HTTP_CLIENT is None or _HTTP_CLIENT.is_closed:
            _HTTP_CLIENT = httpx.Client(
                http2=True,
                follow_redirects=True,
                timeout=httpx.Timeout(25.0, connect=10.0),
                headers=HEADERS,
            )
        return _HTTP_CLIENT


def close_http_client():
    global _HTTP_CLIENT
    with _CLIENT_LOCK:
        if _HTTP_CLIENT is not None and not _HTTP_CLIENT.is_closed:
            try:
                _HTTP_CLIENT.close()
            except Exception:
                pass
            _HTTP_CLIENT = None


def _parse_retry_after(header_value, default_seconds):
    if not header_value:
        return default_seconds
    try:
        seconds = float(str(header_value).strip())
        return max(0.5, min(5.0, seconds))
    except (TypeError, ValueError):
        return default_seconds


def fetch_json(path_or_url, ttl_seconds=600):
    url = path_or_url if str(path_or_url).startswith('http') else (API_URL + path_or_url)
    cache_key = 'json:' + url

    if ttl_seconds and ttl_seconds > 0:
        cached = cache_get(cache_key, ttl_seconds)
        if cached is not None:
            return cached

    client = get_http_client()
    max_attempts = 3
    retryable_codes = (429, 502, 503, 504)

    for attempt in range(max_attempts):
        try:
            log('GET ' + url)
            resp = client.get(url)
            if resp.status_code == 404:
                log('API 404 Not Found: ' + url, xbmc.LOGWARNING)
                return None

            if resp.status_code in retryable_codes and attempt < max_attempts - 1:
                delay = _parse_retry_after(resp.headers.get('Retry-After'), 1.0 * (attempt + 1))
                log(f'HTTP {resp.status_code} for {url}, retrying in {delay:.1f}s', xbmc.LOGWARNING)
                time.sleep(delay)
                continue

            resp.raise_for_status()
            data = resp.json()
            if not isinstance(data, dict):
                log('Unexpected JSON root type for ' + url, xbmc.LOGWARNING)
                return None

            if not (data.get('status') == 'success' or data.get('status') is True or 'movie' in data or 'item' in data or 'items' in data):
                log('API status check failed or missing, returning data anyway.', xbmc.LOGWARNING)

            if ttl_seconds and ttl_seconds > 0:
                cache_set(cache_key, data)
            return data
        except httpx.RequestError as exc:
            if attempt < max_attempts - 1:
                delay = 0.8 * (attempt + 1)
                log(f'Request error for {url}: {exc}, retrying in {delay:.1f}s', xbmc.LOGWARNING)
                time.sleep(delay)
                continue
            log('fetch_json request error: ' + str(exc), xbmc.LOGERROR)
            return None
        except Exception as exc:
            log('fetch_json error: ' + str(exc), xbmc.LOGERROR)
            return None

    return None


def get_dynamic_catalog(kind, show_adult=False):
    static_map = {
        'the-loai': GENRES,
        'quoc-gia': COUNTRIES,
        'nam-phat-hanh': YEARS,
        'ngon-ngu': LANGUAGES,
    }
    base_items = list(static_map.get(kind, []))

    if kind == 'the-loai':
        if not show_adult:
            base_items = [(s, n) for s, n in base_items if s != 'phim-18']
        return _merge_catalog_from_homepage(kind, base_items, show_adult=show_adult)

    if kind == 'quoc-gia':
        return _merge_catalog_from_homepage(kind, base_items, show_adult=False)

    if kind == 'nam-phat-hanh':
        merged = _merge_catalog_from_homepage(kind, base_items, show_adult=False)
        merged.sort(key=lambda pair: (0, -int(pair[0])) if pair[0].isdigit() else (1, pair[0]))
        return merged

    return base_items


def _merge_catalog_from_homepage(kind, base_items, show_adult=False):
    cache_key = f'catalog:{kind}'
    cached = cache_get(cache_key, 86400)
    discovered = cached if isinstance(cached, list) else None

    if discovered is None:
        discovered = []
        try:
            resp = get_http_client().get(BASE_URL + '/')
            if resp.status_code == 200:
                pattern = re.compile(
                    r'<a[^>]+href=["\'](?:https?://[^/"\']+)?/' + re.escape(kind) + r'/([a-zA-Z0-9_-]+)["\'][^>]*>(.*?)</a>',
                    re.S,
                )
                seen = set()
                for slug, inner in pattern.findall(resp.text):
                    label = clean_text(inner)
                    if slug and label and slug not in seen:
                        seen.add(slug)
                        discovered.append([slug, label])
                if discovered:
                    cache_set(cache_key, discovered)
        except Exception as exc:
            log('Dynamic catalog scrape skipped: ' + str(exc), xbmc.LOGDEBUG)

    merged = list(base_items)
    existing_slugs = {slug for slug, _ in merged}
    for entry in discovered:
        if not isinstance(entry, (list, tuple)) or len(entry) != 2:
            continue
        slug, label = str(entry[0]), str(entry[1])
        if kind == 'the-loai' and slug == 'phim-18' and not show_adult:
            continue
        if slug and slug not in existing_slugs:
            existing_slugs.add(slug)
            merged.append((slug, label))

    return merged


def clean_text(raw):
    if raw is None:
        return ''
    text = str(raw)
    text = re.sub(r'<br\s*/?>', '\n', text, flags=re.IGNORECASE)
    text = re.sub(r'</p\s*>', '\n', text, flags=re.IGNORECASE)
    text = re.sub(r'<[^>]+>', '', text)
    text = html.unescape(text)
    lines = [re.sub(r'[ \t]+', ' ', line).strip() for line in text.splitlines()]
    cleaned = '\n'.join(line for line in lines if line)
    return cleaned.strip()


def format_episode_badge(current_ep, total_eps):
    cur = clean_text(current_ep)
    tot_str = str(total_eps or '').strip()
    tot_int = int(tot_str) if tot_str.isdigit() else 0

    if '/' in cur or 'hoàn tất' in cur.lower() or 'hoan tat' in cur.lower():
        return cur
    if cur.upper() == 'FULL' or (tot_int == 1 and cur.lower() in ('1', 'full', '')):
        return 'Full'
    if cur and tot_int > 1:
        return f'{cur}/{tot_int}'
    return cur


def format_episode_title(ep_name, server_name):
    name = clean_text(ep_name)
    srv = clean_text(server_name)
    suffix = f'  [{srv}]' if srv else ''
    if not name:
        return f'Tập ?{suffix}'
    if name.upper() == 'FULL':
        return f'Bản Full{suffix}'
    if re.match(r'^(?:tập|tap|phần|phan|special|ova|trailer|ep|episode)(?:\s|$|:|-|\d)', name, re.IGNORECASE):
        return f'{name}{suffix}'
    return f'Tập {name}{suffix}'


def parse_duration_seconds(time_str):
    text = clean_text(time_str)
    if not text:
        return 0
    hours = 0
    minutes = 0
    h_match = re.search(r'(\d+)\s*(?:giờ|gio|h\b)', text, re.IGNORECASE)
    m_match = re.search(r'(\d+)\s*(?:phút|phut|min|m\b)', text, re.IGNORECASE)
    if h_match:
        hours = int(h_match.group(1))
    if m_match:
        minutes = int(m_match.group(1))
    if not h_match and not m_match:
        d_match = re.search(r'(\d+)', text)
        if d_match:
            minutes = int(d_match.group(1))
    return (hours * 3600) + (minutes * 60)


def _split_people(value):
    text = clean_text(value)
    if not text:
        return []
    parts = [part.strip() for part in text.split(',')]
    ignored = {'đang cập nhật', 'dang cap nhat', 'n/a', 'unknown', ''}
    return [part for part in parts if part.lower() not in ignored]


def extract_movie_metadata(item):
    item = item or {}
    category = item.get('category')
    genres = []
    countries = []
    formats = []
    cat_years = []

    if isinstance(category, dict):
        for group_entry in category.values():
            if not isinstance(group_entry, dict):
                continue
            group_name = str((group_entry.get('group') or {}).get('name') or '').strip().lower()
            entries = [
                clean_text(entry.get('name'))
                for entry in (group_entry.get('list') or [])
                if isinstance(entry, dict) and entry.get('name')
            ]
            if 'thể loại' in group_name or 'the loai' in group_name:
                genres.extend(entries)
            elif 'quốc gia' in group_name or 'quoc gia' in group_name:
                countries.extend(entries)
            elif 'định dạng' in group_name or 'dinh dang' in group_name:
                formats.extend(entries)
            elif 'năm' in group_name or 'nam' in group_name:
                cat_years.extend(entries)

    raw_year = str(item.get('year') or (cat_years[0] if cat_years else '') or '').strip()
    year_match = re.search(r'\d{4}', raw_year)
    year = int(year_match.group(0)) if year_match else 0

    thumb_url = str(item.get('thumb_url') or '').strip()
    poster_url = str(item.get('poster_url') or '').strip()
    poster = thumb_url or poster_url
    fanart = poster_url or thumb_url

    current_episode = str(item.get('episode_current') or item.get('current_episode') or '').strip()
    total_episodes = item.get('episode_total') or item.get('total_episodes') or ''
    total_int = int(str(total_episodes)) if str(total_episodes).isdigit() else 0

    format_lower = ' '.join(f.lower() for f in formats)
    is_series = (
        ('phim bộ' in format_lower)
        or ('tv shows' in format_lower)
        or ('hoạt hình' in format_lower and total_int != 1)
        or (total_int > 1)
        or ('tập' in current_episode.lower())
    )

    tmdb = item.get('tmdb') if isinstance(item.get('tmdb'), dict) else {}
    imdb = item.get('imdb') if isinstance(item.get('imdb'), dict) else {}

    return {
        'slug': str(item.get('slug') or ''),
        'name': clean_text(item.get('name') or 'Không tên'),
        'original_name': clean_text(item.get('original_name') or ''),
        'plot': clean_text(item.get('content') or item.get('description') or ''),
        'thumb_url': thumb_url,
        'poster_url': poster_url,
        'poster': poster,
        'fanart': fanart,
        'year': year,
        'genres': genres,
        'countries': countries,
        'formats': formats,
        'is_series': is_series,
        'directors': _split_people(item.get('director')),
        'casts': _split_people(item.get('casts') or item.get('actor')),
        'duration_seconds': parse_duration_seconds(item.get('time')),
        'quality': clean_text(item.get('quality') or ''),
        'language': clean_text(item.get('language') or ''),
        'current_episode': current_episode,
        'total_episodes': total_episodes,
        'episode_badge': format_episode_badge(current_episode, total_episodes),
        'imdb_id': str(imdb.get('id') or '').strip(),
        'tmdb_id': str(tmdb.get('id') or '').strip(),
        'tmdb_type': str(tmdb.get('type') or '').strip(),
    }


def _build_list_endpoint(list_type, slug, api_page):
    slug_aliases = {
        'dang-chieu': ('phim-moi-cap-nhat', 'phim-moi-cap-nhat'),
        'phim-dang-chieu': ('phim-moi-cap-nhat', 'phim-moi-cap-nhat'),
        'sap-chieu': ('phim-moi-cap-nhat', 'phim-moi-cap-nhat'),
        'phim-sap-chieu': ('phim-moi-cap-nhat', 'phim-moi-cap-nhat'),
    }
    if slug in slug_aliases:
        list_type, slug = slug_aliases[slug]
    elif list_type == 'danh-sach' and slug == 'hoat-hinh':
        list_type = 'the-loai'

    safe_slug = urllib.parse.quote(str(slug or ''))
    endpoints = {
        'phim-moi-cap-nhat': f'/films/phim-moi-cap-nhat?page={api_page}',
        'danh-sach': f'/films/danh-sach/{safe_slug}?page={api_page}',
        'the-loai': f'/films/the-loai/{safe_slug}?page={api_page}',
        'quoc-gia': f'/films/quoc-gia/{safe_slug}?page={api_page}',
        'nam-phat-hanh': f'/films/nam-phat-hanh/{safe_slug}?page={api_page}',
        'ngon-ngu': f'/films/ngon-ngu/{safe_slug}?page={api_page}',
        'search': f'/films/search?keyword={safe_slug}&page={api_page}',
    }
    return endpoints.get(list_type, endpoints['phim-moi-cap-nhat'])


def fetch_movie_list(list_type, slug, logical_page, pages_per_load=1, ttl_seconds=600):
    pages_per_load = max(1, min(3, int(pages_per_load or 1)))
    logical_page = max(1, int(logical_page or 1))
    start_api_page = (logical_page - 1) * pages_per_load + 1

    first_ep = _build_list_endpoint(list_type, slug, start_api_page)
    first_data = fetch_json(first_ep, ttl_seconds=ttl_seconds)
    if first_data is None:
        return None

    paginate = first_data.get('paginate') or {}
    api_total_page = max(1, int(paginate.get('total_page') or 1))
    total_items = int(paginate.get('total_items') or len(first_data.get('items') or []))

    combined_items = []
    seen_slugs = set()

    def _append_items(raw_items):
        for it in raw_items or []:
            if not isinstance(it, dict):
                continue
            item_slug = it.get('slug') or ''
            if item_slug and item_slug in seen_slugs:
                continue
            if item_slug:
                seen_slugs.add(item_slug)
            combined_items.append(it)

    _append_items(first_data.get('items'))

    end_api_page = min(start_api_page + pages_per_load - 1, api_total_page)
    for api_page in range(start_api_page + 1, end_api_page + 1):
        ep = _build_list_endpoint(list_type, slug, api_page)
        extra_data = fetch_json(ep, ttl_seconds=ttl_seconds)
        if extra_data:
            _append_items(extra_data.get('items'))

    total_logical_pages = max(1, math.ceil(api_total_page / pages_per_load))
    return {
        'items': combined_items,
        'current_page': logical_page,
        'total_page': total_logical_pages,
        'total_items': total_items,
        'cat': first_data.get('cat') or {},
    }


def fetch_movie_detail(film_slug, ttl_seconds=600):
    if not film_slug:
        return None
    return fetch_json('/film/' + urllib.parse.quote(str(film_slug)), ttl_seconds=ttl_seconds)
