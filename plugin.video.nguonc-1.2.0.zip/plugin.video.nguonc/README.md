# Nguonc Phim Kodi Addon

## Mô tả
Addon Kodi xem phim trực tuyến từ **phim.nguonc.com**, hỗ trợ đầy đủ kho phim, bộ lọc, lưu lịch sử/yêu thích và phát trực tiếp bên trong Kodi.

## Tính năng
- Danh mục chính: **Phim mới cập nhật**, **Phim lẻ**, **Phim bộ**, **Phim hoạt hình**, **TV Shows**, **Phim Thuyết minh**, **Phim Lồng tiếng**.
- Bộ lọc đầy đủ theo API Nguonc: **Thể loại**, **Quốc gia**, **Năm phát hành** (tự động cập nhật từ trang chủ).
- **Tìm kiếm** có phân trang đầy đủ và lưu lịch sử từ khóa tìm kiếm gần đây.
- **Phim yêu thích** & **Lịch sử đã xem** (lưu tập vừa xem gần nhất trong thư mục dữ liệu addon).
- Gom tập theo 4 nhóm server tách biệt: **Phụ đề (Vietsub)**, **Thuyết minh**, **Lồng tiếng**, **Khác**; tự động mở nhanh tập phát khi phim chỉ có 1 nhóm hoặc ít tập.
- Hiển thị đầy đủ metadata chuẩn `InfoTagVideo` (Kodi 20+) và `ListItem.setInfo` (Kodi 19), dùng ảnh ngang HD (`poster_url`) cho fanart/landscape.
- Tự giải mã luồng `streamc.xyz` (AES-GCM tối ưu bằng T-table / C-extension) và phát qua localhost proxy HTTP/2 hỗ trợ `HEAD`/`GET`/`Range`, tua phim mượt mà.
- Bộ nhớ đệm API (cache JSON có TTL cấu hình được trong Settings).

## Cài đặt
1. Cài trực tiếp từ file `plugin.video.nguonc-1.2.0.zip` trong Kodi (*Add-ons > Install from zip file*).
2. Hoặc copy thư mục `plugin.video.nguonc` vào thư mục `addons` của Kodi:
   - Windows: `%APPDATA%\Kodi\addons\`
   - Android: `Android/data/org.xbmc.kodi/files/.kodi/addons/`
   - Linux/Mac: `~/.kodi/addons/`
3. Mở **Video add-ons > Nguonc Phim**.

## Yêu cầu
- Kodi 19 (Matrix), 20 (Nexus), 21 (Omega) hoặc mới hơn (Python 3).
- Không cần cài thêm addon phụ thuộc ngoài (`httpx` + `h2` đã được đóng gói sẵn trong `resources/lib`).
- Thiết bị cho phép addon tạo kết nối localhost `127.0.0.1`.

## API đang sử dụng
- `GET /api/films/phim-moi-cap-nhat?page={page}`
- `GET /api/films/danh-sach/{slug}?page={page}`
- `GET /api/films/the-loai/{slug}?page={page}`
- `GET /api/films/quoc-gia/{slug}?page={page}`
- `GET /api/films/nam-phat-hanh/{year}?page={page}`
- `GET /api/films/ngon-ngu/{slug}?page={page}`
- `GET /api/films/search?keyword={keyword}&page={page}`
- `GET /api/film/{slug}`

## Version hiện tại
- `1.2.0` - Rà soát và nâng cấp toàn diện: sửa menu/tìm kiếm/settings, tối ưu giải mã AES-GCM, nâng cấp proxy HTTP/2, bổ sung đầy đủ bộ lọc, bộ nhớ đệm, yêu thích và lịch sử xem.
