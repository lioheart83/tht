import json
import os
import re
import sys
import urllib.parse

# Thu vien HTTP/2 bundle (httpx + h2...) nam trong resources/lib
_ADDON_DIR = os.path.dirname(os.path.abspath(__file__))
_LIB_DIR = os.path.join(_ADDON_DIR, 'resources', 'lib')
for _path in (_LIB_DIR, _ADDON_DIR):
    if _path not in sys.path:
        sys.path.insert(0, _path)

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

from resources.lib.nguonc_api import (
    close_http_client,
    extract_movie_metadata,
    fetch_movie_detail,
    fetch_movie_list,
    format_episode_badge,
    format_episode_title,
    get_dynamic_catalog,
    log,
)
from resources.lib.nguonc_storage import (
    add_favorite,
    add_search_keyword,
    cache_clear,
    clear_search_history,
    clear_watch_history,
    get_favorites,
    get_search_history,
    get_watch_history,
    is_favorite,
    record_watch_history,
    remove_favorite,
    remove_history_item,
    remove_search_keyword,
)
from resources.lib.nguonc_stream import resolve_kodi_stream


def get_addon():
    return xbmcaddon.Addon()


def get_handle():
    return int(sys.argv[1])


def build_url(query):
    return sys.argv[0] + '?' + urllib.parse.urlencode(query)


def _get_addon_art():
    addon = get_addon()
    try:
        icon = addon.getAddonInfo('icon') or ''
    except Exception:
        icon = ''
    try:
        fanart = addon.getAddonInfo('fanart') or ''
    except Exception:
        fanart = ''
    return icon, fanart


def get_pages_per_load():
    val = str(get_addon().getSetting('items_per_page_mode') or '10').strip()
    mapping = {
        '10': 1,
        '0': 1,
        '20': 2,
        '1': 2,
        '30': 3,
        '2': 3,
    }
    return mapping.get(val, 1)


def get_cache_ttl_seconds():
    val = str(get_addon().getSetting('cache_ttl_minutes') or '10').strip()
    try:
        minutes = max(0, int(val))
    except (TypeError, ValueError):
        minutes = 10
    return minutes * 60


def get_auto_expand_single_group():
    val = str(get_addon().getSetting('auto_expand_single_group') or 'true').strip().lower()
    return val != 'false'


def get_show_adult_genre():
    val = str(get_addon().getSetting('show_adult_genre') or 'false').strip().lower()
    return val == 'true'


def apply_video_info(li, meta, mediatype='video', title_override=None, episode_number=None):
    meta = meta or {}
    poster = meta.get('poster') or meta.get('thumb_url') or ''
    fanart = meta.get('fanart') or meta.get('poster_url') or poster

    art = {}
    if poster:
        art['thumb'] = poster
        art['poster'] = poster
        art['icon'] = poster
    if fanart:
        art['fanart'] = fanart
        art['landscape'] = fanart
    if art:
        li.setArt(art)

    title = title_override or meta.get('name') or 'Không tên'
    plot = meta.get('plot') or ''

    tag = li.getVideoInfoTag() if hasattr(li, 'getVideoInfoTag') else None
    if tag is not None and hasattr(tag, 'setTitle'):
        tag.setTitle(title)
        if meta.get('original_name') and hasattr(tag, 'setOriginalTitle'):
            tag.setOriginalTitle(meta['original_name'])
        if plot and hasattr(tag, 'setPlot'):
            tag.setPlot(plot)
        if mediatype and hasattr(tag, 'setMediaType'):
            tag.setMediaType(mediatype)
        if meta.get('year') and hasattr(tag, 'setYear'):
            try:
                tag.setYear(int(meta['year']))
            except (TypeError, ValueError):
                pass
        if meta.get('genres') and hasattr(tag, 'setGenres'):
            tag.setGenres(list(meta['genres']))
        if meta.get('countries') and hasattr(tag, 'setCountries'):
            tag.setCountries(list(meta['countries']))
        if meta.get('directors') and hasattr(tag, 'setDirectors'):
            tag.setDirectors(list(meta['directors']))
        if meta.get('duration_seconds') and hasattr(tag, 'setDuration'):
            try:
                tag.setDuration(int(meta['duration_seconds']))
            except (TypeError, ValueError):
                pass
        if episode_number is not None:
            if hasattr(tag, 'setEpisode'):
                tag.setEpisode(int(episode_number))
            if hasattr(tag, 'setSeason'):
                tag.setSeason(1)
        if meta.get('casts') and hasattr(tag, 'setCast') and hasattr(xbmc, 'Actor'):
            try:
                tag.setCast([xbmc.Actor(name) for name in meta['casts']])
            except Exception:
                pass
        unique_ids = {}
        if meta.get('imdb_id'):
            unique_ids['imdb'] = str(meta['imdb_id'])
        if meta.get('tmdb_id'):
            unique_ids['tmdb'] = str(meta['tmdb_id'])
        if unique_ids and hasattr(tag, 'setUniqueIDs'):
            default_uid = 'tmdb' if 'tmdb' in unique_ids else 'imdb'
            try:
                tag.setUniqueIDs(unique_ids, default_uid)
            except TypeError:
                tag.setUniqueIDs(unique_ids)
    else:
        info_dict = {'title': title}
        if plot:
            info_dict['plot'] = plot
        if meta.get('original_name'):
            info_dict['originaltitle'] = meta['original_name']
        if mediatype:
            info_dict['mediatype'] = mediatype
        if meta.get('year'):
            try:
                info_dict['year'] = int(meta['year'])
            except (TypeError, ValueError):
                pass
        if meta.get('genres'):
            info_dict['genre'] = meta['genres']
        if meta.get('countries'):
            info_dict['country'] = meta['countries']
        if meta.get('directors'):
            info_dict['director'] = meta['directors']
        if meta.get('casts'):
            info_dict['cast'] = meta['casts']
        if meta.get('duration_seconds'):
            info_dict['duration'] = int(meta['duration_seconds'])
        if episode_number is not None:
            info_dict['episode'] = int(episode_number)
            info_dict['season'] = 1
        li.setInfo('video', info_dict)


def add_dir(title, url, thumb='', plot='', fanart='', meta=None, mediatype='video', context_menu=None, is_folder=True):
    li = xbmcgui.ListItem(label=title)
    item_meta = dict(meta) if meta else {}
    if not item_meta.get('name'):
        item_meta['name'] = title
    if plot and not item_meta.get('plot'):
        item_meta['plot'] = plot
    if thumb and not item_meta.get('poster'):
        item_meta['poster'] = thumb
    if fanart and not item_meta.get('fanart'):
        item_meta['fanart'] = fanart
    apply_video_info(li, item_meta, mediatype=mediatype, title_override=item_meta.get('name'))
    if context_menu:
        li.addContextMenuItems(context_menu)
    xbmcplugin.addDirectoryItem(handle=get_handle(), url=url, listitem=li, isFolder=is_folder)


def add_link(title, url, thumb='', plot='', fanart='', meta=None, mediatype='episode', episode_number=None, context_menu=None):
    li = xbmcgui.ListItem(label=title)
    item_meta = dict(meta) if meta else {}
    if not item_meta.get('name'):
        item_meta['name'] = title
    if plot and not item_meta.get('plot'):
        item_meta['plot'] = plot
    if thumb and not item_meta.get('poster'):
        item_meta['poster'] = thumb
    if fanart and not item_meta.get('fanart'):
        item_meta['fanart'] = fanart
    apply_video_info(
        li,
        item_meta,
        mediatype=mediatype,
        title_override=title,
        episode_number=episode_number,
    )
    li.setProperty('IsPlayable', 'true')
    if context_menu:
        li.addContextMenuItems(context_menu)
    xbmcplugin.addDirectoryItem(handle=get_handle(), url=url, listitem=li, isFolder=False)


def _compact_movie_payload(meta):
    return {
        'slug': meta.get('slug') or '',
        'name': meta.get('name') or '',
        'original_name': meta.get('original_name') or '',
        'year': meta.get('year') or '',
        'quality': meta.get('quality') or '',
        'language': meta.get('language') or '',
        'current_episode': meta.get('current_episode') or '',
        'total_episodes': meta.get('total_episodes') or '',
        'thumb_url': meta.get('thumb_url') or meta.get('poster') or '',
        'poster_url': meta.get('poster_url') or meta.get('fanart') or '',
    }


def _favorite_context_item(meta):
    slug = meta.get('slug') or ''
    if not slug:
        return None
    if is_favorite(slug):
        return (
            'Xóa khỏi Phim yêu thích',
            f'RunPlugin({build_url({"mode": "fav_remove", "slug": slug})})',
        )
    payload = json.dumps(_compact_movie_payload(meta), ensure_ascii=False)
    return (
        'Thêm vào Phim yêu thích',
        f'RunPlugin({build_url({"mode": "fav_add", "slug": slug, "movie": payload})})',
    )


def _format_movie_list_label(meta):
    parts = [p for p in (meta.get('quality'), meta.get('language'), meta.get('episode_badge')) if p]
    if parts:
        return f"{meta['name']} [{' | '.join(parts)}]"
    return meta['name']


def _render_movie_entries(items, extra_context_fn=None, label_fn=None):
    fav_slugs = {it.get('slug') for it in get_favorites()}
    for raw_item in items:
        meta = extract_movie_metadata(raw_item)
        slug = meta['slug']
        label = label_fn(raw_item, meta) if label_fn else _format_movie_list_label(meta)
        mediatype = 'tvshow' if meta.get('is_series') else 'movie'

        ctx = []
        if slug:
            if slug in fav_slugs:
                ctx.append(('Xóa khỏi Phim yêu thích', f'RunPlugin({build_url({"mode": "fav_remove", "slug": slug})})'))
            else:
                payload = json.dumps(_compact_movie_payload(meta), ensure_ascii=False)
                ctx.append(('Thêm vào Phim yêu thích', f'RunPlugin({build_url({"mode": "fav_add", "slug": slug, "movie": payload})})'))
        if extra_context_fn:
            extra_items = extra_context_fn(raw_item, meta)
            if extra_items:
                ctx.extend(extra_items)

        add_dir(
            label,
            build_url({'mode': 'detail', 'slug': slug}),
            meta=meta,
            mediatype=mediatype,
            context_menu=ctx or None,
        )


# ============================================================
# MAIN MENU & CATALOGS
# ============================================================
def menu_main():
    handle = get_handle()
    xbmcplugin.setContent(handle, 'videos')
    icon, fanart = _get_addon_art()
    clear_ctx = [('Xóa bộ nhớ đệm (Cache)', f'RunPlugin({build_url({"mode": "clear_cache"})})')]

    entries = [
        ('Phim mới cập nhật', {'mode': 'list', 'slug': 'phim-moi-cap-nhat', 'type': 'phim-moi-cap-nhat', 'page': 1}),
        ('Phim lẻ', {'mode': 'list', 'slug': 'phim-le', 'type': 'danh-sach', 'page': 1}),
        ('Phim bộ', {'mode': 'list', 'slug': 'phim-bo', 'type': 'danh-sach', 'page': 1}),
        ('Phim hoạt hình', {'mode': 'list', 'slug': 'hoat-hinh', 'type': 'the-loai', 'page': 1}),
        ('TV Shows', {'mode': 'list', 'slug': 'tv-shows', 'type': 'danh-sach', 'page': 1}),
        ('Phim Thuyết minh', {'mode': 'list', 'slug': 'thuyet-minh', 'type': 'ngon-ngu', 'page': 1}),
        ('Phim Lồng tiếng', {'mode': 'list', 'slug': 'long-tieng', 'type': 'ngon-ngu', 'page': 1}),
        ('Thể loại', {'mode': 'catalog', 'kind': 'the-loai'}),
        ('Quốc gia', {'mode': 'catalog', 'kind': 'quoc-gia'}),
        ('Năm phát hành', {'mode': 'catalog', 'kind': 'nam-phat-hanh'}),
        ('Tìm kiếm', {'mode': 'search_menu'}),
        ('Phim yêu thích', {'mode': 'favorites'}),
        ('Lịch sử đã xem', {'mode': 'history'}),
    ]

    for title, params in entries:
        add_dir(title, build_url(params), thumb=icon, fanart=fanart, context_menu=clear_ctx)

    xbmcplugin.endOfDirectory(handle)


def menu_catalog(kind):
    handle = get_handle()
    xbmcplugin.setContent(handle, 'videos')
    icon, fanart = _get_addon_art()
    items = get_dynamic_catalog(kind, show_adult=get_show_adult_genre())
    if not items:
        add_dir('Không có danh mục nào', build_url({'mode': 'noop'}), thumb=icon, fanart=fanart)
    else:
        for slug, name in items:
            add_dir(
                name,
                build_url({'mode': 'list', 'type': kind, 'slug': slug, 'page': 1}),
                thumb=icon,
                fanart=fanart,
            )
    xbmcplugin.endOfDirectory(handle)


# ============================================================
# LIST MOVIES
# ============================================================
def list_movies(list_type, slug, page):
    handle = get_handle()
    xbmcplugin.setContent(handle, 'movies')

    data = fetch_movie_list(
        list_type,
        slug,
        page,
        pages_per_load=get_pages_per_load(),
        ttl_seconds=get_cache_ttl_seconds(),
    )
    if data is None:
        add_dir('Lỗi: Không tải được dữ liệu từ Nguonc', build_url({'mode': 'noop'}))
        xbmcplugin.endOfDirectory(handle)
        return

    items = data.get('items', [])
    current_page = data.get('current_page', page)
    total_page = data.get('total_page', current_page)

    if not items:
        add_dir('Không tìm thấy phim nào', build_url({'mode': 'noop'}))
        xbmcplugin.endOfDirectory(handle)
        return

    _render_movie_entries(items)

    if current_page < total_page:
        icon, fanart = _get_addon_art()
        add_dir(
            f'>>> Trang {current_page + 1}/{total_page}',
            build_url({'mode': 'list', 'slug': slug, 'type': list_type, 'page': current_page + 1}),
            thumb=icon,
            fanart=fanart,
        )

    xbmcplugin.endOfDirectory(handle)


# ============================================================
# MOVIE DETAIL & SERVER GROUP
# ============================================================
def _classify_server_group(server_name):
    srv_lower = str(server_name or '').lower()
    if 'vietsub' in srv_lower or 'phụ đề' in srv_lower or 'phu de' in srv_lower:
        return 'sub'
    if 'thuyết minh' in srv_lower or 'thuyet minh' in srv_lower:
        return 'dub'
    if 'lồng tiếng' in srv_lower or 'long tieng' in srv_lower:
        return 'voice'
    return 'other'


def _episode_sort_key(item):
    name = str(item.get('name', '')).strip()
    num_match = re.search(r'\d+(?:\.\d+)?', name)
    if num_match:
        return (0, float(num_match.group(0)), name.lower())
    return (1, 0.0, name.lower())


def _extract_episode_number(ep_name):
    num_match = re.search(r'\d+', str(ep_name or ''))
    if num_match:
        try:
            return int(num_match.group(0))
        except ValueError:
            return None
    return None


def _build_detail_info_text(meta):
    lines = [
        f"Tên: {meta.get('name', '')}",
    ]
    if meta.get('original_name'):
        lines.append(f"Tên gốc: {meta['original_name']}")
    if meta.get('year'):
        lines.append(f"Năm: {meta['year']}")
    if meta.get('quality') or meta.get('language'):
        lines.append(f"Chất lượng: {meta.get('quality', '')} | Ngôn ngữ: {meta.get('language', '')}".strip(' |'))
    if meta.get('episode_badge'):
        lines.append(f"Trạng thái: {meta['episode_badge']}")
    if meta.get('genres'):
        lines.append(f"Thể loại: {', '.join(meta['genres'])}")
    if meta.get('countries'):
        lines.append(f"Quốc gia: {', '.join(meta['countries'])}")
    if meta.get('directors'):
        lines.append(f"Đạo diễn: {', '.join(meta['directors'])}")
    if meta.get('casts'):
        lines.append(f"Diễn viên: {', '.join(meta['casts'])}")
    if meta.get('plot'):
        lines.append('')
        lines.append(meta['plot'])
    return '\n'.join(lines)


def _collect_group_episodes(episodes, group_type):
    collected = []
    for server in episodes:
        srv_name = str(server.get('server_name') or '')
        if group_type != 'all' and _classify_server_group(srv_name) != group_type:
            continue
        items_list = server.get('server_data') or server.get('items') or []
        for item in items_list:
            play_link = (
                item.get('embed')
                or item.get('link_embed')
                or item.get('link_m3u8')
                or item.get('m3u8_link')
                or item.get('m3u8')
                or ''
            )
            if not play_link:
                continue
            collected.append({
                'server_name': srv_name,
                'name': str(item.get('name', '')),
                'play_link': play_link,
            })
    collected.sort(key=_episode_sort_key)
    return collected


def _render_episode_items(episode_items, meta, film_slug):
    fav_ctx = _favorite_context_item(meta)
    ctx = [fav_ctx] if fav_ctx else None
    for item in episode_items:
        ep_label = format_episode_title(item['name'], item['server_name'])
        ep_num = _extract_episode_number(item['name'])
        add_link(
            ep_label,
            build_url({
                'mode': 'play',
                'url': item['play_link'],
                'title': f"{meta['name']} - {ep_label}",
                'thumb': meta['poster'],
                'fanart': meta['fanart'],
                'slug': film_slug,
                'ep_label': ep_label,
                'movie_name': meta['name'],
            }),
            meta=meta,
            mediatype='episode',
            episode_number=ep_num,
            context_menu=ctx,
        )


def movie_detail(film_slug):
    handle = get_handle()
    log('DETAIL slug=' + film_slug)

    data = fetch_movie_detail(film_slug, ttl_seconds=get_cache_ttl_seconds())
    if not data:
        xbmcplugin.setContent(handle, 'videos')
        add_dir('Lỗi: Không lấy được dữ liệu', build_url({'mode': 'noop'}))
        xbmcplugin.endOfDirectory(handle)
        return

    movie = data.get('movie') or data.get('item') or {}
    episodes = movie.get('episodes') or data.get('episodes') or []
    meta = extract_movie_metadata(movie)
    if not meta.get('slug'):
        meta['slug'] = film_slug
    info_text = _build_detail_info_text(meta)

    if not episodes:
        xbmcplugin.setContent(handle, 'videos')
        add_dir('Không có tập phim nào', build_url({'mode': 'noop'}), meta=meta, plot=info_text)
        xbmcplugin.endOfDirectory(handle)
        return

    grouped = {'sub': [], 'dub': [], 'voice': [], 'other': []}
    for server in episodes:
        gtype = _classify_server_group(server.get('server_name', ''))
        grouped[gtype].append(server)

    group_specs = [
        ('sub', 'Phụ đề (Vietsub)'),
        ('dub', 'Thuyết minh'),
        ('voice', 'Lồng tiếng'),
        ('other', 'Khác'),
    ]

    active_groups = []
    total_links = 0
    for gtype, label in group_specs:
        servers = grouped[gtype]
        if servers:
            ep_list = _collect_group_episodes(servers, 'all')
            if ep_list:
                active_groups.append((gtype, label, ep_list))
                total_links += len(ep_list)

    if not active_groups:
        xbmcplugin.setContent(handle, 'videos')
        add_dir('Không có tập phim khả dụng', build_url({'mode': 'noop'}), meta=meta, plot=info_text)
        xbmcplugin.endOfDirectory(handle)
        return

    if get_auto_expand_single_group() and (len(active_groups) == 1 or total_links <= 4):
        xbmcplugin.setContent(handle, 'episodes')
        all_eps = []
        for _, _, ep_list in active_groups:
            all_eps.extend(ep_list)
        all_eps.sort(key=_episode_sort_key)
        ep_meta = dict(meta)
        ep_meta['plot'] = info_text
        _render_episode_items(all_eps, ep_meta, film_slug)
        xbmcplugin.endOfDirectory(handle)
        return

    xbmcplugin.setContent(handle, 'videos')
    fav_ctx = _favorite_context_item(meta)
    ctx = [fav_ctx] if fav_ctx else None
    dir_meta = dict(meta)
    dir_meta['plot'] = info_text

    for gtype, label, ep_list in active_groups:
        add_dir(
            f'📁 {label} ({len(ep_list)} tập)',
            build_url({
                'mode': 'group',
                'slug': film_slug,
                'gtype': gtype,
                'title': meta['name'],
                'thumb': meta['poster'],
                'fanart': meta['fanart'],
            }),
            meta=dir_meta,
            mediatype='tvshow' if meta.get('is_series') else 'movie',
            context_menu=ctx,
        )

    xbmcplugin.endOfDirectory(handle)


def server_group(film_slug, group_type, title, thumb, fanart=''):
    handle = get_handle()
    xbmcplugin.setContent(handle, 'episodes')

    data = fetch_movie_detail(film_slug, ttl_seconds=get_cache_ttl_seconds())
    if not data:
        add_dir('Lỗi tải dữ liệu', build_url({'mode': 'noop'}), thumb=thumb, fanart=fanart)
        xbmcplugin.endOfDirectory(handle)
        return

    movie = data.get('movie') or data.get('item') or {}
    episodes = movie.get('episodes') or data.get('episodes') or []
    meta = extract_movie_metadata(movie)
    if not meta.get('slug'):
        meta['slug'] = film_slug
    if title and meta.get('name') == 'Không tên':
        meta['name'] = title
    if thumb and not meta.get('poster'):
        meta['poster'] = thumb
    if fanart and not meta.get('fanart'):
        meta['fanart'] = fanart

    all_items = _collect_group_episodes(episodes, group_type)
    _render_episode_items(all_items, meta, film_slug)
    xbmcplugin.endOfDirectory(handle)


# ============================================================
# SEARCH, FAVORITES & HISTORY
# ============================================================
def menu_search():
    handle = get_handle()
    xbmcplugin.setContent(handle, 'videos')
    icon, fanart = _get_addon_art()

    add_dir(
        '🔍 Nhập từ khóa tìm kiếm mới...',
        build_url({'mode': 'search'}),
        thumb=icon,
        fanart=fanart,
    )

    keywords = get_search_history()
    for kw in keywords:
        ctx = [
            ('Xóa từ khóa này', f'RunPlugin({build_url({"mode": "search_remove", "keyword": kw})})'),
            ('Xóa toàn bộ lịch sử tìm kiếm', f'RunPlugin({build_url({"mode": "search_clear"})})'),
        ]
        add_dir(
            f'🕒 {kw}',
            build_url({'mode': 'list', 'type': 'search', 'slug': kw, 'page': 1}),
            thumb=icon,
            fanart=fanart,
            context_menu=ctx,
        )

    if keywords:
        add_dir(
            '🗑️ Xóa toàn bộ lịch sử tìm kiếm',
            build_url({'mode': 'search_clear'}),
            thumb=icon,
            fanart=fanart,
            is_folder=False,
        )

    xbmcplugin.endOfDirectory(handle)


def search_dialog():
    keyword = xbmcgui.Dialog().input('Tìm kiếm phim', type=xbmcgui.INPUT_ALPHANUM)
    if keyword and keyword.strip():
        cleaned = keyword.strip()
        add_search_keyword(cleaned)
        list_movies('search', cleaned, 1)
    else:
        xbmcplugin.endOfDirectory(get_handle(), succeeded=False)


def menu_favorites():
    handle = get_handle()
    xbmcplugin.setContent(handle, 'movies')
    items = get_favorites()
    if not items:
        icon, fanart = _get_addon_art()
        add_dir('Chưa có phim yêu thích nào', build_url({'mode': 'noop'}), thumb=icon, fanart=fanart)
        xbmcplugin.endOfDirectory(handle)
        return

    _render_movie_entries(items)
    xbmcplugin.endOfDirectory(handle)


def menu_history():
    handle = get_handle()
    xbmcplugin.setContent(handle, 'movies')
    items = get_watch_history()
    if not items:
        icon, fanart = _get_addon_art()
        add_dir('Chưa có lịch sử xem nào', build_url({'mode': 'noop'}), thumb=icon, fanart=fanart)
        xbmcplugin.endOfDirectory(handle)
        return

    def _history_label(raw_item, meta):
        last_ep = str(raw_item.get('last_episode') or '').strip()
        if last_ep:
            return f"{meta['name']} [Đang xem: {last_ep}]"
        return _format_movie_list_label(meta)

    def _history_ctx(raw_item, meta):
        slug = meta.get('slug') or ''
        actions = []
        if slug:
            actions.append(('Xóa khỏi lịch sử', f'RunPlugin({build_url({"mode": "history_remove", "slug": slug})})'))
        actions.append(('Xóa toàn bộ lịch sử', f'RunPlugin({build_url({"mode": "history_clear"})})'))
        return actions

    _render_movie_entries(items, extra_context_fn=_history_ctx, label_fn=_history_label)

    icon, fanart = _get_addon_art()
    add_dir(
        '🗑️ Xóa toàn bộ lịch sử xem',
        build_url({'mode': 'history_clear'}),
        thumb=icon,
        fanart=fanart,
        is_folder=False,
    )
    xbmcplugin.endOfDirectory(handle)


# ============================================================
# PLAYBACK
# ============================================================
def _monitor_proxy_playback(proxy_server, resolved_path):
    monitor = xbmc.Monitor()
    player = xbmc.Player()
    playback_started = False
    pre_play_idle_ticks = 0
    post_play_idle_ticks = 0

    while not monitor.abortRequested():
        if player.isPlayingVideo():
            playback_started = True
            post_play_idle_ticks = 0
            try:
                playing_file = player.getPlayingFile()
            except Exception:
                playing_file = ''
            if playing_file and playing_file.startswith('http://127.0.0.1:') and playing_file != resolved_path:
                break
        else:
            if playback_started:
                post_play_idle_ticks += 1
                if post_play_idle_ticks >= 5:
                    break
            else:
                pre_play_idle_ticks += 1
                if pre_play_idle_ticks >= 30:
                    break
        if monitor.waitForAbort(1):
            break


def play_video(play_url, title, thumb='', fanart='', film_slug='', ep_label='', movie_name=''):
    handle = get_handle()
    if not play_url:
        xbmcgui.Dialog().notification('Lỗi', 'Không có link phát', xbmcgui.NOTIFICATION_ERROR, 3000)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    proxy_server = None
    try:
        resolved_path, proxy_server = resolve_kodi_stream(play_url)
        log('Da resolve stream de phat trong Kodi: ' + resolved_path)

        if film_slug:
            record_watch_history(
                {
                    'slug': film_slug,
                    'name': movie_name or title,
                    'thumb_url': thumb,
                    'poster_url': fanart,
                },
                episode_label=ep_label or title,
            )

        item = xbmcgui.ListItem(path=resolved_path)
        apply_video_info(
            item,
            {'name': title, 'poster': thumb, 'fanart': fanart or thumb},
            mediatype='episode',
            title_override=title,
        )
        item.setProperty('IsPlayable', 'true')
        if proxy_server is None and '.mp4' in resolved_path.lower():
            item.setMimeType('video/mp4')
        else:
            item.setMimeType('application/x-mpegURL')
        item.setContentLookup(False)

        xbmcplugin.setResolvedUrl(handle, True, item)

        if proxy_server is not None:
            _monitor_proxy_playback(proxy_server, resolved_path)
    except Exception as exc:
        log('Loi khi resolve stream trong Kodi: ' + str(exc), xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Lỗi', 'Không thể phát video trong Kodi', xbmcgui.NOTIFICATION_ERROR, 3000)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
    finally:
        if proxy_server is not None:
            proxy_server.stop()


# ============================================================
# ACTION HANDLERS (CONTEXT MENU & MAINTENANCE)
# ============================================================
def _handle_fav_add(params):
    slug = params.get('slug', '')
    raw_movie = params.get('movie', '')
    movie_summary = None
    if raw_movie:
        try:
            movie_summary = json.loads(raw_movie)
        except Exception:
            movie_summary = None

    if not movie_summary and slug:
        detail = fetch_movie_detail(slug, ttl_seconds=get_cache_ttl_seconds())
        if detail:
            movie_summary = detail.get('movie') or detail.get('item') or {'slug': slug}

    if add_favorite(movie_summary or {'slug': slug}):
        xbmcgui.Dialog().notification('Yêu thích', 'Đã thêm vào Phim yêu thích', xbmcgui.NOTIFICATION_INFO, 2500)
        xbmc.executebuiltin('Container.Refresh')


def _handle_fav_remove(params):
    if remove_favorite(params.get('slug', '')):
        xbmcgui.Dialog().notification('Yêu thích', 'Đã xóa khỏi Phim yêu thích', xbmcgui.NOTIFICATION_INFO, 2500)
        xbmc.executebuiltin('Container.Refresh')


def _handle_history_remove(params):
    if remove_history_item(params.get('slug', '')):
        xbmcgui.Dialog().notification('Lịch sử', 'Đã xóa khỏi lịch sử xem', xbmcgui.NOTIFICATION_INFO, 2500)
        xbmc.executebuiltin('Container.Refresh')


def _handle_history_clear():
    clear_watch_history()
    xbmcgui.Dialog().notification('Lịch sử', 'Đã xóa toàn bộ lịch sử xem', xbmcgui.NOTIFICATION_INFO, 2500)
    xbmc.executebuiltin('Container.Refresh')


def _handle_search_remove(params):
    if remove_search_keyword(params.get('keyword', '')):
        xbmc.executebuiltin('Container.Refresh')


def _handle_search_clear():
    clear_search_history()
    xbmcgui.Dialog().notification('Tìm kiếm', 'Đã xóa lịch sử tìm kiếm', xbmcgui.NOTIFICATION_INFO, 2500)
    xbmc.executebuiltin('Container.Refresh')


def _handle_clear_cache():
    removed = cache_clear()
    xbmcgui.Dialog().notification('Bộ nhớ đệm', f'Đã xóa {removed} mục cache', xbmcgui.NOTIFICATION_INFO, 2500)


# ============================================================
# ROUTER
# ============================================================
def router():
    raw_query = sys.argv[2].lstrip('?') if len(sys.argv) > 2 else ''
    params = dict(urllib.parse.parse_qsl(raw_query))
    mode = params.get('mode', 'main')

    try:
        if mode == 'main':
            menu_main()
        elif mode == 'catalog':
            menu_catalog(params.get('kind', 'the-loai'))
        elif mode == 'list':
            list_movies(
                params.get('type', 'phim-moi-cap-nhat'),
                params.get('slug', ''),
                int(params.get('page', 1)),
            )
        elif mode == 'detail':
            movie_detail(params.get('slug', ''))
        elif mode == 'group':
            server_group(
                params.get('slug', ''),
                params.get('gtype', ''),
                params.get('title', ''),
                params.get('thumb', ''),
                params.get('fanart', ''),
            )
        elif mode == 'play':
            play_video(
                params.get('url', ''),
                params.get('title', ''),
                params.get('thumb', ''),
                params.get('fanart', ''),
                params.get('slug', ''),
                params.get('ep_label', ''),
                params.get('movie_name', ''),
            )
        elif mode == 'search_menu':
            menu_search()
        elif mode == 'search':
            search_dialog()
        elif mode == 'favorites':
            menu_favorites()
        elif mode == 'history':
            menu_history()
        elif mode == 'fav_add':
            _handle_fav_add(params)
        elif mode == 'fav_remove':
            _handle_fav_remove(params)
        elif mode == 'history_remove':
            _handle_history_remove(params)
        elif mode == 'history_clear':
            _handle_history_clear()
        elif mode == 'search_remove':
            _handle_search_remove(params)
        elif mode == 'search_clear':
            _handle_search_clear()
        elif mode == 'clear_cache':
            _handle_clear_cache()
        elif mode == 'noop':
            xbmcplugin.endOfDirectory(get_handle())
        else:
            menu_main()
    except Exception as exc:
        log('ROUTER ERROR: ' + str(exc), xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Lỗi Addon', str(exc), xbmcgui.NOTIFICATION_ERROR, 5000)
        try:
            xbmcplugin.endOfDirectory(get_handle(), succeeded=False)
        except Exception:
            pass
    finally:
        close_http_client()


if __name__ == '__main__':
    router()
