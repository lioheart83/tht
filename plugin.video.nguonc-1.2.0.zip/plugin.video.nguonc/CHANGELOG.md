# Changelog

## 1.2.0 - 2026-11-21

- **Sửa lỗi menu & phân trang API**:
  - Gỡ bỏ 2 mục `Phim đang chiếu` / `Phim sắp chiếu` bị lỗi HTTP 404 trên API Nguonc (giữ alias tương thích ngược về `Phim mới cập nhật`).
  - Sửa lỗi phân trang Tìm kiếm (bổ sung `&page={page}`), hỗ trợ duyệt trang 2, 3... đầy đủ.
  - Sửa cấu trúc `Hoạt hình` sang `/api/films/the-loai/hoat-hinh` và bổ sung danh mục **Phim Thuyết minh** / **Phim Lồng tiếng** (`/api/films/ngon-ngu/{slug}`).
  - Bổ sung đầy đủ menu **Thể loại** (22 mục), **Quốc gia** (20 mục), **Năm phát hành** với khả năng tự động cập nhật danh mục mới từ trang chủ (cache 24 giờ).
- **Sửa lỗi & nâng cấp cài đặt**:
  - Di chuyển `settings.xml` về đúng chuẩn Kodi `resources/settings.xml`.
  - Kích hoạt cài đặt số lượng phim mỗi trang (`10`/`20`/`30`), tự động mở thẳng danh sách tập khi chỉ có 1 nhóm server (hoặc <= 4 tập), thời gian lưu bộ nhớ đệm API (`0`/`5`/`10`/`30` phút), và tùy chọn ẩn/hiện mục `Phim 18+`.
- **Tối ưu giải mã & Proxy phát video**:
  - Tối ưu `nguonc_crypto.py` bằng 32-bit T-tables (nhanh hơn ~5x thuần Python) và tự động dùng C-extension (`pycryptodome`/`cryptography`) nếu có sẵn trên hệ thống.
  - Nâng cấp `NguoncProxyServer`: hỗ trợ `HEAD` và `GET`, bật `follow_redirects=True`, ép `Content-Type: video/mp2t` cho segment (khắc phục CDN trả `image/png`), hỗ trợ sub-playlist `/sub/<id>.m3u8`, `#EXT-X-MAP`/`#EXT-X-KEY`, URL tương đối và link `.mp4`/`.m3u8` trực tiếp, xử lý êm lỗi ngắt kết nối khi tua phim.
  - Sửa vòng lặp theo dõi `xbmc.Player()` để đóng proxy cũ ngay khi chuyển tập khác và chống ngắt nhầm khi buffer/tua.
- **Tính năng & giao diện mới**:
  - Tách cấu trúc modular (`nguonc_api.py`, `nguonc_storage.py`, `nguonc_stream.py`, `nguonc_crypto.py`).
  - Thêm **Phim yêu thích**, **Lịch sử đã xem**, **Lịch sử tìm kiếm**, và **Xóa bộ nhớ đệm (Cache)**.
  - Tách riêng nhóm server `Phụ đề (Vietsub)`, `Thuyết minh`, `Lồng tiếng`, `Khác`; sửa hiển thị badge và tên tập; dùng `poster_url` HD làm `fanart`/`landscape` và hỗ trợ `InfoTagVideo` chuẩn Kodi 20+ (fallback sạch cho Kodi 19).
  - Loại bỏ phụ thuộc `script.module.requests` bằng `httpx` bundle sẵn có hỗ trợ retry và connection pooling.

## 1.1.4 - 2026-09-12

- Sua loi khong play duoc: streamc.xyz doi sang player moi (POST bootstrap tra grant ma hoa AES-GCM + playlist ky san) va them WAF Cloudflare chan moi client HTTP/1.1 theo TLS fingerprint.
- Goi truc tiep bootstrap API bang HTTP/2 (bundle httpx + h2 pure-python vao resources/lib), giai ma grant de lay playlist, roi tai va giai ma manifest nhu cu (key derivation khong doi).
- Chuyen proxy segment sang httpx (ho tro ca HTTP/2 va HTTP/1.1, tu dong theo ALPN).
- Giu flow cu (data-obf) lam du phong khi bootstrap that bai.

## 1.1.2

- Sua loi sap xep tap phim: tuple key an toan, khong con nem `TypeError` khi mot phim vua co ten tap dang so vua co ten tap dang chu tren Python 3.
- Dong bo phien ban addon.xml (1.1.2) de khop lich su CHANGELOG.

## 1.1.1 - 2026-07-04

- Sua menu `Phim dang chieu` theo slug moi `dang-chieu` cua API Nguonc.
- Them alias tuong thich nguoc cho slug cu `phim-dang-chieu` va `phim-sap-chieu`.
- Chinh menu `Phim sap chieu` sang slug moi `sap-chieu`.

## 1.1.0 - 2026-07-03

- Chuyen sang phat truc tiep trong Kodi bang localhost proxy cho nguon `streamc.xyz`
- Tu giai ma manifest ma hoa va phuc vu lai duoi dang `m3u8/ts` chuan
- Don dep helper cu khong con su dung sau khi chot huong proxy playback
- Cap nhat README de mo ta dung luong phat va yeu cau localhost

## 1.0.1 - 2026-07-03

- Bo browser ngoai va thu resolve play truc tiep trong Kodi
- Them helper giai ma manifest dau tien cho nguon Nguonc

## 1.0.0

- Phien ban khoi dau
