# -*- coding: utf-8 -*-
"""Motchille Kodi video addon entrypoint."""

import os
import re
import sys
import urllib.parse

_LIB_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'resources', 'lib')
if _LIB_DIR not in sys.path:
    sys.path.insert(0, _LIB_DIR)

import xbmc
import xbmcgui
import xbmcplugin

from resources.lib.motchille import search_history
from resources.lib.motchille.config import COUNTRIES, GENRES, YEARS, get_addon, get_settings, log
from resources.lib.motchille.http_client import fetch_site_soup
from resources.lib.motchille.proxy import publish_stream_to_proxy
from resources.lib.motchille.resolvers import fetch_watch_candidates, resolve_with_failover
from resources.lib.motchille.scraper import (
    build_page_url,
    build_search_path,
    enrich_movie_cards,
    group_episodes_by_server,
    has_next_page,
    load_movie_detail,
    parse_movie_cards,
)


def _new_context():
    return {
        'base_url': sys.argv[0],
        'handle': int(sys.argv[1]) if len(sys.argv) > 1 else -1,
        'items': [],
    }


def build_url(ctx, query):
    return ctx['base_url'] + '?' + urllib.parse.urlencode(query)


def apply_video_info(item, info):
    """Apply video metadata using Kodi 20+ InfoTagVideo with Kodi 19 fallback."""
    title = info.get('title') or ''
    original = info.get('original_name') or ''
    plot = info.get('plot') or ''
    year = int(info.get('year') or 0)
    duration = int(info.get('duration') or 0)
    genres = info.get('genres') or []
    countries = info.get('countries') or []
    directors = info.get('directors') or []
    cast = info.get('cast') or []
    media_type = info.get('mediatype') or ''
    episode_num = int(info.get('episode') or 0)

    get_tag = getattr(item, 'getVideoInfoTag', None)
    if callable(get_tag):
        try:
            tag = get_tag()
            if title:
                tag.setTitle(title)
            if original:
                tag.setOriginalTitle(original)
            if plot:
                tag.setPlot(plot)
            if year > 0:
                tag.setYear(year)
            if duration > 0:
                tag.setDuration(duration)
            if genres:
                tag.setGenres(list(genres))
            if countries:
                tag.setCountries(list(countries))
            if directors:
                tag.setDirectors(list(directors))
            if cast and hasattr(xbmc, 'Actor'):
                tag.setCast([xbmc.Actor(name) for name in cast[:15]])
            if media_type:
                tag.setMediaType(media_type)
            if episode_num > 0:
                tag.setEpisode(episode_num)
            return
        except Exception:
            pass

    legacy = {'title': title, 'plot': plot}
    if original:
        legacy['originaltitle'] = original
    if year > 0:
        legacy['year'] = year
    if duration > 0:
        legacy['duration'] = duration
    if genres:
        legacy['genre'] = ', '.join(genres)
    if countries:
        legacy['country'] = ', '.join(countries)
    if directors:
        legacy['director'] = ', '.join(directors)
    if cast:
        legacy['cast'] = list(cast[:15])
    if media_type:
        legacy['mediatype'] = media_type
    if episode_num > 0:
        legacy['episode'] = episode_num
    item.setInfo('video', legacy)


def _create_list_item(title, thumb='', fanart='', info=None, is_playable=False, context_menu=None):
    item = xbmcgui.ListItem(label=title, offscreen=True)
    art_thumb = thumb or ''
    art_fanart = fanart or art_thumb
    if art_thumb or art_fanart:
        item.setArt({'thumb': art_thumb, 'icon': art_thumb, 'poster': art_thumb, 'fanart': art_fanart})
    payload = dict(info or {})
    payload.setdefault('title', title)
    apply_video_info(item, payload)
    if is_playable:
        item.setProperty('IsPlayable', 'true')
    if context_menu:
        item.addContextMenuItems(context_menu)
    return item


def add_dir(ctx, title, url, thumb='', fanart='', info=None, context_menu=None):
    item = _create_list_item(title, thumb=thumb, fanart=fanart, info=info, is_playable=False, context_menu=context_menu)
    ctx['items'].append((url, item, True))


def add_action(ctx, title, url, thumb='', plot=''):
    item = _create_list_item(title, thumb=thumb, info={'title': title, 'plot': plot}, is_playable=False)
    ctx['items'].append((url, item, False))


def add_link(ctx, title, url, thumb='', fanart='', info=None, context_menu=None):
    item = _create_list_item(title, thumb=thumb, fanart=fanart, info=info, is_playable=True, context_menu=context_menu)
    ctx['items'].append((url, item, False))


def flush_directory(ctx, succeeded=True):
    handle = ctx['handle']
    if handle < 0:
        return
    if ctx['items']:
        xbmcplugin.addDirectoryItems(handle, ctx['items'], len(ctx['items']))
        ctx['items'].clear()
    xbmcplugin.endOfDirectory(handle, succeeded=succeeded)


def _busy(message):
    try:
        progress = xbmcgui.DialogProgressBG()
        progress.create('Motchille', message)
        return progress
    except Exception:
        return None


def _busy_close(progress):
    if progress is None:
        return
    try:
        progress.close()
    except Exception:
        pass


def menu_main(ctx):
    xbmcplugin.setContent(ctx['handle'], 'videos')
    add_dir(ctx, 'Mới cập nhật', build_url(ctx, {'mode': 'list', 'path': '/phim', 'title': 'Mới cập nhật', 'page': 1}))
    add_dir(ctx, 'Phim lẻ', build_url(ctx, {'mode': 'list', 'path': '/danh-sach/phim-le', 'title': 'Phim lẻ', 'page': 1}))
    add_dir(ctx, 'Phim bộ', build_url(ctx, {'mode': 'list', 'path': '/danh-sach/phim-bo', 'title': 'Phim bộ', 'page': 1}))
    add_dir(ctx, 'Phim chiếu rạp', build_url(ctx, {'mode': 'list', 'path': '/danh-sach/phim-chieu-rap', 'title': 'Phim chiếu rạp', 'page': 1}))
    add_dir(ctx, 'Phim thuyết minh', build_url(ctx, {'mode': 'list', 'path': '/danh-sach/phim-thuyet-minh', 'title': 'Phim thuyết minh', 'page': 1}))
    add_dir(ctx, 'Phim hoạt hình', build_url(ctx, {'mode': 'list', 'path': '/danh-sach/hoat-hinh', 'title': 'Phim hoạt hình', 'page': 1}))
    add_dir(ctx, 'TV Shows', build_url(ctx, {'mode': 'list', 'path': '/danh-sach/tv-shows', 'title': 'TV Shows', 'page': 1}))
    add_dir(ctx, 'Thể loại', build_url(ctx, {'mode': 'genres'}))
    add_dir(ctx, 'Quốc gia', build_url(ctx, {'mode': 'countries'}))
    add_dir(ctx, 'Năm phát hành', build_url(ctx, {'mode': 'years'}))
    add_dir(ctx, 'Tìm kiếm', build_url(ctx, {'mode': 'search_menu'}))
    add_action(ctx, 'Cài đặt Addon', build_url(ctx, {'mode': 'settings'}))
    flush_directory(ctx)


def show_static_menu(ctx, title, entries, path_prefix):
    xbmcplugin.setContent(ctx['handle'], 'videos')
    xbmcplugin.setPluginCategory(ctx['handle'], title)
    for label, slug in entries:
        add_dir(ctx, label, build_url(ctx, {'mode': 'list', 'path': path_prefix % slug, 'title': label, 'page': 1}))
    flush_directory(ctx)


def _render_movie_cards(ctx, movies):
    for movie in movies:
        has_rich_meta = bool(movie.get('year') or movie.get('genres') or movie.get('countries') or movie.get('status'))
        plot = _format_movie_plot(movie) if has_rich_meta else movie.get('plot', '')
        add_dir(
            ctx,
            movie['label'],
            build_url(ctx, {'mode': 'detail', 'slug': movie['slug']}),
            thumb=movie['thumb'],
            fanart=movie.get('fanart') or movie['thumb'],
            info={
                'title': movie['title'],
                'original_name': movie.get('original_name', ''),
                'plot': plot,
                'year': movie.get('year', 0),
                'duration': movie.get('duration', 0),
                'genres': movie.get('genres', []),
                'countries': movie.get('countries', []),
                'directors': movie.get('directors', []),
                'cast': movie.get('cast', []),
                'mediatype': 'movie',
            },
        )


def list_movies(ctx, path, title, page):
    xbmcplugin.setContent(ctx['handle'], 'movies')
    xbmcplugin.setPluginCategory(ctx['handle'], '%s - Trang %d' % (title, page))

    target_path = build_page_url(path, page)
    try:
        soup, _, _, active_base = fetch_site_soup(target_path)
        movies = parse_movie_cards(soup, active_base)
        enrich_movie_cards(movies, active_base, get_settings())
    except Exception as exc:
        log('Lỗi load danh sách: %s' % exc, xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Motchille', 'Không tải được danh sách phim', xbmcgui.NOTIFICATION_ERROR, 3000)
        flush_directory(ctx, succeeded=False)
        return

    _render_movie_cards(ctx, movies)

    next_page = page + 1
    if movies and has_next_page(soup, path, next_page):
        add_dir(
            ctx,
            '>>> Trang %d' % next_page,
            build_url(ctx, {'mode': 'list', 'path': path, 'title': title, 'page': next_page}),
        )

    flush_directory(ctx)


def search_menu(ctx):
    xbmcplugin.setContent(ctx['handle'], 'videos')
    xbmcplugin.setPluginCategory(ctx['handle'], 'Tìm kiếm')
    add_dir(ctx, '[Tìm kiếm mới...]', build_url(ctx, {'mode': 'search'}))

    history = search_history.load_history()
    for keyword in history:
        cm = [
            ('Xóa từ khóa này', 'RunPlugin(%s)' % build_url(ctx, {'mode': 'remove_history', 'keyword': keyword})),
            ('Xóa toàn bộ lịch sử', 'RunPlugin(%s)' % build_url(ctx, {'mode': 'clear_history'})),
        ]
        add_dir(
            ctx,
            keyword,
            build_url(ctx, {'mode': 'search_results', 'keyword': keyword, 'page': 1}),
            context_menu=cm,
        )

    if history:
        add_action(ctx, '[Xóa lịch sử tìm kiếm]', build_url(ctx, {'mode': 'clear_history'}))

    flush_directory(ctx)


def search_dialog(ctx):
    keyword = xbmcgui.Dialog().input('Tìm kiếm phim trên Motchille', type=xbmcgui.INPUT_ALPHANUM)
    keyword = (keyword or '').strip()
    if keyword:
        search_history.add_query(keyword)
        search_movies(ctx, keyword, 1)
    else:
        flush_directory(ctx, succeeded=False)


def search_movies(ctx, keyword, page):
    xbmcplugin.setContent(ctx['handle'], 'movies')
    xbmcplugin.setPluginCategory(ctx['handle'], 'Tìm kiếm: %s' % keyword)

    if page == 1 and keyword:
        search_history.add_query(keyword)

    search_path = build_search_path(keyword, page)
    try:
        soup, _, _, active_base = fetch_site_soup(search_path)
        movies = parse_movie_cards(soup, active_base)
        enrich_movie_cards(movies, active_base, get_settings())
    except Exception as exc:
        log('Lỗi tìm kiếm: %s' % exc, xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Motchille', 'Không tìm kiếm được', xbmcgui.NOTIFICATION_ERROR, 3000)
        flush_directory(ctx, succeeded=False)
        return

    _render_movie_cards(ctx, movies)

    next_page = page + 1
    if movies and has_next_page(soup, '', next_page, is_search=True):
        add_dir(
            ctx,
            '>>> Trang %d' % next_page,
            build_url(ctx, {'mode': 'search_results', 'keyword': keyword, 'page': next_page}),
        )

    flush_directory(ctx)


def _format_movie_plot(movie):
    parts = []
    meta = []
    if movie.get('status'):
        meta.append(movie['status'])
    if movie.get('year'):
        meta.append('Năm %d' % movie['year'])
    if movie.get('countries'):
        meta.append(', '.join(movie['countries']))
    if movie.get('genres'):
        meta.append(', '.join(movie['genres']))
    if meta:
        parts.append(' | '.join(meta))
    if movie.get('plot'):
        parts.append(movie['plot'])
    if movie.get('original_name'):
        parts.append('Tên gốc: %s' % movie['original_name'])
    return '\n\n'.join(parts)


def movie_detail(ctx, slug):
    xbmcplugin.setContent(ctx['handle'], 'videos')
    try:
        movie = load_movie_detail(slug)
    except Exception as exc:
        log('Lỗi load detail: %s' % exc, xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Motchille', 'Không tải được thông tin phim', xbmcgui.NOTIFICATION_ERROR, 3000)
        flush_directory(ctx, succeeded=False)
        return

    grouped = group_episodes_by_server(movie['episodes'])
    if not grouped:
        xbmcgui.Dialog().notification('Motchille', 'Không tìm thấy tập hoặc nguồn phát', xbmcgui.NOTIFICATION_ERROR, 3000)
        flush_directory(ctx, succeeded=False)
        return

    if len(grouped) == 1:
        server_name, _ = grouped[0]
        episode_list(ctx, slug, server_name, movie=movie)
        return

    xbmcplugin.setPluginCategory(ctx['handle'], movie['title'])
    full_plot = _format_movie_plot(movie)
    base_info = {
        'title': movie['title'],
        'original_name': movie.get('original_name', ''),
        'plot': full_plot,
        'year': movie.get('year', 0),
        'duration': movie.get('duration', 0),
        'genres': movie.get('genres', []),
        'countries': movie.get('countries', []),
        'directors': movie.get('directors', []),
        'cast': movie.get('cast', []),
        'mediatype': 'movie',
    }

    for server_name, items in grouped:
        server_info = dict(base_info)
        server_info['title'] = '%s (%d tập)' % (server_name, len(items))
        add_dir(
            ctx,
            server_info['title'],
            build_url(ctx, {'mode': 'episodes', 'slug': slug, 'server': server_name}),
            thumb=movie['thumb'],
            fanart=movie['fanart'],
            info=server_info,
        )

    flush_directory(ctx)


def episode_list(ctx, slug, server_name, movie=None):
    xbmcplugin.setContent(ctx['handle'], 'episodes')
    if movie is None:
        try:
            movie = load_movie_detail(slug)
        except Exception as exc:
            log('Lỗi load episodes: %s' % exc, xbmc.LOGERROR)
            xbmcgui.Dialog().notification('Motchille', 'Không tải được danh sách tập', xbmcgui.NOTIFICATION_ERROR, 3000)
            flush_directory(ctx, succeeded=False)
            return

    grouped = dict(group_episodes_by_server(movie['episodes']))
    items = grouped.get(server_name, [])
    if not items and grouped:
        items = next(iter(grouped.values()))
    if not items:
        xbmcgui.Dialog().notification('Motchille', 'Server này không còn nguồn phát', xbmcgui.NOTIFICATION_ERROR, 3000)
        flush_directory(ctx, succeeded=False)
        return

    xbmcplugin.setPluginCategory(ctx['handle'], '%s - %s' % (movie['title'], server_name))
    full_plot = _format_movie_plot(movie)

    for item in items:
        episode_name = str(item.get('name') or '?')
        episode_label = episode_name if re.match(r'^tập\s', episode_name, re.IGNORECASE) else 'Tập %s' % episode_name
        ep_num_match = re.search(r'(\d+)', episode_name)
        ep_num = int(ep_num_match.group(1)) if ep_num_match else 0
        play_title = '%s - %s' % (movie['title'], episode_label)

        ep_info = {
            'title': episode_label,
            'original_name': movie.get('original_name', ''),
            'plot': full_plot,
            'year': movie.get('year', 0),
            'duration': movie.get('duration', 0),
            'genres': movie.get('genres', []),
            'countries': movie.get('countries', []),
            'directors': movie.get('directors', []),
            'cast': movie.get('cast', []),
            'mediatype': 'episode',
            'episode': ep_num,
        }

        select_url = build_url(ctx, {
            'mode': 'select_source',
            'url': item.get('link', ''),
            'type': item.get('type', 'watch'),
            'title': play_title,
            'thumb': movie['thumb'],
            'fanart': movie['fanart'],
        })
        play_url = build_url(ctx, {
            'mode': 'play',
            'url': item.get('link', ''),
            'type': item.get('type', 'watch'),
            'title': play_title,
            'thumb': movie['thumb'],
            'fanart': movie['fanart'],
        })
        add_link(
            ctx,
            episode_label,
            play_url,
            thumb=movie['thumb'],
            fanart=movie['fanart'],
            info=ep_info,
            context_menu=[('Chọn nguồn phát...', 'RunPlugin(%s)' % select_url)],
        )

    flush_directory(ctx)


def build_kodi_stream_path(stream_url, headers):
    if not headers:
        return stream_url
    header_string = '&'.join(
        '%s=%s' % (urllib.parse.quote(key), urllib.parse.quote(value))
        for key, value in headers.items()
    )
    return stream_url + '|' + header_string


def _build_playable_listitem(resolved, title, thumb, fanart=''):
    if resolved.get('is_hls') and 'manifest_text' in resolved:
        kodi_path = publish_stream_to_proxy(resolved)
    else:
        kodi_path = build_kodi_stream_path(resolved.get('direct_url', ''), resolved.get('headers'))

    item = _create_list_item(
        title,
        thumb=thumb,
        fanart=fanart or thumb,
        info={'title': title},
        is_playable=True,
    )
    item.setPath(kodi_path)

    subtitles = resolved.get('subtitles') or []
    if subtitles:
        item.setSubtitles(subtitles)

    if resolved.get('is_hls'):
        item.setMimeType('application/vnd.apple.mpegurl')
        item.setContentLookup(False)

    return kodi_path, item


def play_video(ctx, raw_link, title, thumb, fanart='', source_type=''):
    settings = get_settings()
    progress = _busy('Đang chuẩn bị nguồn phát...')
    try:
        resolved = resolve_with_failover(raw_link, source_type=source_type, settings=settings)
        _, item = _build_playable_listitem(resolved, title, thumb, fanart=fanart)
    except Exception as exc:
        log('Không phát được nguồn video: %s' % exc, xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Motchille', 'Không lấy được link phát', xbmcgui.NOTIFICATION_ERROR, 3000)
        if ctx['handle'] >= 0:
            xbmcplugin.setResolvedUrl(ctx['handle'], False, xbmcgui.ListItem())
        return
    finally:
        _busy_close(progress)

    if ctx['handle'] >= 0:
        xbmcplugin.setResolvedUrl(ctx['handle'], True, item)
    else:
        xbmc.Player().play(item.getPath(), item)


def select_source_and_play(raw_link, title, thumb, fanart='', source_type=''):
    settings = get_settings()
    progress = _busy('Đang tải danh sách nguồn phát...')
    try:
        candidates, _ = fetch_watch_candidates(raw_link, source_type=source_type, settings=settings)
    except Exception as exc:
        log('Không lấy được danh sách nguồn phát: %s' % exc, xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Motchille', 'Không tải được nguồn phát', xbmcgui.NOTIFICATION_ERROR, 3000)
        return
    finally:
        _busy_close(progress)

    if not candidates:
        xbmcgui.Dialog().notification('Motchille', 'Không tìm thấy nguồn phát khả dụng', xbmcgui.NOTIFICATION_ERROR, 3000)
        return

    choices = []
    choice_labels = []
    for idx, cand in enumerate(candidates):
        base_label = cand.get('label') or 'Nguồn %d' % (idx + 1)
        if 'vicdn.cc/' in (cand.get('link') or '').lower():
            for audio_key, audio_title in (
                ('original', 'Audio Gốc (Phụ đề Tiếng Việt)'),
                ('female', 'Thuyết Minh Nữ'),
                ('male', 'Thuyết Minh Nam'),
            ):
                choices.append((idx, audio_key))
                choice_labels.append('%s (%s)' % (base_label, audio_title))
        else:
            choices.append((idx, None))
            choice_labels.append(base_label)

    selected = xbmcgui.Dialog().select('Chọn nguồn phát', choice_labels)
    if selected < 0:
        return

    cand_idx, audio_override = choices[selected]
    progress = _busy('Đang chuẩn bị nguồn đã chọn...')
    try:
        resolved = resolve_with_failover(
            raw_link,
            source_type=source_type,
            settings=settings,
            candidate_index=cand_idx,
            audio_override=audio_override,
        )
        kodi_path, item = _build_playable_listitem(resolved, title, thumb, fanart=fanart)
    except Exception as exc:
        log('Lỗi phát nguồn đã chọn: %s' % exc, xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Motchille', 'Nguồn này không phát được', xbmcgui.NOTIFICATION_ERROR, 3000)
        return
    finally:
        _busy_close(progress)

    xbmc.Player().play(kodi_path, item)


def router():
    ctx = _new_context()
    query_str = sys.argv[2].lstrip('?') if len(sys.argv) > 2 else ''
    params = dict(urllib.parse.parse_qsl(query_str))
    mode = params.get('mode', 'main')

    try:
        if mode == 'main':
            menu_main(ctx)
        elif mode == 'genres':
            show_static_menu(ctx, 'Thể loại', GENRES, '/the-loai/%s')
        elif mode == 'countries':
            show_static_menu(ctx, 'Quốc gia', COUNTRIES, '/quoc-gia/%s')
        elif mode == 'years':
            show_static_menu(ctx, 'Năm phát hành', YEARS, '/nam/%s')
        elif mode == 'list':
            list_movies(ctx, params.get('path', '/phim'), params.get('title', 'Danh sách phim'), int(params.get('page', 1)))
        elif mode == 'search_menu':
            search_menu(ctx)
        elif mode == 'search':
            search_dialog(ctx)
        elif mode == 'search_results':
            search_movies(ctx, params.get('keyword', ''), int(params.get('page', 1)))
        elif mode == 'remove_history':
            search_history.remove_query(params.get('keyword', ''))
            if ctx['handle'] >= 0:
                flush_directory(ctx, succeeded=False)
            xbmc.executebuiltin('Container.Refresh')
        elif mode == 'clear_history':
            search_history.clear_history()
            if ctx['handle'] >= 0:
                flush_directory(ctx, succeeded=False)
            xbmc.executebuiltin('Container.Refresh')
        elif mode == 'detail':
            movie_detail(ctx, params.get('slug', ''))
        elif mode == 'episodes':
            episode_list(ctx, params.get('slug', ''), params.get('server', ''))
        elif mode == 'play':
            play_video(
                ctx,
                params.get('url', ''),
                params.get('title', ''),
                params.get('thumb', ''),
                fanart=params.get('fanart', ''),
                source_type=params.get('type', ''),
            )
        elif mode == 'select_source':
            select_source_and_play(
                params.get('url', ''),
                params.get('title', ''),
                params.get('thumb', ''),
                fanart=params.get('fanart', ''),
                source_type=params.get('type', ''),
            )
        elif mode == 'settings':
            get_addon().openSettings()
            if ctx['handle'] >= 0:
                flush_directory(ctx, succeeded=False)
        else:
            menu_main(ctx)
    except Exception as exc:
        log('Router error: %s' % exc, xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Motchille', str(exc), xbmcgui.NOTIFICATION_ERROR, 4000)
        flush_directory(ctx, succeeded=False)


if __name__ == '__main__':
    router()
