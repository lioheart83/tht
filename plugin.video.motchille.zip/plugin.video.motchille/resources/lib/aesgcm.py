# -*- coding: utf-8 -*-
"""Small AES-256-GCM decryptor for Kodi builds without crypto modules."""

import hmac
from functools import lru_cache


SBOX = (
    0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76,
    0xca, 0x82, 0xc9, 0x7d, 0xfa, 0x59, 0x47, 0xf0, 0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4, 0x72, 0xc0,
    0xb7, 0xfd, 0x93, 0x26, 0x36, 0x3f, 0xf7, 0xcc, 0x34, 0xa5, 0xe5, 0xf1, 0x71, 0xd8, 0x31, 0x15,
    0x04, 0xc7, 0x23, 0xc3, 0x18, 0x96, 0x05, 0x9a, 0x07, 0x12, 0x80, 0xe2, 0xeb, 0x27, 0xb2, 0x75,
    0x09, 0x83, 0x2c, 0x1a, 0x1b, 0x6e, 0x5a, 0xa0, 0x52, 0x3b, 0xd6, 0xb3, 0x29, 0xe3, 0x2f, 0x84,
    0x53, 0xd1, 0x00, 0xed, 0x20, 0xfc, 0xb1, 0x5b, 0x6a, 0xcb, 0xbe, 0x39, 0x4a, 0x4c, 0x58, 0xcf,
    0xd0, 0xef, 0xaa, 0xfb, 0x43, 0x4d, 0x33, 0x85, 0x45, 0xf9, 0x02, 0x7f, 0x50, 0x3c, 0x9f, 0xa8,
    0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5, 0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 0xd2,
    0xcd, 0x0c, 0x13, 0xec, 0x5f, 0x97, 0x44, 0x17, 0xc4, 0xa7, 0x7e, 0x3d, 0x64, 0x5d, 0x19, 0x73,
    0x60, 0x81, 0x4f, 0xdc, 0x22, 0x2a, 0x90, 0x88, 0x46, 0xee, 0xb8, 0x14, 0xde, 0x5e, 0x0b, 0xdb,
    0xe0, 0x32, 0x3a, 0x0a, 0x49, 0x06, 0x24, 0x5c, 0xc2, 0xd3, 0xac, 0x62, 0x91, 0x95, 0xe4, 0x79,
    0xe7, 0xc8, 0x37, 0x6d, 0x8d, 0xd5, 0x4e, 0xa9, 0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a, 0xae, 0x08,
    0xba, 0x78, 0x25, 0x2e, 0x1c, 0xa6, 0xb4, 0xc6, 0xe8, 0xdd, 0x74, 0x1f, 0x4b, 0xbd, 0x8b, 0x8a,
    0x70, 0x3e, 0xb5, 0x66, 0x48, 0x03, 0xf6, 0x0e, 0x61, 0x35, 0x57, 0xb9, 0x86, 0xc1, 0x1d, 0x9e,
    0xe1, 0xf8, 0x98, 0x11, 0x69, 0xd9, 0x8e, 0x94, 0x9b, 0x1e, 0x87, 0xe9, 0xce, 0x55, 0x28, 0xdf,
    0x8c, 0xa1, 0x89, 0x0d, 0xbf, 0xe6, 0x42, 0x68, 0x41, 0x99, 0x2d, 0x0f, 0xb0, 0x54, 0xbb, 0x16,
)


def _bytes_to_matrix(value):
    return [list(value[index:index + 4]) for index in range(0, len(value), 4)]


def _matrix_to_bytes(value):
    return bytes(sum(value, []))


def _xtime(value):
    return ((value << 1) ^ 0x11B) & 0xFF if value & 0x80 else value << 1


@lru_cache(maxsize=8)
def _expand_key(key):
    columns = _bytes_to_matrix(key)
    iteration_size = len(key) // 4
    rounds = 14
    rcon = 1
    while len(columns) < (rounds + 1) * 4:
        word = list(columns[-1])
        if len(columns) % iteration_size == 0:
            word.append(word.pop(0))
            word = [SBOX[byte] for byte in word]
            word[0] ^= rcon
            rcon = _xtime(rcon)
        elif iteration_size > 6 and len(columns) % iteration_size == 4:
            word = [SBOX[byte] for byte in word]
        word = [left ^ right for left, right in zip(word, columns[-iteration_size])]
        columns.append(word)
    return [columns[index:index + 4] for index in range(0, len(columns), 4)]


def _add_round_key(state, key):
    for row in range(4):
        for column in range(4):
            state[row][column] ^= key[row][column]


def _sub_bytes(state):
    for row in range(4):
        for column in range(4):
            state[row][column] = SBOX[state[row][column]]


def _shift_rows(state):
    state[0][1], state[1][1], state[2][1], state[3][1] = state[1][1], state[2][1], state[3][1], state[0][1]
    state[0][2], state[1][2], state[2][2], state[3][2] = state[2][2], state[3][2], state[0][2], state[1][2]
    state[0][3], state[1][3], state[2][3], state[3][3] = state[3][3], state[0][3], state[1][3], state[2][3]


def _mix_column(column):
    total = column[0] ^ column[1] ^ column[2] ^ column[3]
    first = column[0]
    column[0] ^= total ^ _xtime(column[0] ^ column[1])
    column[1] ^= total ^ _xtime(column[1] ^ column[2])
    column[2] ^= total ^ _xtime(column[2] ^ column[3])
    column[3] ^= total ^ _xtime(column[3] ^ first)


def _encrypt_block(block, key):
    round_keys = _expand_key(key)
    state = _bytes_to_matrix(block)
    _add_round_key(state, round_keys[0])
    for round_number in range(1, 14):
        _sub_bytes(state)
        _shift_rows(state)
        for column in state:
            _mix_column(column)
        _add_round_key(state, round_keys[round_number])
    _sub_bytes(state)
    _shift_rows(state)
    _add_round_key(state, round_keys[14])
    return _matrix_to_bytes(state)


def _multiply_gf(left, right):
    result = 0
    value = left
    for bit in range(128):
        if right & (1 << (127 - bit)):
            result ^= value
        value = (value >> 1) ^ (0xE1000000000000000000000000000000 if value & 1 else 0)
    return result


def _ghash(hash_key, ciphertext, aad=b""):
    aad_padding = b"\x00" * ((16 - len(aad) % 16) % 16)
    ciphertext_padding = b"\x00" * ((16 - len(ciphertext) % 16) % 16)
    data = (
        aad
        + aad_padding
        + ciphertext
        + ciphertext_padding
        + (len(aad) * 8).to_bytes(8, "big")
        + (len(ciphertext) * 8).to_bytes(8, "big")
    )
    result = 0
    for index in range(0, len(data), 16):
        result = _multiply_gf(result ^ int.from_bytes(data[index:index + 16], "big"), hash_key)
    return result


def decrypt(key, iv, ciphertext_and_tag, aad=b""):
    if len(key) != 32 or len(iv) != 12 or len(ciphertext_and_tag) < 16:
        raise ValueError("Invalid AES-256-GCM input")
    ciphertext = ciphertext_and_tag[:-16]
    tag = ciphertext_and_tag[-16:]
    zero_block = b"\x00" * 16
    hash_key = int.from_bytes(_encrypt_block(zero_block, key), "big")
    initial_counter = iv + b"\x00\x00\x00\x01"
    expected_tag = bytes(
        left ^ right
        for left, right in zip(
            _encrypt_block(initial_counter, key),
            _ghash(hash_key, ciphertext, aad).to_bytes(16, "big"),
        )
    )
    if not hmac.compare_digest(tag, expected_tag):
        raise ValueError("AES-GCM authentication failed")

    prefix = int.from_bytes(initial_counter[:12], "big") << 32
    counter = int.from_bytes(initial_counter[12:], "big")
    plaintext = bytearray()
    for index in range(0, len(ciphertext), 16):
        counter = (counter + 1) & 0xFFFFFFFF
        stream = _encrypt_block((prefix | counter).to_bytes(16, "big"), key)
        block = ciphertext[index:index + 16]
        plaintext.extend(left ^ right for left, right in zip(block, stream))
    return bytes(plaintext)
