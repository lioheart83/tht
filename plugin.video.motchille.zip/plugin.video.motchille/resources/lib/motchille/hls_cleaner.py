# -*- coding: utf-8 -*-
"""HLS variant selection and #EXT-X-DISCONTINUITY ad-segment filtering."""

import posixpath
import re
import urllib.parse

_AD_PATH_RE = re.compile(
    r'(?:/convertv\d+/|/adjump/|/v\d+/[0-9a-f]{32}/segment_)',
    re.IGNORECASE,
)


def parse_hls_variants(manifest_text, manifest_url):
    """Parse master playlist #EXT-X-STREAM-INF variants."""
    variants = []
    lines = manifest_text.splitlines()

    for index, line in enumerate(lines):
        stripped = line.strip()
        if not stripped.startswith('#EXT-X-STREAM-INF'):
            continue

        bandwidth_match = re.search(r'BANDWIDTH=(\d+)', stripped)
        bandwidth = int(bandwidth_match.group(1)) if bandwidth_match else 0

        for next_index in range(index + 1, len(lines)):
            next_line = lines[next_index].strip()
            if not next_line or next_line.startswith('#'):
                continue
            variants.append({
                'bandwidth': bandwidth,
                'url': urllib.parse.urljoin(manifest_url, next_line),
            })
            break

    return variants


def select_hls_variant_url(manifest_text, manifest_url, prefer_low_bandwidth=False):
    """Choose best or lowest-bandwidth variant URL unless alternate audio tracks exist."""
    if '#EXT-X-MEDIA:TYPE=AUDIO' in manifest_text:
        return ''
    variants = parse_hls_variants(manifest_text, manifest_url)
    if not variants:
        return ''
    variants.sort(key=lambda item: (item['bandwidth'] <= 0, item['bandwidth']))
    if prefer_low_bandwidth:
        return variants[0]['url']
    return variants[-1]['url']


def _absolutize_uri_attr(line, base_url):
    def _replace(match):
        raw_uri = match.group(1)
        abs_uri = urllib.parse.urljoin(base_url, raw_uri)
        return 'URI="%s"' % abs_uri

    return re.sub(r'URI="([^"]+)"', _replace, line)


def absolutize_manifest(manifest_text, manifest_url):
    """Convert all relative segment, variant, key, and map URIs to absolute URLs."""
    if not manifest_url:
        return manifest_text
    output = []
    for line in manifest_text.splitlines():
        stripped = line.strip()
        if not stripped:
            output.append(line)
        elif stripped.startswith('#'):
            output.append(_absolutize_uri_attr(line, manifest_url))
        else:
            output.append(urllib.parse.urljoin(manifest_url, stripped))
    return '\n'.join(output)


def _segment_dir_key(segment_url):
    parsed = urllib.parse.urlsplit(segment_url)
    return (parsed.scheme.lower(), parsed.netloc.lower(), posixpath.dirname(parsed.path))


def _is_ad_section(section, dominant_dir):
    segments = section['segments']
    if not segments:
        return False

    urls = [url for _, url in segments]
    if all(_AD_PATH_RE.search(urllib.parse.urlsplit(url).path) for url in urls):
        return True

    dirs = {_segment_dir_key(url) for url in urls}
    if dominant_dir is not None and dominant_dir not in dirs and len(segments) <= 30:
        return True

    return False


def clean_hls_manifest(manifest_text, manifest_url, strip_ads=True):
    """Absolutize an HLS playlist and strip injected #EXT-X-DISCONTINUITY ad blocks.

    Returns (cleaned_manifest_text, removed_ad_segments_count).
    """
    if not manifest_text:
        return manifest_text, 0

    if '#EXT-X-STREAM-INF' in manifest_text or not strip_ads or '#EXT-X-DISCONTINUITY' not in manifest_text:
        return absolutize_manifest(manifest_text, manifest_url), 0

    lines = manifest_text.splitlines()
    header_lines = []
    sections = []
    current_section = {'segments': [], 'key_line': None, 'map_line': None}
    pending_tags = []
    seen_first_segment_or_disc = False
    has_endlist = False

    header_key = None
    header_map = None

    for raw_line in lines:
        stripped = raw_line.strip()
        if not stripped:
            continue

        if stripped == '#EXT-X-ENDLIST':
            has_endlist = True
            continue

        if stripped == '#EXT-X-DISCONTINUITY':
            seen_first_segment_or_disc = True
            if current_section['segments']:
                sections.append(current_section)
                current_section = {'segments': [], 'key_line': None, 'map_line': None}
            pending_tags = []
            continue

        if stripped.startswith('#'):
            abs_line = _absolutize_uri_attr(stripped, manifest_url) if manifest_url else stripped
            if not seen_first_segment_or_disc and not pending_tags and not stripped.startswith('#EXTINF') and not stripped.startswith('#EXT-X-BYTERANGE'):
                if stripped.startswith('#EXT-X-KEY'):
                    header_key = abs_line
                elif stripped.startswith('#EXT-X-MAP'):
                    header_map = abs_line
                header_lines.append(abs_line)
            else:
                if stripped.startswith('#EXT-X-KEY'):
                    current_section['key_line'] = abs_line
                elif stripped.startswith('#EXT-X-MAP'):
                    current_section['map_line'] = abs_line
                pending_tags.append(abs_line)
            continue

        seen_first_segment_or_disc = True
        seg_url = urllib.parse.urljoin(manifest_url, stripped) if manifest_url else stripped
        current_section['segments'].append((pending_tags, seg_url))
        pending_tags = []

    if current_section['segments']:
        sections.append(current_section)

    if len(sections) <= 1:
        return absolutize_manifest(manifest_text, manifest_url), 0

    dir_counts = {}
    total_segments = 0
    for section in sections:
        for _, url in section['segments']:
            key = _segment_dir_key(url)
            dir_counts[key] = dir_counts.get(key, 0) + 1
            total_segments += 1

    if total_segments < 20 or not dir_counts:
        return absolutize_manifest(manifest_text, manifest_url), 0

    dominant_dir, dominant_count = max(dir_counts.items(), key=lambda item: item[1])
    if dominant_count / float(total_segments) < 0.60:
        return absolutize_manifest(manifest_text, manifest_url), 0

    kept_sections = []
    removed_count = 0
    removed_since_last_kept = False

    for section in sections:
        if _is_ad_section(section, dominant_dir):
            removed_count += len(section['segments'])
            removed_since_last_kept = True
        else:
            kept_sections.append((section, removed_since_last_kept))
            removed_since_last_kept = False

    kept_total = sum(len(sec['segments']) for sec, _ in kept_sections)
    if removed_count == 0 or kept_total == 0 or kept_total < total_segments * 0.50:
        return absolutize_manifest(manifest_text, manifest_url), 0

    rebuilt = list(header_lines)
    active_key = header_key or '#EXT-X-KEY:METHOD=NONE'

    for sec_index, (section, had_removed_before) in enumerate(kept_sections):
        if sec_index > 0:
            rebuilt.append('#EXT-X-DISCONTINUITY')
            if had_removed_before and not section['key_line'] and active_key and active_key != '#EXT-X-KEY:METHOD=NONE':
                # Restore movie encryption key if an adjacent stripped ad block had set METHOD=NONE.
                rebuilt.append(active_key)

        for tags, seg_url in section['segments']:
            for tag in tags:
                if tag.startswith('#EXT-X-KEY'):
                    active_key = tag
                rebuilt.append(tag)
            rebuilt.append(seg_url)

    if has_endlist:
        rebuilt.append('#EXT-X-ENDLIST')

    return '\n'.join(rebuilt) + '\n', removed_count
