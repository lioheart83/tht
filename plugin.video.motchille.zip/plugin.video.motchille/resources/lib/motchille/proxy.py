# -*- coding: utf-8 -*-
"""Persistent localhost HTTP/2 HLS proxy for Kodi playback.

Handles:
- PNG-disguised MPEG-TS segments (strips fake image headers using buffered head probing)
- fMP4 / HTTP/2-only segments (streamc.xyz, vicdn.cc, streamvsmov.com)
- Clean rewritten manifests served over localhost without short-read or HEAD bugs
"""

import collections
import json
import re
import secrets
import threading
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import httpx
import xbmc
import xbmcgui

from resources.lib.motchille.config import USER_AGENT, WINDOW_PROP_PROXY, log

_MAX_SESSIONS = 6
_PROBE_BYTES = 32768
_MAX_TS_SCAN = 24576
_CHUNK_BYTES = 65536


def find_mpeg_ts_offset(payload):
    """Locate the first valid MPEG-TS sync sequence (4 consecutive 188-byte packets).

    Returns offset >= 0 if MPEG-TS is detected, or -1 otherwise.
    """
    if not payload or len(payload) < 188 * 4:
        return -1

    packet_size = 188
    probe_packets = 4
    limit = min(len(payload) - (packet_size * (probe_packets - 1)), _MAX_TS_SCAN)

    for offset in range(max(0, limit)):
        if payload[offset] != 0x47:
            continue
        if all(payload[offset + (packet_size * idx)] == 0x47 for idx in range(1, probe_packets)):
            return offset

    return -1


def detect_media_content_type(head, upstream_url=''):
    """Determine (skip_bytes, content_type) from the buffered head of a media segment."""
    if not head:
        return 0, 'application/octet-stream'

    ts_offset = find_mpeg_ts_offset(head)
    if ts_offset >= 0:
        if ts_offset > 0:
            log('Đã bỏ %d byte rác trước MPEG-TS: %s' % (ts_offset, upstream_url))
        return ts_offset, 'video/mp2t'

    if len(head) >= 8 and head[4:8] in (b'ftyp', b'styp', b'moof', b'sidx', b'mdat'):
        return 0, 'video/mp4'

    lower = urllib.parse.urlsplit(upstream_url or '').path.lower()
    if lower.endswith('.ts'):
        return 0, 'video/mp2t'
    if lower.endswith('.m4s') or lower.endswith('.mp4'):
        return 0, 'video/mp4'
    if lower.endswith('.aac'):
        return 0, 'audio/aac'

    return 0, 'application/octet-stream'


def rewrite_manifest_for_proxy(manifest_text, manifest_url, port, session_id, media_urls, segment_ext='ts'):
    """Rewrite all media and encryption key/map URIs in a playlist to local proxy endpoints."""
    rewritten = []

    def _register_media(raw_uri):
        upstream = urllib.parse.urljoin(manifest_url, raw_uri) if manifest_url else raw_uri
        index = len(media_urls)
        media_urls.append(upstream)
        return 'http://127.0.0.1:%d/s/%s/media/%d.%s' % (port, session_id, index, segment_ext)

    for line in manifest_text.splitlines():
        stripped = line.strip()
        if not stripped:
            rewritten.append(line)
            continue
        if stripped.startswith('#'):
            rewritten.append(re.sub(r'URI="([^"]+)"', lambda m: 'URI="%s"' % _register_media(m.group(1)), line))
            continue
        rewritten.append(_register_media(stripped))

    return '\n'.join(rewritten) + '\n'


class _ReusableThreadingHTTPServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True


class HlsProxyServer(object):
    """Threaded localhost HLS proxy backed by an HTTP/2-capable httpx client."""

    def __init__(self, timeout=25):
        self.timeout = timeout
        self.token = secrets.token_hex(16)
        self.httpd = None
        self.thread = None
        self.port = 0
        self._lock = threading.Lock()
        self._sessions = collections.OrderedDict()
        self._client = httpx.Client(
            http2=True,
            follow_redirects=True,
            timeout=httpx.Timeout(timeout, connect=8.0),
            limits=httpx.Limits(max_connections=32, max_keepalive_connections=16),
            headers={'User-Agent': USER_AGENT},
        )
        self._handler_class = self._build_handler()

    def _build_handler(self):
        owner = self

        class ProxyHandler(BaseHTTPRequestHandler):
            protocol_version = 'HTTP/1.1'

            def _send_bytes(self, status, content_type, data, head_only=False):
                self.send_response(status)
                self.send_header('Content-Type', content_type)
                self.send_header('Content-Length', str(len(data)))
                self.send_header('Connection', 'close')
                self.end_headers()
                if not head_only and data:
                    self.wfile.write(data)

            def do_HEAD(self):
                self._handle_read(head_only=True)

            def do_GET(self):
                self._handle_read(head_only=False)

            def do_POST(self):
                if self.path != '/session':
                    self.send_error(404)
                    return
                if self.headers.get('X-Motchille-Token') != owner.token:
                    self.send_error(403)
                    return
                try:
                    length = int(self.headers.get('Content-Length') or 0)
                    raw = self.rfile.read(length)
                    payload = json.loads(raw.decode('utf-8'))
                    playlist_url = owner.register_session(
                        manifest_text=payload['manifest_text'],
                        manifest_url=payload.get('manifest_url', ''),
                        headers=payload.get('headers') or {},
                        needs_segment_proxy=bool(payload.get('needs_segment_proxy', True)),
                        segment_ext=payload.get('segment_ext') or 'ts',
                    )
                    body = json.dumps({'playlist_url': playlist_url}).encode('utf-8')
                    self._send_bytes(200, 'application/json', body)
                except Exception as exc:
                    log('Proxy /session lỗi: %s' % exc, xbmc.LOGERROR)
                    self.send_error(400)

            def _handle_read(self, head_only=False):
                path = urllib.parse.urlsplit(self.path).path
                if path == '/health':
                    self._send_bytes(200, 'text/plain', b'ok', head_only=head_only)
                    return

                manifest_match = re.match(r'^/s/([0-9a-f]+)/manifest\.m3u8$', path)
                if manifest_match:
                    session = owner.get_session(manifest_match.group(1))
                    if not session:
                        self.send_error(404)
                        return
                    self._send_bytes(
                        200,
                        'application/vnd.apple.mpegurl; charset=utf-8',
                        session['manifest_bytes'],
                        head_only=head_only,
                    )
                    return

                media_match = re.match(r'^/s/([0-9a-f]+)/media/(\d+)\.[a-z0-9]+$', path)
                if media_match:
                    session = owner.get_session(media_match.group(1))
                    idx = int(media_match.group(2))
                    if not session or idx < 0 or idx >= len(session['media_urls']):
                        self.send_error(404)
                        return
                    self._stream_media(session, session['media_urls'][idx], head_only=head_only)
                    return

                self.send_error(404)

            def _stream_media(self, session, upstream_url, head_only=False):
                req_headers = dict(session['headers'])
                range_hdr = self.headers.get('Range')
                if range_hdr:
                    req_headers['Range'] = range_hdr

                try:
                    with owner._client.stream('GET', upstream_url, headers=req_headers) as upstream:
                        if upstream.status_code >= 400:
                            log('Proxy upstream %d: %s' % (upstream.status_code, upstream_url), xbmc.LOGERROR)
                            self.send_error(upstream.status_code)
                            return

                        iterator = upstream.iter_bytes(chunk_size=_CHUNK_BYTES)
                        head_buf = bytearray()
                        while len(head_buf) < _PROBE_BYTES:
                            try:
                                chunk = next(iterator)
                            except StopIteration:
                                break
                            if chunk:
                                head_buf.extend(chunk)

                        head_bytes = bytes(head_buf)
                        skip, content_type = detect_media_content_type(head_bytes, upstream_url)
                        trimmed_head = head_bytes[skip:]

                        self.send_response(upstream.status_code)
                        self.send_header('Content-Type', content_type)
                        has_encoding = upstream.headers.get('Content-Encoding', '').lower() not in ('', 'identity')
                        upstream_len = upstream.headers.get('Content-Length')
                        if not has_encoding and upstream_len and upstream_len.isdigit():
                            adjusted = max(0, int(upstream_len) - skip)
                            self.send_header('Content-Length', str(adjusted))
                        content_range = upstream.headers.get('Content-Range')
                        if content_range and not has_encoding and skip == 0:
                            self.send_header('Content-Range', content_range)
                        self.send_header('Connection', 'close')
                        self.end_headers()

                        if head_only:
                            return

                        if trimmed_head:
                            self.wfile.write(trimmed_head)
                        for chunk in iterator:
                            if chunk:
                                self.wfile.write(chunk)
                except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                    return
                except Exception as exc:
                    log('Proxy segment lỗi (%s): %s' % (upstream_url, exc), xbmc.LOGERROR)
                    try:
                        self.send_error(502)
                    except Exception:
                        pass

            def log_message(self, format_str, *args):
                return

        return ProxyHandler

    def register_session(self, manifest_text, manifest_url='', headers=None, needs_segment_proxy=True, segment_ext='ts'):
        """Store an HLS session and return its localhost playlist URL."""
        session_id = secrets.token_hex(8)
        media_urls = []
        if needs_segment_proxy:
            served_manifest = rewrite_manifest_for_proxy(
                manifest_text,
                manifest_url,
                self.port,
                session_id,
                media_urls,
                segment_ext=segment_ext,
            )
        else:
            served_manifest = manifest_text if manifest_text.endswith('\n') else (manifest_text + '\n')

        entry = {
            'manifest_bytes': served_manifest.encode('utf-8'),
            'media_urls': media_urls,
            'headers': dict(headers or {'User-Agent': USER_AGENT}),
        }
        with self._lock:
            self._sessions[session_id] = entry
            while len(self._sessions) > _MAX_SESSIONS:
                self._sessions.popitem(last=False)

        return 'http://127.0.0.1:%d/s/%s/manifest.m3u8' % (self.port, session_id)

    def get_session(self, session_id):
        with self._lock:
            return self._sessions.get(session_id)

    def start(self):
        """Start the HTTP proxy daemon thread and return bound port."""
        self.httpd = _ReusableThreadingHTTPServer(('127.0.0.1', 0), self._handler_class)
        self.port = self.httpd.server_port
        self.thread = threading.Thread(target=self.httpd.serve_forever, name='MotchilleHlsProxy', daemon=True)
        self.thread.start()
        return self.port

    def stop(self):
        """Shut down HTTP server and close pooled httpx client."""
        try:
            if self.httpd:
                self.httpd.shutdown()
                self.httpd.server_close()
        except Exception:
            pass
        try:
            self._client.close()
        except Exception:
            pass
        self.httpd = None
        self.thread = None


_FALLBACK_LOCK = threading.Lock()
_FALLBACK_PROXY = None


def _get_service_proxy_info():
    try:
        raw = xbmcgui.Window(10000).getProperty(WINDOW_PROP_PROXY)
        if not raw:
            return None
        info = json.loads(raw)
        if info.get('port') and info.get('token'):
            return info
    except Exception:
        pass
    return None


def publish_stream_to_proxy(resolved):
    """Publish a resolved HLS manifest to the background proxy service and return playlist URL.

    Falls back to a local in-process proxy server if service.py has not started yet.
    """
    global _FALLBACK_PROXY

    payload = {
        'manifest_text': resolved['manifest_text'],
        'manifest_url': resolved.get('manifest_url', ''),
        'headers': resolved.get('headers') or {},
        'needs_segment_proxy': bool(resolved.get('needs_segment_proxy', True)),
        'segment_ext': resolved.get('segment_ext') or 'ts',
    }

    service_info = _get_service_proxy_info()
    if service_info:
        try:
            endpoint = 'http://127.0.0.1:%d/session' % int(service_info['port'])
            with httpx.Client(timeout=5.0) as local_client:
                resp = local_client.post(
                    endpoint,
                    headers={'X-Motchille-Token': service_info['token']},
                    json=payload,
                )
                resp.raise_for_status()
                return resp.json()['playlist_url']
        except Exception as exc:
            log('Không kết nối được service proxy, dùng fallback nội bộ: %s' % exc, xbmc.LOGWARNING)

    with _FALLBACK_LOCK:
        if _FALLBACK_PROXY is None:
            _FALLBACK_PROXY = HlsProxyServer()
            _FALLBACK_PROXY.start()
        return _FALLBACK_PROXY.register_session(
            manifest_text=payload['manifest_text'],
            manifest_url=payload['manifest_url'],
            headers=payload['headers'],
            needs_segment_proxy=payload['needs_segment_proxy'],
            segment_ext=payload['segment_ext'],
        )
