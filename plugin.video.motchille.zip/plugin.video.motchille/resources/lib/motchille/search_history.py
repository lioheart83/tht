# -*- coding: utf-8 -*-
"""Persistent search history management inside Kodi's addon_data profile."""

import json
import os

import xbmcvfs

from resources.lib.motchille.config import ADDON_ID, translate_path

_MAX_HISTORY = 20


def _history_file_path():
    profile_dir = translate_path('special://profile/addon_data/%s/' % ADDON_ID)
    if not xbmcvfs.exists(profile_dir):
        xbmcvfs.mkdirs(profile_dir)
    if not os.path.isdir(profile_dir):
        os.makedirs(profile_dir, exist_ok=True)
    return os.path.join(profile_dir, 'search_history.json')


def load_history():
    """Return list of recent search queries (newest first)."""
    path = _history_file_path()
    if not os.path.isfile(path):
        return []
    try:
        with open(path, 'r', encoding='utf-8') as handle:
            data = json.load(handle)
        if isinstance(data, list):
            return [str(item).strip() for item in data if str(item).strip()][:_MAX_HISTORY]
    except Exception:
        pass
    return []


def _save_history(items):
    path = _history_file_path()
    try:
        with open(path, 'w', encoding='utf-8') as handle:
            json.dump(items[:_MAX_HISTORY], handle, ensure_ascii=False, indent=2)
    except Exception:
        pass


def add_query(keyword):
    """Add or promote a keyword to the top of search history."""
    text = (keyword or '').strip()
    if not text:
        return
    items = [item for item in load_history() if item.lower() != text.lower()]
    items.insert(0, text)
    _save_history(items)


def remove_query(keyword):
    """Remove a single keyword from search history."""
    text = (keyword or '').strip()
    if not text:
        return
    items = [item for item in load_history() if item.lower() != text.lower()]
    _save_history(items)


def clear_history():
    """Clear all saved search history."""
    _save_history([])
