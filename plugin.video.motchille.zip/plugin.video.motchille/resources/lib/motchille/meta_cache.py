# -*- coding: utf-8 -*-
"""SQLite metadata cache for movie descriptions and info shown in outer listings."""

import json
import os
import sqlite3
import threading
import time

import xbmcvfs

from resources.lib.motchille.config import ADDON_ID, translate_path

_CACHE_LOCK = threading.Lock()
_DEFAULT_TTL_SECONDS = 7 * 86400
_DEFAULT_MAX_ENTRIES = 2000


def _db_path():
    profile_dir = translate_path('special://profile/addon_data/%s/' % ADDON_ID)
    if not xbmcvfs.exists(profile_dir):
        xbmcvfs.mkdirs(profile_dir)
    if not os.path.isdir(profile_dir):
        os.makedirs(profile_dir, exist_ok=True)
    return os.path.join(profile_dir, 'meta_cache.db')


def _connect():
    conn = sqlite3.connect(_db_path(), timeout=5.0)
    conn.execute(
        'CREATE TABLE IF NOT EXISTS movie_meta ('
        'slug TEXT PRIMARY KEY, '
        'data TEXT NOT NULL, '
        'updated_at INTEGER NOT NULL'
        ')'
    )
    return conn


def get_many(slugs, ttl_seconds=_DEFAULT_TTL_SECONDS):
    """Fetch cached metadata dicts for the requested slugs that have not expired."""
    clean_slugs = [str(slug) for slug in (slugs or []) if slug]
    if not clean_slugs:
        return {}

    cutoff = int(time.time()) - int(ttl_seconds)
    results = {}
    with _CACHE_LOCK:
        conn = None
        try:
            conn = _connect()
            placeholders = ','.join('?' for _ in clean_slugs)
            query = (
                'SELECT slug, data FROM movie_meta '
                'WHERE slug IN (%s) AND updated_at >= ?' % placeholders
            )
            cursor = conn.execute(query, clean_slugs + [cutoff])
            for slug, raw_json in cursor.fetchall():
                try:
                    parsed = json.loads(raw_json)
                    if isinstance(parsed, dict):
                        results[slug] = parsed
                except Exception:
                    pass
        except Exception:
            return {}
        finally:
            if conn is not None:
                try:
                    conn.close()
                except Exception:
                    pass
    return results


def put_many(items_by_slug, max_entries=_DEFAULT_MAX_ENTRIES):
    """Insert or update cached metadata entries and prune oldest records above max_entries."""
    if not items_by_slug:
        return

    now = int(time.time())
    rows = []
    for slug, meta in items_by_slug.items():
        if not slug or not isinstance(meta, dict):
            continue
        try:
            rows.append((str(slug), json.dumps(meta, ensure_ascii=False), now))
        except Exception:
            pass
    if not rows:
        return

    with _CACHE_LOCK:
        conn = None
        try:
            conn = _connect()
            with conn:
                conn.executemany(
                    'INSERT OR REPLACE INTO movie_meta (slug, data, updated_at) VALUES (?, ?, ?)',
                    rows,
                )
                count_row = conn.execute('SELECT COUNT(*) FROM movie_meta').fetchone()
                total = count_row[0] if count_row else 0
                if total > max_entries:
                    excess = total - max_entries
                    conn.execute(
                        'DELETE FROM movie_meta WHERE slug IN ('
                        'SELECT slug FROM movie_meta ORDER BY updated_at ASC LIMIT ?'
                        ')',
                        (excess,),
                    )
        except Exception:
            pass
        finally:
            if conn is not None:
                try:
                    conn.close()
                except Exception:
                    pass
