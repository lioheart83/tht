# -*- coding: utf-8 -*-
"""Motchille Kodi addon core package."""
