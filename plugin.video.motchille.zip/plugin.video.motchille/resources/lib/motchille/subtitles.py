# -*- coding: utf-8 -*-
"""WebVTT parsing and temporary Vietnamese SRT subtitle management."""

import hashlib
import html
import os
import re
import time

import xbmcvfs

from resources.lib.motchille.config import translate_path

_TIMESTAMP_RE = re.compile(
    r'(?:(\d{1,2}):)?(\d{2}):(\d{2})[.,](\d{3})\s*-->\s*(?:(\d{1,2}):)?(\d{2}):(\d{2})[.,](\d{3})'
)
_TAG_RE = re.compile(r'<[^>]+>')
_SUB_CACHE_DIR = 'special://temp/motchille_subs/'
_SUB_MAX_AGE_SECONDS = 86400


def _to_ms(hours, minutes, seconds, millis):
    h = int(hours or 0)
    m = int(minutes)
    s = int(seconds)
    ms = int(millis)
    return (((h * 60) + m) * 60 + s) * 1000 + ms


def _format_srt_time(total_ms):
    total_ms = max(0, int(total_ms))
    hours, rem = divmod(total_ms, 3600000)
    minutes, rem = divmod(rem, 60000)
    seconds, millis = divmod(rem, 1000)
    return '%02d:%02d:%02d,%03d' % (hours, minutes, seconds, millis)


def _clean_cue_text(lines):
    cleaned = []
    for line in lines:
        text = _TAG_RE.sub('', line)
        text = html.unescape(text).strip()
        if text:
            cleaned.append(text)
    return '\n'.join(cleaned)


def vtt_to_cues(vtt_text):
    """Parse WebVTT text (including MM:SS.mmm without hours) into normalized cue dicts."""
    if not vtt_text:
        return []

    normalized = vtt_text.lstrip('\ufeff').replace('\r\n', '\n').replace('\r', '\n')
    cues = []
    blocks = re.split(r'\n{2,}', normalized)

    for block in blocks:
        lines = [line.rstrip() for line in block.split('\n') if line.strip()]
        if not lines:
            continue
        header = lines[0].strip().upper()
        if header.startswith('WEBVTT') or header.startswith('NOTE') or header.startswith('STYLE') or header.startswith('REGION'):
            continue

        time_idx = -1
        match = None
        for idx, line in enumerate(lines):
            match = _TIMESTAMP_RE.search(line)
            if match:
                time_idx = idx
                break
        if match is None:
            continue

        start_ms = _to_ms(*match.groups()[:4])
        end_ms = _to_ms(*match.groups()[4:8])
        if end_ms <= start_ms:
            end_ms = start_ms + 1000

        text = _clean_cue_text(lines[time_idx + 1:])
        if not text:
            continue

        cues.append({
            'start': start_ms,
            'end': end_ms,
            'text': text,
        })

    return cues


def cues_to_srt(cues):
    """Serialize cue dicts into standard UTF-8 SRT subtitle text."""
    out = []
    for index, cue in enumerate(cues, start=1):
        out.append('%d\n%s --> %s\n%s\n' % (
            index,
            _format_srt_time(cue['start']),
            _format_srt_time(cue['end']),
            cue['text'],
        ))
    return '\n'.join(out)


def _ensure_sub_dir():
    local_dir = translate_path(_SUB_CACHE_DIR)
    if not xbmcvfs.exists(local_dir):
        xbmcvfs.mkdirs(local_dir)
    if not os.path.isdir(local_dir):
        os.makedirs(local_dir, exist_ok=True)
    return local_dir


def _cleanup_old_subs(local_dir):
    now = time.time()
    try:
        for name in os.listdir(local_dir):
            if not name.endswith('.srt'):
                continue
            path = os.path.join(local_dir, name)
            try:
                if now - os.path.getmtime(path) > _SUB_MAX_AGE_SECONDS:
                    os.remove(path)
            except OSError:
                pass
    except OSError:
        pass


def save_temp_srt(srt_text, key_seed, lang_code):
    """Write SRT subtitle content into Kodi temp directory and return its local path."""
    if not srt_text or not srt_text.strip():
        return ''
    local_dir = _ensure_sub_dir()
    _cleanup_old_subs(local_dir)
    digest = hashlib.md5((key_seed or 'sub').encode('utf-8')).hexdigest()[:12]
    filename = '%s.%s.srt' % (digest, lang_code)
    file_path = os.path.join(local_dir, filename)
    with open(file_path, 'w', encoding='utf-8') as handle:
        handle.write(srt_text)
    return file_path


def build_subtitle_files(key_seed, vi_vtt=''):
    """Convert raw Vietnamese WebVTT string into a single local SRT file path."""
    vi_cues = vtt_to_cues(vi_vtt) if vi_vtt else []
    if not vi_cues:
        return []
    vi_path = save_temp_srt(cues_to_srt(vi_cues), key_seed, 'vi')
    return [vi_path] if vi_path else []
