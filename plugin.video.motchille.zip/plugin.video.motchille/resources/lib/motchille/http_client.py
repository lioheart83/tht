# -*- coding: utf-8 -*-
"""HTTP/2 client with pooled connections and automatic Motchill mirror failover."""

import json
import threading
import time
import urllib.parse

import httpx
import xbmc
import xbmcgui

from resources.lib.motchille.config import (
    DEFAULT_HEADERS,
    DEFAULT_MIRRORS,
    MIRROR_MODES,
    MIRROR_TTL_SECONDS,
    WINDOW_PROP_MIRROR,
    get_settings,
    log,
)

_CLIENT_LOCK = threading.Lock()
_SHARED_CLIENT = None
_SHARED_TIMEOUT = None


def get_shared_client(timeout=12):
    """Return a thread-safe shared httpx.Client with HTTP/2 enabled."""
    global _SHARED_CLIENT, _SHARED_TIMEOUT
    with _CLIENT_LOCK:
        if _SHARED_CLIENT is None or _SHARED_TIMEOUT != timeout:
            if _SHARED_CLIENT is not None:
                try:
                    _SHARED_CLIENT.close()
                except Exception:
                    pass
            _SHARED_CLIENT = httpx.Client(
                http2=True,
                follow_redirects=True,
                timeout=httpx.Timeout(timeout, connect=min(5.0, float(timeout))),
                limits=httpx.Limits(max_connections=20, max_keepalive_connections=10),
                headers=DEFAULT_HEADERS.copy(),
            )
            _SHARED_TIMEOUT = timeout
        return _SHARED_CLIENT


def build_headers(referer=None, origin=None, accept=None, extra=None):
    """Construct browser-like request headers."""
    headers = DEFAULT_HEADERS.copy()
    if referer:
        headers['Referer'] = referer
        if not origin:
            parsed = urllib.parse.urlsplit(referer)
            if parsed.scheme and parsed.netloc:
                headers['Origin'] = '%s://%s' % (parsed.scheme, parsed.netloc)
    if origin:
        headers['Origin'] = origin
    if accept:
        headers['Accept'] = accept
    if extra:
        headers.update(extra)
    return headers


def extract_origin(url):
    """Return scheme://netloc for an HTTP URL."""
    parsed = urllib.parse.urlsplit(url or '')
    if parsed.scheme and parsed.netloc:
        return '%s://%s' % (parsed.scheme, parsed.netloc)
    return ''


def _get_cached_mirror():
    try:
        raw = xbmcgui.Window(10000).getProperty(WINDOW_PROP_MIRROR)
        if not raw:
            return ''
        data = json.loads(raw)
        if time.time() - float(data.get('ts', 0)) < MIRROR_TTL_SECONDS:
            return data.get('origin', '')
    except Exception:
        pass
    return ''


def _set_cached_mirror(origin):
    if not origin:
        return
    try:
        payload = json.dumps({'origin': origin, 'ts': int(time.time())})
        xbmcgui.Window(10000).setProperty(WINDOW_PROP_MIRROR, payload)
    except Exception:
        pass


def get_candidate_mirrors(settings=None):
    """Return ordered list of mirror base URLs based on addon settings."""
    if settings is None:
        settings = get_settings()

    mode = settings.get('mirror_mode', 0)
    if mode in MIRROR_MODES:
        return [MIRROR_MODES[mode]]
    if mode == 3 and settings.get('custom_domain'):
        return [settings['custom_domain']]

    ordered = []
    cached = _get_cached_mirror()
    if cached:
        ordered.append(cached)
    for mirror in DEFAULT_MIRRORS:
        if mirror not in ordered:
            ordered.append(mirror)
    return ordered


def get_active_base_url(settings=None):
    """Return the currently preferred mirror origin without performing network I/O."""
    return get_candidate_mirrors(settings)[0]


def _is_blocked_or_stub_response(response):
    """Detect Cloudflare challenge pages, HTTP errors, or parked domain landers."""
    if response.status_code in (403, 429) or response.status_code >= 500:
        return True
    final_url = str(response.url)
    if '/lander' in final_url:
        return True
    text = response.text or ''
    if len(text) < 800 and ('/lander' in text or 'cf-browser-verification' in text or 'Just a moment' in text):
        return True
    return False


def fetch_url(url, referer=None, accept=None, extra_headers=None, retries=2, timeout=None):
    """Fetch a standalone URL (non-mirror CDN/player/API) with short retries."""
    if timeout is None:
        timeout = get_settings()['timeout']
    client = get_shared_client(timeout)
    headers = build_headers(referer=referer, accept=accept, extra=extra_headers)
    last_error = None
    for attempt in range(retries):
        try:
            response = client.get(url, headers=headers)
            response.raise_for_status()
            return response
        except (httpx.HTTPError, OSError) as exc:
            last_error = exc
            log('GET lỗi (%d/%d) %s: %s' % (attempt + 1, retries, url, exc), xbmc.LOGWARNING)
            if attempt + 1 < retries:
                xbmc.sleep(350 * (attempt + 1))
    raise last_error


def fetch_site_html(path_or_url, referer=None, settings=None):
    """Fetch a Motchill site page, failing over automatically across mirrors in auto mode.

    Returns (html_text, final_url, active_base_url).
    """
    if settings is None:
        settings = get_settings()
    timeout = settings['timeout']
    client = get_shared_client(timeout)
    mirrors = get_candidate_mirrors(settings)

    parsed_input = urllib.parse.urlsplit(path_or_url or '')
    if parsed_input.scheme and parsed_input.netloc:
        rel_path = parsed_input.path or '/'
        if parsed_input.query:
            rel_path += '?' + parsed_input.query
        input_origin = '%s://%s' % (parsed_input.scheme, parsed_input.netloc)
        try_bases = [input_origin] + [m for m in mirrors if m != input_origin]
        if settings.get('mirror_mode', 0) != 0:
            try_bases = [input_origin]
    else:
        rel_path = path_or_url if (path_or_url or '').startswith('/') else '/' + (path_or_url or '')
        try_bases = mirrors

    last_error = None
    for base in try_bases:
        target_url = base.rstrip('/') + rel_path
        req_referer = referer or (base.rstrip('/') + '/')
        headers = build_headers(referer=req_referer, origin=base.rstrip('/'))
        try:
            log('GET ' + target_url)
            response = client.get(target_url, headers=headers)
            if _is_blocked_or_stub_response(response):
                raise httpx.HTTPStatusError(
                    'Mirror bị chặn hoặc trả trang chờ (%d)' % response.status_code,
                    request=response.request,
                    response=response,
                )
            response.raise_for_status()
            final_url = str(response.url)
            active_base = extract_origin(final_url) or base.rstrip('/')
            if settings.get('mirror_mode', 0) == 0:
                _set_cached_mirror(active_base)
            return response.text, final_url, active_base
        except httpx.HTTPStatusError as exc:
            last_error = exc
            if exc.response is not None and exc.response.status_code == 404:
                raise
            log('Mirror %s lỗi HTTP: %s' % (base, exc), xbmc.LOGWARNING)
        except (httpx.HTTPError, OSError) as exc:
            last_error = exc
            log('Mirror %s lỗi kết nối: %s' % (base, exc), xbmc.LOGWARNING)

    raise last_error or RuntimeError('Không kết nối được tới mirror Motchill nào')


def fetch_site_soup(path_or_url, referer=None, settings=None):
    """Fetch a Motchill site page and return (BeautifulSoup, html_text, final_url, active_base_url)."""
    from bs4 import BeautifulSoup

    html_text, final_url, active_base = fetch_site_html(path_or_url, referer=referer, settings=settings)
    return BeautifulSoup(html_text, 'html.parser'), html_text, final_url, active_base
