# -*- coding: utf-8 -*-
"""HTML scrapers for Motchill listing, search, detail, and watch pages."""

import concurrent.futures
import html
import re
import urllib.parse

from bs4 import BeautifulSoup

from resources.lib.motchille import meta_cache
from resources.lib.motchille.http_client import build_headers, fetch_site_soup, get_shared_client

_MOVIE_PATH_RE = re.compile(r'^/phim/([^/]+)/?$')
_EPISODE_PATH_RE = re.compile(r'/tap-(.+?)-sv-(\d+)/?$')


def strip_html(value):
    """Strip HTML tags and normalize whitespace."""
    if not value:
        return ''
    text = BeautifulSoup(str(value), 'html.parser').get_text(' ')
    text = html.unescape(text)
    text = re.sub(r'\s+', ' ', text)
    return text.strip()


def absolute_url(url, base_url):
    """Resolve relative or protocol-relative URLs against base_url."""
    if not url:
        return ''
    url = html.unescape(str(url)).strip()
    if url.startswith('http://') or url.startswith('https://'):
        return url
    if url.startswith('//'):
        return 'https:' + url
    return urllib.parse.urljoin(base_url.rstrip('/') + '/', url.lstrip('/'))


def extract_meta_content(soup, name=None, prop=None):
    """Read a <meta name=...> or <meta property=...> content value safely."""
    if name:
        tag = soup.find('meta', attrs={'name': name})
        if tag and tag.get('content'):
            value = html.unescape(tag['content']).strip()
            if value and value != 'Array':
                return value
    if prop:
        tag = soup.find('meta', attrs={'property': prop})
        if tag and tag.get('content'):
            value = html.unescape(tag['content']).strip()
            if value and value != 'Array':
                return value
    return ''


def build_page_url(path, page):
    """Build relative page path for Motchill category/archive listings."""
    clean_path = '/' + (path or '').strip('/')
    if clean_path == '/':
        clean_path = '/phim'
    if page <= 1:
        return clean_path
    return '%s/page/%d' % (clean_path, page)


def build_search_path(keyword, page=1):
    """Build WordPress search path compatible with Motchill mirrors."""
    encoded = urllib.parse.quote_plus(keyword or '')
    if page <= 1:
        return '/?s=%s' % encoded
    return '/page/%d/?s=%s' % (page, encoded)


def has_next_page(soup, path, next_page, is_search=False):
    """Detect whether pagination links on the page contain next_page."""
    target_suffix = '/page/%d' % next_page
    if is_search:
        for anchor in soup.find_all('a', href=True):
            href = anchor.get('href', '')
            if ('paged=%d' % next_page) in href or (target_suffix in href and 's=' in href):
                return True
        return False

    clean_path = '/' + (path or '').strip('/')
    if clean_path == '/':
        clean_path = '/phim'
    expected_prefix = clean_path + target_suffix

    for anchor in soup.find_all('a', href=True):
        parsed_path = urllib.parse.urlparse(anchor.get('href', '')).path.rstrip('/')
        if parsed_path == expected_prefix or parsed_path.endswith(expected_prefix):
            return True
    return False


def _extract_img_url(tag, base_url):
    if not tag:
        return ''
    src = tag.get('data-original') or tag.get('data-src') or tag.get('src') or ''
    if src.startswith('data:'):
        src = tag.get('data-original') or tag.get('data-src') or ''
    return absolute_url(src, base_url)


def _extract_card_from_container(container, base_url):
    anchors = []
    slug = ''
    href = ''
    for anchor in container.find_all('a', href=True):
        movie_path = urllib.parse.urlparse(anchor.get('href', '')).path
        match = _MOVIE_PATH_RE.match(movie_path)
        if match:
            anchors.append(anchor)
            if not slug:
                slug = match.group(1)
                href = anchor.get('href', '')

    if not slug:
        return None

    h3 = container.find('h3')
    name_link = container.select_one('.name a, .name-title a')
    img = container.find('img')
    img_alt = (img.get('alt') if img else '') or ''
    anchor_title = next((a.get('title', '').strip() for a in anchors if a.get('title')), '')

    title = (
        strip_html(name_link.decode_contents() if name_link else '')
        or strip_html(h3.decode_contents() if h3 else '')
        or anchor_title
        or html.unescape(img_alt).strip()
    )
    if not title or title in ('Trang chủ', 'Motchill', 'PHIM MỚI'):
        return None

    orig_tag = container.select_one('.original-title-home, .real-name, p')
    original_name = strip_html(orig_tag.decode_contents() if orig_tag else '')
    if original_name == title:
        original_name = ''

    badges = []
    for span in container.select('span.label, .motchill-recommended-badges span'):
        text = strip_html(span.decode_contents())
        if text and 'Trending' not in text and text not in badges:
            badges.append(text)

    extra = ' | '.join(badges[:2])
    label = '%s [%s]' % (title, extra) if extra else title
    plot_parts = [part for part in (original_name, extra) if part]

    return {
        'href': absolute_url(href, base_url),
        'slug': slug,
        'title': title,
        'original_name': original_name,
        'thumb': _extract_img_url(img, base_url),
        'label': label,
        'plot': ' | '.join(plot_parts),
    }


def parse_movie_cards(soup, base_url):
    """Parse movie card items across motchillxv.cc and motchilltvi.net layouts."""
    results = []
    seen = set()

    containers = soup.select('li.item, div.item, article.item')
    for container in containers:
        card = _extract_card_from_container(container, base_url)
        if card and card['slug'] not in seen:
            results.append(card)
            seen.add(card['slug'])

    if results:
        return results

    # Fallback anchor scan if a listing page does not use .item wrappers.
    for anchor in soup.find_all('a', href=True):
        href = anchor.get('href', '')
        movie_path = urllib.parse.urlparse(href).path
        match = _MOVIE_PATH_RE.match(movie_path)
        if not match:
            continue

        slug = match.group(1)
        if slug in seen:
            continue

        img = anchor.find('img')
        h3 = anchor.find('h3')
        p = anchor.find('p')
        img_alt = (img.get('alt') if img else '') or ''
        title = (
            (anchor.get('title') or '').strip()
            or strip_html(h3.decode_contents() if h3 else '')
            or html.unescape(img_alt).strip()
        )
        if not title or title in ('Trang chủ', 'Motchill', 'PHIM MỚI'):
            continue

        original_name = strip_html(p.decode_contents() if p else '')
        results.append({
            'href': absolute_url(href, base_url),
            'slug': slug,
            'title': title,
            'original_name': original_name,
            'thumb': _extract_img_url(img, base_url),
            'label': title,
            'plot': original_name,
        })
        seen.add(slug)

    return results


def _split_csv(text):
    items = []
    for part in (text or '').split(','):
        cleaned = re.sub(r'\s+', ' ', part).strip()
        if cleaned and 'đang cập nhật' not in cleaned.lower():
            items.append(cleaned)
    return items


def _parse_dinfo(soup):
    info = {
        'year': 0,
        'duration': 0,
        'genres': [],
        'countries': [],
        'directors': [],
        'cast': [],
        'status': '',
    }
    dinfo = soup.select_one('.dinfo')
    if not dinfo:
        return info

    for dt in dinfo.find_all('dt'):
        dd = dt.find_next_sibling('dd')
        if not dd:
            continue
        key = strip_html(dt.decode_contents()).rstrip(':').lower()
        val = strip_html(dd.decode_contents())
        if not val:
            continue

        if 'trạng thái' in key:
            info['status'] = val
        elif 'thời lượng' in key:
            m = re.search(r'(\d+)\s*phút', val, re.IGNORECASE)
            if m:
                info['duration'] = int(m.group(1)) * 60
        elif 'năm' in key:
            m = re.search(r'(19\d{2}|20\d{2})', val)
            if m:
                info['year'] = int(m.group(1))
        elif 'quốc gia' in key:
            info['countries'] = _split_csv(val)
        elif 'thể loại' in key:
            info['genres'] = _split_csv(val)
        elif 'đạo diễn' in key:
            info['directors'] = _split_csv(val)
        elif 'diễn viên' in key:
            info['cast'] = _split_csv(val)

    return info


def _find_watch_url(slug, soup, base_url):
    watch_re = re.compile(r'^/(?:xem-)?phim/' + re.escape(slug) + r'/tap-[^/]+/?$')
    for anchor in soup.find_all('a', href=True):
        path = urllib.parse.urlparse(anchor.get('href', '')).path
        if watch_re.match(path):
            return absolute_url(anchor.get('href'), base_url)
    return ''


def _collect_server_labels(watch_soup):
    """Map sv index string ('0', '1', ...) to human-readable server names."""
    btn_labels = {}
    for btn in watch_soup.select('[data-link][data-server]'):
        sv = str(btn.get('data-server', '')).strip()
        text = re.sub(r'\s+', ' ', btn.get_text(' ', strip=True)).strip()
        if sv and text and sv not in btn_labels:
            btn_labels[sv] = text

    sibling_labels = {}
    for ep_div in watch_soup.select('div.episodes'):
        prev = ep_div.find_previous_sibling()
        heading = re.sub(r'\s+', ' ', prev.get_text(' ', strip=True)).strip(': ') if prev else ''
        if not heading:
            continue
        for anchor in ep_div.find_all('a', href=True):
            match = _EPISODE_PATH_RE.search(urllib.parse.urlparse(anchor.get('href', '')).path)
            if match:
                sv = match.group(2)
                sibling_labels.setdefault(sv, heading)
                break

    labels = {}
    all_svs = set(btn_labels) | set(sibling_labels)
    for sv in all_svs:
        num = int(sv) + 1
        sib = sibling_labels.get(sv, '')
        btn = btn_labels.get(sv, '')
        # Prefer descriptive language heading ('Vietsub', 'Thuyết Minh') or specific button label.
        if sib and not sib.lower().startswith('vip'):
            labels[sv] = 'Server %d (%s)' % (num, sib)
        elif btn:
            labels[sv] = 'Server %d - %s' % (num, btn)
        elif sib:
            labels[sv] = 'Server %d - %s' % (num, sib)
        else:
            labels[sv] = 'Server %d' % num
    return labels


def extract_watch_episodes(slug, detail_soup, base_url):
    """Load the watch page once and return grouped episode entries per server."""
    watch_url = _find_watch_url(slug, detail_soup, base_url)
    if not watch_url:
        return []

    detail_referer = base_url.rstrip('/') + '/phim/' + slug
    watch_soup, _, _, active_base = fetch_site_soup(watch_url, referer=detail_referer)
    server_labels = _collect_server_labels(watch_soup)

    episodes = []
    seen_paths = set()
    ep_prefix_re = re.compile(r'^/(?:xem-)?phim/' + re.escape(slug) + r'/tap-(.+?)-sv-(\d+)/?$')

    containers = watch_soup.select('div.episodes') or [watch_soup]
    for container in containers:
        for anchor in container.find_all('a', href=True):
            href = absolute_url(anchor.get('href'), active_base)
            parsed = urllib.parse.urlparse(href)
            norm_path = parsed.path.rstrip('/')
            match = ep_prefix_re.match(parsed.path)
            if not match or norm_path in seen_paths:
                continue

            sv = match.group(2)
            ep_name = anchor.get_text(' ', strip=True) or match.group(1)
            server_name = server_labels.get(sv, 'Server %d' % (int(sv) + 1))

            episodes.append({
                'name': ep_name,
                'link': href,
                'type': 'watch',
                'server_index': int(sv),
                'server': server_name,
            })
            seen_paths.add(norm_path)

    return episodes


def episode_sort_key(item):
    """Natural sort key for episode names."""
    name = str(item.get('name') or '')
    match = re.search(r'(\d+)', name)
    if match:
        return (0, int(match.group(1)), name)
    return (1, 0, name)


def group_episodes_by_server(episodes):
    """Group episode dicts into an ordered list of (server_name, sorted_episodes)."""
    by_server = {}
    server_order = {}
    for ep in episodes:
        srv = ep['server']
        by_server.setdefault(srv, []).append(ep)
        server_order.setdefault(srv, ep.get('server_index', 99))

    ordered_servers = sorted(by_server.keys(), key=lambda name: (server_order[name], name))
    return [(srv, sorted(by_server[srv], key=episode_sort_key)) for srv in ordered_servers]


_META_CACHE_FIELDS = (
    'title',
    'original_name',
    'plot',
    'fanart',
    'year',
    'duration',
    'genres',
    'countries',
    'directors',
    'cast',
    'status',
)


def _extract_meta_from_soup(soup, fallback_title, active_base):
    """Extract rich movie metadata fields from a parsed detail BeautifulSoup tree."""
    title_tag = soup.find('h1')
    title = strip_html(title_tag.decode_contents() if title_tag else '') or fallback_title

    orig_tag = (
        soup.select_one('.real-name')
        or soup.find('h2', class_=re.compile(r'text-gray-400'))
        or soup.select_one('.info h2')
    )
    raw_orig = strip_html(orig_tag.decode_contents() if orig_tag else '')
    if raw_orig.lower() == 'phim đề cử':
        raw_orig = ''

    orig_year = 0
    year_tail = re.search(r'\s*\((19\d{2}|20\d{2})\)\s*$', raw_orig)
    if year_tail:
        orig_year = int(year_tail.group(1))
        raw_orig = raw_orig[:year_tail.start()].strip()

    dinfo = _parse_dinfo(soup)
    if not dinfo['year'] and orig_year:
        dinfo['year'] = orig_year

    plot_tag = (
        soup.select_one('#info-film .tab')
        or soup.select_one('#info-film')
        or soup.select_one('.film-content, .the-article, article, .entry-content')
    )
    plot = strip_html(plot_tag.decode_contents() if plot_tag else '')
    if plot:
        plot = re.sub(r'^Nội dung phim(?:\s+' + re.escape(title) + r')?\s*:?\s*', '', plot, flags=re.IGNORECASE).strip()
    if not plot:
        plot = extract_meta_content(soup, name='description')

    poster_tag = soup.select_one('.poster img, .limage img, [itemprop="image"]')
    poster = _extract_img_url(poster_tag, active_base)
    og_image = extract_meta_content(soup, prop='og:image') or extract_meta_content(soup, name='twitter:image')
    fanart = absolute_url(og_image, active_base) if og_image else poster
    if not poster:
        poster = fanart

    return {
        'title': title,
        'original_name': raw_orig,
        'plot': plot,
        'thumb': poster,
        'fanart': fanart,
        'year': dinfo['year'],
        'duration': dinfo['duration'],
        'genres': dinfo['genres'],
        'countries': dinfo['countries'],
        'directors': dinfo['directors'],
        'cast': dinfo['cast'],
        'status': dinfo['status'],
    }


def _slice_detail_fragments(html_text):
    """Extract only relevant HTML fragments to keep BeautifulSoup CPU overhead minimal."""
    if not html_text:
        return ''
    parts = []
    head_end = html_text.find('</head>')
    if 0 < head_end < 30000:
        parts.append(html_text[:head_end + 7])

    for marker, span in (
        ('<h1', 1500),
        ('class="real-name"', 600),
        ('class="info"', 1500),
        ('class="dinfo"', 4000),
        ('id="info-film"', 8000),
        ('class="film-content"', 8000),
        ('<article', 8000),
    ):
        idx = html_text.find(marker)
        if idx >= 0:
            tag_start = html_text.rfind('<', max(0, idx - 200), idx + 1)
            start = tag_start if tag_start >= 0 else idx
            parts.append(html_text[start:idx + span])
    return '\n'.join(parts)


def parse_detail_metadata_fast(html_text, fallback_title='', base_url=''):
    """Parse movie synopsis and metadata from a detail page without parsing the full DOM."""
    mini_html = _slice_detail_fragments(html_text)
    mini_soup = BeautifulSoup(mini_html, 'html.parser')
    return _extract_meta_from_soup(mini_soup, fallback_title, base_url)


def _merge_card_metadata(movie, meta, active_base):
    if not meta:
        return
    if meta.get('plot'):
        movie['plot'] = meta['plot']
    if meta.get('original_name'):
        movie['original_name'] = meta['original_name']
    for key in ('status', 'year', 'duration', 'genres', 'countries', 'directors', 'cast'):
        if meta.get(key):
            movie[key] = meta[key]
    fanart = meta.get('fanart') or ''
    active_host = urllib.parse.urlsplit(active_base or '').netloc.lower()
    fanart_host = urllib.parse.urlsplit(fanart).netloc.lower()
    if fanart and (not active_host or not fanart_host or fanart_host == active_host):
        movie['fanart'] = fanart
    elif not movie.get('fanart'):
        movie['fanart'] = movie.get('thumb', '')


def enrich_movie_cards(movies, active_base, settings=None):
    """Attach synopsis, metadata, and fanart to listing cards using SQLite cache + HTTP/2 batching."""
    if not movies:
        return movies
    if settings and not settings.get('preload_movie_info', True):
        return movies

    slugs = [movie['slug'] for movie in movies if movie.get('slug')]
    cached = meta_cache.get_many(slugs)
    missing = [movie for movie in movies if movie.get('slug') and movie['slug'] not in cached]

    newly_fetched = {}
    if missing:
        base_clean = (active_base or '').rstrip('/')
        shared_timeout = int((settings or {}).get('timeout', 10))
        client = get_shared_client(shared_timeout)
        headers = build_headers(referer=base_clean + '/', origin=base_clean)

        def _fetch_one(card):
            slug = card['slug']
            resp = client.get('%s/phim/%s' % (base_clean, slug), headers=headers, timeout=4.0)
            resp.raise_for_status()
            meta = parse_detail_metadata_fast(resp.text, fallback_title=card.get('title', slug), base_url=base_clean)
            return slug, {key: meta[key] for key in _META_CACHE_FIELDS if key in meta}

        executor = concurrent.futures.ThreadPoolExecutor(max_workers=8)
        try:
            future_map = {executor.submit(_fetch_one, card): card['slug'] for card in missing}
            done, _ = concurrent.futures.wait(future_map.keys(), timeout=5.5)
            for future in done:
                try:
                    slug, meta = future.result()
                    if meta.get('plot') or meta.get('year') or meta.get('genres'):
                        newly_fetched[slug] = meta
                except Exception:
                    pass
        finally:
            executor.shutdown(wait=False)

        if newly_fetched:
            meta_cache.put_many(newly_fetched)

    combined = dict(cached)
    combined.update(newly_fetched)
    for movie in movies:
        meta = combined.get(movie.get('slug'))
        if meta:
            _merge_card_metadata(movie, meta, active_base)
    return movies


def load_movie_detail(slug):
    """Fetch and parse movie metadata plus episode list from the detail and watch pages."""
    detail_soup, _, final_url, active_base = fetch_site_soup('/phim/' + slug)
    meta = _extract_meta_from_soup(detail_soup, slug, active_base)
    meta_cache.put_many({slug: {key: meta[key] for key in _META_CACHE_FIELDS if key in meta}})

    episodes = extract_watch_episodes(slug, detail_soup, active_base)

    result = dict(meta)
    result['slug'] = slug
    result['url'] = final_url
    result['episodes'] = episodes
    return result


def _is_dub_button(label, slot):
    text = ((label or '') + ' ' + (slot or '')).lower()
    return any(kw in text for kw in ('thuyết minh', 'thuyet minh', 'lồng tiếng', 'long tieng', 'dub'))


def _candidate_priority(cand):
    url_lower = (cand.get('link') or '').lower()
    src = cand.get('data_source') or ''
    stype = cand.get('source_type') or ''
    if stype == 'm3u8' or '.m3u8' in url_lower:
        if 'streamvsmov.com' in url_lower:
            return 1
        return 0
    if 'streamvsmov.com' in url_lower or src in ('vs', 'vsmov', 'embed_vs'):
        return 2
    if 'vicdn.cc' in url_lower or src == 'vieflix':
        return 3
    if 'streamc.xyz' in url_lower or src == 'nguonc':
        return 4
    return 5


def extract_watch_candidates(watch_html, watch_url):
    """Extract ordered stream source candidates for the requested watch page URL.

    On mirrors where all server buttons share the HTML (e.g. motchillxv.cc),
    only buttons matching the URL's `-sv-N` server index are placed first,
    followed by same-language backups so Thuyết Minh never silently falls back to Vietsub.
    """
    soup = BeautifulSoup(watch_html, 'html.parser')
    sv_match = re.search(r'-sv-(\d+)/?$', urllib.parse.urlsplit(watch_url).path)
    target_sv = sv_match.group(1) if sv_match else None

    all_buttons = []
    seen_links = set()
    for el in soup.select('[data-link]'):
        raw_link = html.unescape((el.get('data-link') or '').strip()).replace('\\/', '/')
        if not raw_link:
            continue
        link = absolute_url(raw_link, watch_url)
        if link in seen_links:
            continue
        seen_links.add(link)

        label = re.sub(r'\s+', ' ', el.get_text(' ', strip=True)).strip() or 'Nguồn phát'
        slot = (el.get('data-slot') or '').lower()
        sub = el.get('data-subtitle') or ''
        all_buttons.append({
            'label': label,
            'link': link,
            'source_type': (el.get('data-type') or '').lower(),
            'data_source': (el.get('data-source') or '').lower(),
            'data_server': str(el.get('data-server')).strip() if el.get('data-server') is not None else None,
            'data_slot': slot,
            'subtitle': absolute_url(sub, watch_url) if sub else '',
            'watch_url': watch_url,
            'is_dub': _is_dub_button(label, slot),
        })

    if not all_buttons:
        match = re.search(r'data-link=["\']([^"\']+)["\']', watch_html, re.IGNORECASE)
        if not match:
            match = re.search(r'["\'](https?:\\?/\\?/[^"\']+\.m3u8[^"\']*)["\']', watch_html, re.IGNORECASE)
        if match:
            link = absolute_url(match.group(1).replace('\\/', '/'), watch_url)
            all_buttons.append({
                'label': 'Mặc định',
                'link': link,
                'source_type': 'm3u8' if '.m3u8' in link.lower() else 'embed',
                'data_source': '',
                'data_server': None,
                'data_slot': '',
                'subtitle': '',
                'watch_url': watch_url,
                'is_dub': False,
            })
        return all_buttons

    has_server_attr = any(btn['data_server'] is not None for btn in all_buttons)
    if target_sv is not None and has_server_attr:
        primary = [btn for btn in all_buttons if btn['data_server'] == target_sv]
        if primary:
            target_is_dub = any(btn['is_dub'] for btn in primary)
            backups = [
                btn for btn in all_buttons
                if btn['data_server'] != target_sv and btn['is_dub'] == target_is_dub
            ]
            backups.sort(key=_candidate_priority)
            return primary + backups

    all_buttons.sort(key=_candidate_priority)
    return all_buttons
