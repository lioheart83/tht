# -*- coding: utf-8 -*-
"""Configuration, static taxonomy catalogs, and Kodi helper utilities."""

import os
import sys

import xbmc
import xbmcaddon
import xbmcvfs

_LIB_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _LIB_DIR not in sys.path:
    sys.path.insert(0, _LIB_DIR)

ADDON_ID = 'plugin.video.motchille'

DEFAULT_MIRRORS = (
    'https://motchillxv.cc',
    'https://motchilltvi.net',
    'https://motchillr.one',
    'https://motchille.net',
)

MIRROR_MODES = {
    1: 'https://motchillxv.cc',
    2: 'https://motchilltvi.net',
}

USER_AGENT = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/138.0.0.0 Safari/537.36'
)

DEFAULT_HEADERS = {
    'User-Agent': USER_AGENT,
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7',
}

WINDOW_PROP_MIRROR = 'motchille.active_mirror'
WINDOW_PROP_PROXY = 'motchille.proxy_info'
MIRROR_TTL_SECONDS = 1800

GENRES = [
    ('Hành động', 'hanh-dong'),
    ('Tình cảm', 'tinh-cam'),
    ('Hài hước', 'hai-huoc'),
    ('Cổ trang', 'co-trang'),
    ('Tâm lý', 'tam-ly'),
    ('Hình sự', 'hinh-su'),
    ('Chiến tranh', 'chien-tranh'),
    ('Thể thao', 'the-thao'),
    ('Võ thuật', 'vo-thuat'),
    ('Viễn tưởng', 'vien-tuong'),
    ('Phiêu lưu', 'phieu-luu'),
    ('Khoa học', 'khoa-hoc'),
    ('Kinh dị', 'kinh-di'),
    ('Âm nhạc', 'am-nhac'),
    ('Thần thoại', 'than-thoai'),
    ('Tài liệu', 'tai-lieu'),
    ('Gia đình', 'gia-dinh'),
    ('Chính kịch', 'chinh-kich'),
    ('Bí ẩn', 'bi-an'),
    ('Học đường', 'hoc-duong'),
    ('Kinh điển', 'kinh-dien'),
    ('Đời thường', 'doi-thuong'),
    ('Giả tưởng', 'gia-tuong'),
    ('Kỳ ảo', 'ky-ao'),
    ('Lãng mạn', 'lang-man'),
    ('Lịch sử', 'lich-su'),
    ('Miền Tây', 'mien-tay'),
    ('Trẻ em', 'tre-em'),
    ('Phim 18+', 'phim-18'),
    ('Hoạt hình', 'hoat-hinh'),
    ('TV Shows', 'tv-shows'),
]

COUNTRIES = [
    ('Trung Quốc', 'trung-quoc'),
    ('Hàn Quốc', 'han-quoc'),
    ('Nhật Bản', 'nhat-ban'),
    ('Thái Lan', 'thai-lan'),
    ('Âu Mỹ', 'au-my'),
    ('Việt Nam', 'viet-nam'),
    ('Đài Loan', 'dai-loan'),
    ('Hong Kong', 'hong-kong'),
    ('Ấn Độ', 'an-do'),
    ('Anh', 'anh'),
    ('Pháp', 'phap'),
    ('Canada', 'canada'),
    ('Philippines', 'philippines'),
    ('Tây Ban Nha', 'tay-ban-nha'),
    ('Ý', 'y'),
    ('Nga', 'nga'),
    ('Quốc gia khác', 'quoc-gia-khac'),
]

YEARS = [(str(year), str(year)) for year in range(2026, 2009, -1)]


def get_addon():
    """Return a fresh Addon instance so settings stay current under reuselanguageinvoker."""
    return xbmcaddon.Addon(ADDON_ID)


def _safe_int(value, default):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _safe_bool(value, default=True):
    if isinstance(value, bool):
        return value
    text = str(value or '').strip().lower()
    if text in ('true', '1', 'yes'):
        return True
    if text in ('false', '0', 'no'):
        return False
    return default


def normalize_origin(domain):
    """Normalize a user-entered mirror domain into a bare https://host origin."""
    text = (domain or '').strip().rstrip('/')
    if not text:
        return ''
    if not text.startswith('http://') and not text.startswith('https://'):
        text = 'https://' + text
    return text


def get_settings():
    """Read current addon settings into a normalized dictionary."""
    addon = get_addon()
    mirror_mode = _safe_int(addon.getSetting('mirror_mode'), 0)
    custom_domain = normalize_origin(addon.getSetting('custom_domain'))
    timeout = max(4, min(30, _safe_int(addon.getSetting('request_timeout'), 10)))
    prefer_quality = _safe_int(addon.getSetting('prefer_quality'), 0)
    strip_hls_ads = _safe_bool(addon.getSetting('strip_hls_ads'), True)
    auto_subtitles = _safe_bool(addon.getSetting('auto_subtitles'), True)
    vicdn_audio = _safe_int(addon.getSetting('vicdn_audio'), 0)
    preload_movie_info = _safe_bool(addon.getSetting('preload_movie_info'), True)
    return {
        'mirror_mode': mirror_mode,
        'custom_domain': custom_domain,
        'timeout': timeout,
        'prefer_low_bandwidth': prefer_quality == 1,
        'strip_hls_ads': strip_hls_ads,
        'auto_subtitles': auto_subtitles,
        'vicdn_audio': vicdn_audio,
        'preload_movie_info': preload_movie_info,
    }


def translate_path(path):
    """Cross-version Kodi special:// path translation."""
    translator = getattr(xbmcvfs, 'translatePath', None)
    if translator is None:
        translator = getattr(xbmc, 'translatePath', None)
    if translator is not None:
        return translator(path)
    return path


def log(message, level=xbmc.LOGINFO):
    """Write a prefixed message to Kodi's log."""
    xbmc.log('[Motchille] ' + str(message), level)
