# -*- coding: utf-8 -*-
"""Stream resolvers for direct HLS, streamvsmov.com, streamc.xyz, and vicdn.cc."""

import base64
import hashlib
import hmac
import html
import json
import re
import urllib.parse

import xbmc

from resources.lib.aesgcm import decrypt as aesgcm_decrypt
from resources.lib.motchille.config import USER_AGENT, get_settings, log
from resources.lib.motchille.hls_cleaner import clean_hls_manifest, select_hls_variant_url
from resources.lib.motchille.http_client import build_headers, extract_origin, fetch_site_html, fetch_url, get_shared_client
from resources.lib.motchille.subtitles import build_subtitle_files

_PACKED_RE = re.compile(
    r"eval\(function\(p,a,c,k,e,[dr]\)\{.*?\}\('(.*?)',(\d+),(\d+),'(.*?)'\.split\('\|'\)",
    re.DOTALL,
)
_ALPHABET = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'


def unwrap_player_url(url):
    """Extract inner stream URL from known iframe wrappers like phimapi or goplayer."""
    current = html.unescape((url or '').strip())
    for _ in range(3):
        parsed = urllib.parse.urlsplit(current)
        host = parsed.netloc.lower()
        if 'phimapi.com' in host or 'goplayer.xyz' in host or '/player/' in parsed.path:
            params = urllib.parse.parse_qs(parsed.query)
            inner = (params.get('url') or [''])[0]
            if inner and (inner.startswith('http://') or inner.startswith('https://')):
                current = inner
                continue
        break
    return current


def _unpack_dean_edwards(html_text):
    """Unpack Dean Edwards p,a,c,k,e,d obfuscated JavaScript blocks."""
    blocks = []
    for match in _PACKED_RE.finditer(html_text or ''):
        payload = match.group(1).replace("\\'", "'").replace('\\"', '"').replace('\\\\', '\\')
        radix = int(match.group(2))
        keywords = match.group(4).split('|')
        valid_digits = _ALPHABET[:radix]

        def _replace(word_match):
            word = word_match.group(0)
            index = 0
            for ch in word:
                if ch not in valid_digits:
                    return word
                index = (index * radix) + _ALPHABET.index(ch)
            if 0 <= index < len(keywords) and keywords[index]:
                return keywords[index]
            return word

        blocks.append(re.sub(r'\b\w+\b', _replace, payload))
    return '\n'.join(blocks)


def _fetch_vtt_text(url, referer, timeout):
    if not url:
        return ''
    try:
        resp = fetch_url(url, referer=referer, accept='text/vtt,text/plain,*/*', retries=1, timeout=timeout)
        return resp.text
    except Exception as exc:
        log('Không tải được phụ đề VTT %s: %s' % (url, exc), xbmc.LOGWARNING)
        return ''


def _resolve_hls_manifest_and_clean(manifest_url, headers, settings):
    """Fetch master/media HLS manifest, pick variant, and strip injected discontinuity ads."""
    client = get_shared_client(settings['timeout'])
    resp = client.get(manifest_url, headers=headers)
    resp.raise_for_status()
    text = resp.text
    current_url = str(resp.url)

    if '#EXT-X-STREAM-INF' in text:
        variant_url = select_hls_variant_url(text, current_url, settings['prefer_low_bandwidth'])
        if variant_url:
            v_resp = client.get(variant_url, headers=headers)
            v_resp.raise_for_status()
            text = v_resp.text
            current_url = str(v_resp.url)

    if '#EXTM3U' not in text:
        raise ValueError('Playlist HLS không hợp lệ')

    cleaned, removed = clean_hls_manifest(text, current_url, strip_ads=settings['strip_hls_ads'])
    if removed:
        log('Đã lọc %d segment quảng cáo khỏi HLS manifest' % removed)
    return cleaned, current_url


def _resolve_vsmov(url, referer_site, settings, extra_subtitle=''):
    """Resolve v*.streamvsmov.com video page or master.m3u8 plus WebVTT subtitles."""
    parsed = urllib.parse.urlsplit(url)
    origin = '%s://%s' % (parsed.scheme, parsed.netloc)
    hash_match = re.search(r'/(?:video|stream)/([\w-]+)', parsed.path)
    if not hash_match:
        raise ValueError('URL StreamVSMov không hợp lệ: ' + url)

    video_id = hash_match.group(1)
    video_page_url = '%s/video/%s' % (origin, video_id)
    master_url = '%s/stream/%s/master.m3u8' % (origin, video_id)

    sub_paths = []
    if settings['auto_subtitles']:
        vi_vtt = ''
        vi_url = ''

        try:
            page_resp = fetch_url(video_page_url, referer=referer_site, retries=1, timeout=settings['timeout'])
            raw_vtts = re.findall(r'["\']([^"\']*?/subtitle/[^"\']+\.vtt[^"\']*)["\']', page_resp.text)
            for raw_sub in raw_vtts:
                full_sub = urllib.parse.urljoin(origin + '/', raw_sub)
                lower_sub = full_sub.lower()
                if ('/vie_' in lower_sub or 'vietsub' in lower_sub) and not vi_url:
                    vi_url = full_sub
                    break
        except Exception as exc:
            log('Không đọc được trang phụ đề VSMov: %s' % exc, xbmc.LOGWARNING)

        if not vi_url and extra_subtitle:
            vi_url = extra_subtitle

        if vi_url:
            vi_vtt = _fetch_vtt_text(vi_url, video_page_url, settings['timeout'])
        if vi_vtt:
            sub_paths = build_subtitle_files('vsmov_' + video_id, vi_vtt=vi_vtt)

    headers = build_headers(referer=referer_site)
    cleaned_manifest, final_manifest_url = _resolve_hls_manifest_and_clean(master_url, headers, settings)

    return {
        'manifest_text': cleaned_manifest,
        'manifest_url': final_manifest_url,
        'headers': {'User-Agent': USER_AGENT, 'Referer': referer_site},
        'needs_segment_proxy': True,
        'segment_ext': 'ts',
        'subtitles': sub_paths,
        'is_hls': True,
        'provider_label': 'StreamVSMov',
    }


def _resolve_streamc(embed_url, site_origin, settings):
    """Resolve embed*.streamc.xyz via HTTP/2 bootstrap and AES-256-GCM decryption."""
    parsed = urllib.parse.urlsplit(embed_url)
    embed_origin = '%s://%s' % (parsed.scheme, parsed.netloc)
    site_ref = site_origin.rstrip('/') + '/'
    client = get_shared_client(max(settings['timeout'], 15))

    body = {
        'action': 'bootstrap',
        'referrer': site_ref,
        'frame_origins': [site_origin.rstrip('/')],
        'request_grant': True,
        'playlist_format': 'aesgcm-v2',
        'pretty_url': True,
        'path_chunks': True,
        'bootstrap_format': 'aesgcm-v1',
    }
    boot_headers = {
        'User-Agent': USER_AGENT,
        'Accept': 'application/json, text/plain, */*',
        'Accept-Language': 'vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7',
        'Content-Type': 'application/json',
        'Referer': site_ref,
        'Origin': embed_origin,
    }
    resp = client.post(embed_url, headers=boot_headers, json=body)
    resp.raise_for_status()
    envelope = resp.json()

    if envelope.get('format') == 'aesgcm-v1':
        associated_data = ('stream-bootstrap-v1\n' + embed_url).encode('utf-8')
        key = hashlib.sha256(associated_data).digest()
        plaintext = aesgcm_decrypt(
            key,
            bytes.fromhex(envelope['iv']),
            base64.b64decode(envelope['data']),
            associated_data,
        )
        grant = json.loads(plaintext.decode('utf-8'))
    else:
        grant = envelope

    video_hash = grant.get('video') or (urllib.parse.parse_qs(parsed.query).get('hash') or [''])[0]
    playlist_url = (grant.get('preissued') or {}).get('playlist') or ''
    if not playlist_url:
        raise ValueError('StreamC không trả về playlist')

    pl_resp = client.get(playlist_url, headers={
        'User-Agent': USER_AGENT,
        'Referer': embed_url,
        'Accept': 'application/vnd.apple.mpegurl,*/*;q=0.8',
    })
    pl_resp.raise_for_status()
    manifest_text = pl_resp.text

    if '#ENC-AESGCM' in manifest_text:
        iv_match = re.search(r'#ENC-AESGCM;iv=([0-9a-fA-F]+)', manifest_text)
        payload = next(
            (line.strip() for line in manifest_text.splitlines() if line.strip() and not line.startswith('#')),
            '',
        )
        if not video_hash or not iv_match or not payload:
            raise ValueError('Manifest StreamC thiếu dữ liệu giải mã')
        key = hmac.new(b'stream-derive-v1', video_hash.encode('utf-8'), hashlib.sha256).digest()
        manifest_text = aesgcm_decrypt(
            key,
            bytes.fromhex(iv_match.group(1)),
            base64.b64decode(payload),
        ).decode('utf-8')

    if '#EXTM3U' not in manifest_text:
        raise ValueError('Manifest StreamC sau giải mã không hợp lệ')

    cleaned_manifest, _ = clean_hls_manifest(manifest_text, playlist_url, strip_ads=settings['strip_hls_ads'])
    return {
        'manifest_text': cleaned_manifest,
        'manifest_url': playlist_url,
        'headers': {'User-Agent': USER_AGENT, 'Referer': embed_url, 'Origin': embed_origin},
        'needs_segment_proxy': True,
        'segment_ext': 'ts',
        'subtitles': [],
        'is_hls': True,
        'provider_label': 'StreamC',
    }


def _decrypt_vicdn_payload(raw_text, secret_key):
    if '#ENC-AESGCM' not in raw_text:
        return raw_text
    iv_match = re.search(r'#ENC-AESGCM;iv=([0-9a-fA-F]+)', raw_text)
    payload_lines = [line.strip() for line in raw_text.splitlines() if line.strip() and not line.startswith('#')]
    if not iv_match or not payload_lines:
        raise ValueError('Dữ liệu mã hóa ViCDN không hợp lệ')
    return aesgcm_decrypt(
        secret_key,
        bytes.fromhex(iv_match.group(1)),
        base64.b64decode(payload_lines[-1]),
    ).decode('utf-8')


def _resolve_vicdn(embed_url, site_origin, settings, audio_override=None):
    """Resolve vicdn.cc dual-language player (multi-audio + AES-GCM manifest & bilingual subtitles)."""
    parsed = urllib.parse.urlsplit(embed_url)
    origin = '%s://%s' % (parsed.scheme, parsed.netloc)
    site_ref = site_origin.rstrip('/') + '/'
    resp = fetch_url(embed_url, referer=site_ref, timeout=settings['timeout'])

    unpacked = _unpack_dean_edwards(resp.text)
    if not unpacked:
        raise ValueError('Không giải mã được player ViCDN')

    secret_match = re.search(r"AES_SECRET\s*=\s*['\"]([^'\"]+)['\"]", unpacked)
    secret = secret_match.group(1) if secret_match else 'vicdn_cc_key'
    aes_key = hashlib.sha256(secret.encode('utf-8')).digest()

    audio_sources = {}
    for match in re.finditer(r"AUDIO_SOURCES\.(\w+)\s*=\s*['\"]([^'\"]+)['\"]", unpacked):
        audio_sources[match.group(1)] = urllib.parse.urljoin(origin + '/', match.group(2))

    if not audio_sources:
        raise ValueError('Không tìm thấy luồng âm thanh trên ViCDN')

    preferred_keys = {0: 'original', 1: 'female', 2: 'male'}
    chosen_key = audio_override or preferred_keys.get(settings['vicdn_audio'], 'original')
    if chosen_key not in audio_sources:
        chosen_key = next(iter(('original', 'female', 'male') if 'original' in audio_sources else audio_sources))
        if chosen_key not in audio_sources:
            chosen_key = next(iter(audio_sources))

    hls_url = audio_sources[chosen_key]
    hls_resp = fetch_url(hls_url, referer=embed_url, timeout=settings['timeout'])
    manifest_text = _decrypt_vicdn_payload(hls_resp.text, aes_key)
    if '#EXTM3U' not in manifest_text:
        raise ValueError('Manifest ViCDN không hợp lệ')

    cleaned_manifest, _ = clean_hls_manifest(manifest_text, hls_url, strip_ads=settings['strip_hls_ads'])

    sub_paths = []
    if settings['auto_subtitles']:
        vi_match = re.search(r"VTT_VI_URL\s*=\s*['\"]([^'\"]+)['\"]", unpacked)
        vi_vtt = ''
        if vi_match and vi_match.group(1):
            raw_vi = _fetch_vtt_text(urllib.parse.urljoin(origin + '/', vi_match.group(1)), embed_url, settings['timeout'])
            if raw_vi:
                try:
                    vi_vtt = _decrypt_vicdn_payload(raw_vi, aes_key)
                except Exception:
                    vi_vtt = raw_vi
        if vi_vtt:
            sub_paths = build_subtitle_files('vicdn_' + parsed.path.strip('/'), vi_vtt=vi_vtt)

    audio_names = {'original': 'Audio Gốc', 'female': 'T.Minh Nữ', 'male': 'T.Minh Nam'}
    return {
        'manifest_text': cleaned_manifest,
        'manifest_url': hls_url,
        'headers': {'User-Agent': USER_AGENT, 'Referer': embed_url, 'Origin': origin},
        'needs_segment_proxy': True,
        'segment_ext': 'm4s',
        'subtitles': sub_paths,
        'is_hls': True,
        'provider_label': 'ViCDN (%s)' % audio_names.get(chosen_key, chosen_key),
    }


def _resolve_direct_hls(stream_url, site_origin, settings, extra_subtitle=''):
    """Resolve standard .m3u8 streams, strip injected ads, and decide if segment proxying is needed."""
    site_ref = site_origin.rstrip('/') + '/'
    headers = build_headers(referer=site_ref)
    cleaned_manifest, final_manifest_url = _resolve_hls_manifest_and_clean(stream_url, headers, settings)

    sub_paths = []
    if settings['auto_subtitles'] and extra_subtitle:
        vi_vtt = _fetch_vtt_text(extra_subtitle, site_ref, settings['timeout'])
        if vi_vtt:
            sub_paths = build_subtitle_files('sub_' + stream_url, vi_vtt=vi_vtt)

    needs_seg_proxy = '/player/master/' in stream_url.lower()
    return {
        'manifest_text': cleaned_manifest,
        'manifest_url': final_manifest_url,
        'headers': {'User-Agent': USER_AGENT, 'Referer': site_ref, 'Origin': site_origin.rstrip('/')},
        'needs_segment_proxy': needs_seg_proxy,
        'segment_ext': 'ts',
        'subtitles': sub_paths,
        'is_hls': True,
        'provider_label': 'HLS Trực tiếp',
    }


def resolve_candidate(candidate, site_origin, settings, audio_override=None):
    """Resolve a single candidate dict into a playable stream descriptor."""
    url = unwrap_player_url(candidate.get('link', ''))
    source_type = (candidate.get('source_type') or '').lower()
    extra_sub = candidate.get('subtitle') or ''
    lower = url.lower()

    if not url:
        raise ValueError('Link nguồn phát rỗng')

    if 'streamc.xyz/' in lower:
        return _resolve_streamc(url, site_origin, settings)
    if 'streamvsmov.com/' in lower:
        return _resolve_vsmov(url, site_origin.rstrip('/') + '/', settings, extra_subtitle=extra_sub)
    if 'vicdn.cc/' in lower:
        return _resolve_vicdn(url, site_origin, settings, audio_override=audio_override)
    if source_type in ('m3u8', 'hls', 'hlsjs') or '.m3u8' in lower or '/player/master/' in lower:
        return _resolve_direct_hls(url, site_origin, settings, extra_subtitle=extra_sub)

    return {
        'direct_url': url,
        'headers': {'User-Agent': USER_AGENT, 'Referer': site_origin.rstrip('/') + '/'},
        'needs_segment_proxy': False,
        'subtitles': [],
        'is_hls': False,
        'provider_label': candidate.get('label') or 'Direct',
    }


def fetch_watch_candidates(raw_link, source_type='', settings=None):
    """Fetch watch page (if watch URL) and return (candidates, site_origin)."""
    from resources.lib.motchille.scraper import extract_watch_candidates

    if settings is None:
        settings = get_settings()

    if source_type == 'watch':
        html_text, final_url, active_base = fetch_site_html(raw_link, settings=settings)
        candidates = extract_watch_candidates(html_text, final_url)
        return candidates, active_base

    origin = extract_origin(raw_link) or 'https://motchillxv.cc'
    return [{
        'label': 'Mặc định',
        'link': raw_link,
        'source_type': source_type,
        'data_source': '',
        'data_server': None,
        'data_slot': '',
        'subtitle': '',
        'watch_url': raw_link,
        'is_dub': False,
    }], origin


def resolve_with_failover(raw_link, source_type='', settings=None, candidate_index=None, audio_override=None):
    """Resolve the selected watch source, automatically trying backup candidates on error."""
    if settings is None:
        settings = get_settings()

    candidates, site_origin = fetch_watch_candidates(raw_link, source_type=source_type, settings=settings)
    if not candidates:
        raise ValueError('Không tìm thấy nguồn phát trên trang xem phim')

    if candidate_index is not None and 0 <= candidate_index < len(candidates):
        ordered = [candidates[candidate_index]] + [
            c for idx, c in enumerate(candidates) if idx != candidate_index
        ]
    else:
        ordered = candidates

    last_error = None
    for idx, candidate in enumerate(ordered):
        override = audio_override if idx == 0 else None
        try:
            resolved = resolve_candidate(candidate, site_origin, settings, audio_override=override)
            log('Đã chọn nguồn [%s] (%s): %s' % (
                candidate.get('label', '?'),
                resolved.get('provider_label', '?'),
                candidate.get('link', ''),
            ))
            return resolved
        except Exception as exc:
            last_error = exc
            log('Nguồn %s lỗi (%s), thử nguồn dự phòng...' % (candidate.get('label', '?'), exc), xbmc.LOGWARNING)

    raise last_error or ValueError('Tất cả nguồn phát đều không khả dụng')
