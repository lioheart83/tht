# Changelog

## 1.1.2 - 2026-11-21

- **Đưa giới thiệu phim & thông tin đầy đủ ra ngoài danh sách phim**: Hiển thị nội dung phim, năm phát hành, quốc gia, thể loại, thời lượng và fanart ngay tại màn hình danh sách phim bên ngoài (Mới cập nhật, Phim lẻ, Phim bộ, Phim chiếu rạp, Thể loại, Quốc gia, Năm, Tìm kiếm).
- **Tối ưu tốc độ với HTTP/2 song song & Cache SQLite (`meta_cache.py`)**: Tải song song phần tóm tắt phim và lưu cache SQLite cục bộ 7 ngày (`meta_cache.db`, tối đa 2.000 phim) giúp các lần duyệt tiếp theo mở tức thì; có tùy chọn bật/tắt trong Cài đặt (`preload_movie_info`).

## 1.1.1 - 2026-11-21

- **Phụ đề chỉ giữ 1 bản Tiếng Việt duy nhất (`.vi.srt`)**: Bỏ ghép phụ đề song ngữ Việt-Anh và bỏ track tiếng Anh phụ trên `streamvsmov.com` và `vicdn.cc`, giúp bật/tắt phụ đề trong Kodi chỉ hiển thị gọn 1 dòng Tiếng Việt và giảm request khi tải luồng phát.

## 1.1.0 - 2026-11-21

- **Đổi tên miền & Tự động chuyển dự phòng (Auto-Failover)**: Thay thế domain cũ bị chặn (`motchilli.today`) bằng hệ thống mirror hoạt động (`motchillxv.cc`, `motchilltvi.net`, `motchillr.one`, `motchille.net`); tự động phát hiện chặn SNI/Cloudflare/5xx để chuyển mirror và lưu cache trong phiên Kodi.
- **Cài đặt Addon (`resources/settings.xml`)**: Hỗ trợ chọn mirror tự động/cố định/tùy chỉnh, cấu hình timeout, chọn chất lượng ưu tiên (`Full HD` hoặc `Tiết kiệm băng thông` thay vì ép SD trên Android TV), bật/tắt lọc quảng cáo HLS, tự động tải phụ đề và chọn luồng âm thanh mặc định cho ViCDN.
- **Sửa lỗi chọn nhầm Server (`Thuyết Minh` bị phát `Vietsub`)**: Khớp chính xác thuộc tính `data-server` theo đường dẫn `-sv-N` trên trang xem, đồng thời giữ nguồn dự phòng cùng ngôn ngữ và hiển thị tên server rõ ràng (`Server 1 - VIP#1`, `Server 4 - VIP#4 Song Ngữ`, `Server 5 - VIP#5 Thuyết Minh`...).
- **Dịch vụ HLS Proxy nền (`service.py`) & Sửa lỗi `403` `streamc.xyz`**:
  - Chuyển HLS Proxy sang `xbmc.service` chạy suốt phiên Kodi kèm `<reuselanguageinvoker>true</reuselanguageinvoker>` để proxy không bị tắt khi `main.py` kết thúc.
  - Thay `requests` (HTTP/1.1) trong proxy bằng `httpx` (HTTP/2) có pooling để tải segment `streamc.xyz` không còn lỗi `403 Forbidden`.
  - Hỗ trợ `HEAD`, gom đệm đủ `32KB` để dò và cắt byte PNG rác trước MPEG-TS/fMP4 đáng tin cậy.
- **Lọc quảng cáo chèn trong luồng HLS (`#EXT-X-DISCONTINUITY`)**: Tự động loại bỏ các cụm segment quảng cáo tiêm vào manifest (`convertv9/*.ts`, `/v9/*/segment_*.ts`) trên nguồn `kvp726.com` và giữ đúng ranh giới discontinuity theo chuẩn HLS.
- **Phụ đề WebVTT -> SRT & Hỗ trợ nguồn mới `vicdn.cc` (`VIP Song Ngữ`)**:
  - Tự động tải phụ đề `.vtt` từ `streamvsmov.com` (hỗ trợ timestamp `MM:SS.mmm`) và chuyển đổi sang `.srt`.
  - Giải mã player `vicdn.cc` (Dean Edwards + AES-256-GCM manifest fMP4 & phụ đề), hỗ trợ đủ 3 kênh âm thanh (`Audio Gốc`, `T.Minh Nữ`, `T.Minh Nam`) và ghép phụ đề **Song ngữ Việt-Anh**.
- **Sửa toàn bộ danh mục, phân trang & nâng chuẩn Kodi 20/21**:
  - Sửa đường dẫn `Mới cập nhật` (`/phim`), `Năm phát hành` (`/nam/%s`), `Phim hoạt hình`, `TV Shows`, phân trang tìm kiếm (`/page/N/?s=...`) và thêm **Lịch sử tìm kiếm**.
  - Cập nhật selector thẻ phim (`li.item`), thông tin chi tiết (`.dinfo`, `.real-name`, `#info-film`), context menu **Chọn nguồn phát...**, và dùng `InfoTagVideo` thay thế `ListItem.setInfo` đã deprecated.
  - Dọn dẹp kiến trúc thành các mô-đun rõ ràng trong `resources/lib/motchille/` và loại bỏ ~180 dòng mã cũ không còn sử dụng.

## 1.0.13 - 2026-09-12

- Sua nguon phat khong chay (khoang 24% phim): data-link kieu `embed*.streamc.xyz` gio duoc resolve bang bootstrap API HTTP/2 (bundle httpx) roi giai ma manifest #ENC-AESGCM va phat qua proxy noi bo voi Referer dung URL embed.
- Them resolver cho `v7/v8.streamvsmov.com`: doi trang player `/video/<hash>` thanh `/stream/<hash>/master.m3u8` va phat qua proxy noi bo (segment PNG chua TS, proxy tu do offset TS co san).
- Chuyen BASE_URL sang `motchilli.today` (motchille.mov chi con 301) de bot mot hop moi request.
- Trang xem gio doc data-link moi dang (khong chi m3u8) de phan loai nguon.


## 1.0.12

- Chuyển nguồn từ `motchille.cx` sang mirror `motchille.mov`, tránh lỗi kết nối TLS/SNI trên một số mạng.
- Thay scraper API cũ bằng luồng WordPress/OPhim: trang danh sách, trang chi tiết, trang xem và thuộc tính `data-link` của player.
- Lấy HLS trực tiếp khi chọn tập, giảm request và không phụ thuộc cookie hay cơ chế Cloudflare của tên miền cũ.

## 1.0.11

- Sửa bộ đọc nguồn phát để tương thích API bọc dữ liệu trong `data`/`result`/`payload` và các tên trường link mới như `url`, `file`, `source`, `embed`.
- Chuẩn hóa nguồn tập nhúng và API trước khi hiển thị, không bỏ qua tập khi trang thay đổi tên trường `name`, `server` hoặc `type`.
- Nhận diện thêm các nguồn HLS khai báo kiểu `hls`/`hlsjs`.

## 1.0.10

- Giảm thời gian chờ mạng: timeout 12s và tối đa 2 lần thử (trước đây 30s x 3) để Android TV không bị treo lâu khi CDN chậm hoặc không phản hồi.
- Thêm thanh tiến trình nền khi chuẩn bị nguồn phát để thao tác chờ không giống bị treo.
- Proxy HLS truyền segment theo luồng thay vì nạp toàn bộ vào RAM; chỉ đệm ~16KB đầu để dò và bỏ byte rác trước MPEG-TS, giảm áp lực bộ nhớ và giật hình trên Android TV.

## 1.0.9

- Chuẩn hóa nhãn tập để không hiển thị trùng `Tập Tập 01`.

## 1.0.8

- Sửa lỗi tương thích Kodi Python `name 'ValueError' is not defined` khi đọc dữ liệu tập nhúng.

## 1.0.7

- Đổi sang tên miền Motchill đang hoạt động (`motchille.cx`) và thêm retry cho lỗi CDN 522.
- Lấy danh sách tập đầy đủ từ API `baseapi/episodes` thay vì dùng dữ liệu khởi tạo chỉ có tập đầu tiên.
- Đồng bộ header phát HLS theo tên miền mới để Kodi mở link ổn định hơn.

## 1.0.6

- Sửa bộ đọc danh sách tập để lấy toàn bộ các cụm `episodes` mà trang nhúng, thay vì chỉ cụm đầu tiên.

## 1.0.4 - 2026-07-04

- Fix playback for T Vietsub: the local HLS proxy now strips fake PNG headers before MPEG-TS data in segment payloads so Kodi can read the stream.
- Force /player/master/... sources through the local proxy on every platform, not only Android TV.

## 1.0.3 - 2026-07-04

- Tối ưu phát HLS cho Android TV: resolve trước manifest `m3u8` sang playlist con trước khi đưa vào Kodi.
- Thêm proxy localhost nhẹ cho luồng HLS trên Android để Kodi không phải tự xử lý nhiều request/headers tới server gốc.
- Giữ fallback về link trực tiếp nếu bước tối ưu HLS gặp lỗi, tránh làm hỏng playback trên PC.

## 1.0.2 - 2026-07-04

- Chuyển toàn bộ phần phân tích HTML sang `BeautifulSoup` (thẻ card phim, chi tiết phim, meta) thay cho regex thủ công, bền hơn khi HTML thay đổi
- Parse mỗi trang HTML một lần rồi tái dùng `soup` (thêm helper `fetch_soup`)
- Thêm phụ thuộc `script.module.beautifulsoup4`

## 1.0.1 - 2026-07-04

- Tái sử dụng một `requests.Session` (keep-alive) cho toàn bộ lần chạy
- Gom mục thư mục và thêm một lần bằng `addDirectoryItems`, dùng `ListItem(offscreen=True)`
- Tránh tải lại HTML trang phim khi phim chỉ có một server
- Chỉ khai báo mime HLS cho nguồn `m3u8`, tránh phát lỗi với nguồn `embed`/`mp4`

## 1.0.0 - 2026-07-03

- Tạo addon `plugin.video.motchille` cho nguồn `motchille.app`
- Hỗ trợ duyệt phim mới cập nhật, phim lẻ, phim bộ, phim chiếu rạp, thuyết minh, thể loại, quốc gia và năm phát hành
- Tích hợp tìm kiếm qua API `searchapi/search`
- Trích xuất danh sách tập và link `m3u8` trực tiếp từ dữ liệu render của trang phim
- Phát video trực tiếp trong Kodi, ưu tiên nguồn `m3u8` thay vì mở trình duyệt ngoài
