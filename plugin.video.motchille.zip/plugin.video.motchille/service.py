# -*- coding: utf-8 -*-
"""Background Kodi service keeping the local HTTP/2 HLS proxy alive across plugin calls."""

import json
import os
import sys

_LIB_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'resources', 'lib')
if _LIB_DIR not in sys.path:
    sys.path.insert(0, _LIB_DIR)

import xbmc
import xbmcgui

from resources.lib.motchille.config import WINDOW_PROP_PROXY, log
from resources.lib.motchille.proxy import HlsProxyServer


def run_service():
    """Start the HLS proxy server and wait until Kodi shuts down."""
    server = HlsProxyServer()
    port = server.start()
    window = xbmcgui.Window(10000)
    window.setProperty(WINDOW_PROP_PROXY, json.dumps({'port': port, 'token': server.token}))
    log('Dịch vụ HLS Proxy khởi chạy tại 127.0.0.1:%d' % port)

    monitor = xbmc.Monitor()
    try:
        while not monitor.abortRequested():
            if monitor.waitForAbort(1):
                break
    finally:
        window.clearProperty(WINDOW_PROP_PROXY)
        server.stop()
        log('Dịch vụ HLS Proxy đã dừng')


if __name__ == '__main__':
    run_service()
