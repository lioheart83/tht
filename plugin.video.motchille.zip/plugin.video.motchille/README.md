# Motchille Kodi Addon (`v1.1.2`)

Addon xem phim trực tiếp trong Kodi từ hệ thống Motchill (hỗ trợ tự động chuyển mirror dự phòng như `motchillxv.cc`, `motchilltvi.net` hoặc tên miền tùy chỉnh trong phần cài đặt).

## Tính năng chính
- Duyệt phim mới cập nhật, phim lẻ, phim bộ, phim chiếu rạp, phim thuyết minh, hoạt hình và TV Shows.
- Hiển thị đầy đủ giới thiệu phim, năm, thời lượng, thể loại, quốc gia và fanart ngay ngoài danh sách phim (có cache SQLite tăng tốc).
- Duyệt theo thể loại, quốc gia và năm phát hành.
- Tìm kiếm phim kèm **lịch sử tìm kiếm** (xem lại, xóa từng từ khóa hoặc xóa toàn bộ).
- Chọn đúng server ngôn ngữ (`Vietsub`, `Thuyết Minh`, `Song Ngữ`) và hỗ trợ context menu **`Chọn nguồn phát...`** trên từng tập phim.
- Tự động lọc quảng cáo chèn trong luồng HLS (`#EXT-X-DISCONTINUITY`).
- Tự động tải phụ đề Tiếng Việt rời WebVTT sang SRT trên `streamvsmov.com` và `vicdn.cc`.
- Dịch vụ nền `service.py` cung cấp HTTP/2 HLS Proxy ổn định cho `streamc.xyz`, `streamvsmov.com`, `vicdn.cc` và tối ưu `reuselanguageinvoker`.
